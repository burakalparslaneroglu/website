function [thresh,a,b,ncons]=threshold_determination(P,a,b,rho)
% This function computes simple threshold for pairs trading.
% Inputs: 1) P: Tx2 Price matrix 2) a: initial intercept term (can be
% empty) 3) b: initial slope term (can be empty) 4) rho: a parameter to
% control tightness of threshold.
% Outputs: 1) Thresh: trading Threshold 2) a: estimated intercept term
% 3) b: estimate slope term 4) ncons: scaling factor for Prices (used in
% spread determination)

if isempty(a) && isempty(b) % If not supplied, estimate a and b via OLS
    OLS_result=fitlm(P(:,2),P(:,1));
    a=OLS_result.Coefficients.Estimate(1);
    b=OLS_result.Coefficients.Estimate(2);
end
if a==0 && b==1 
    thresh=rho*std(P(:,1)/P(1,1)-a-b*P(:,2)/P(1,2)); % threshold in Gatev et al.
    ncons=P(end,:);
elseif isempty(a) && isempty(b)
    thresh=2*std(OLS_res.Residuals.Raw);
    ncons=ones(1,2);
else
    thresh=rho*std(P(:,1)*a-b*P(:,2));
    ncons=ones(1,2);
end

