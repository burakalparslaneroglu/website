"PAIRS TRADING WITH WAVELET TRANSFORM"
Burak Alparslan Eroğlu, Haluk Yener and Taner Yiğit
MATLAB Codes used in practical implementation of the method

MAINFILE:
	mainfile_trading.m: Runs a wavelet pairs trading exercise for given data.

AUXILLIARY FILES: 
	spread_determination.m: computes the spread described in the article.
	threshold_determination.m: computes the threshold.	
	