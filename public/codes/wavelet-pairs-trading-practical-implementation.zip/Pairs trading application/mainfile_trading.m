% This code can be used to employ Pairs trading algortihm
% It only requires two custom functions "spread_determination" and
% "threshold determination".
clear
close all
clc
%% Fix Parameters
rho=1; % Threshold tightness parameter. Higher -> low chance to open trade.
initial_capital=1; % How much capital will be put on trading
tc=0.001; % Transaction cost per action.
wavelet='sym22'; % Type of wavelet
level=1; % Wavelet level
T0=252; % Training period sample size
%% Dynamic Parameters
thresh=[]; % Threshold
a=[]; % Intercept parameter
b=[]; % Slope parameter
Trade_open=0; % Trade open indicator
Trade_close=0; % Trade close indicator
Trade_profit_Short=[]; % Profit from short side of the trade 
Trade_profit_Long=[]; % Profit from long side of the trade
Trade_profit=[]; % Total Profit from on one full turn trade
Stocks=[]; % Stocks transcated in the trade
Transaction_price=[]; % transaction price at trade openning
spread=[]; % current spread
spread_open=[]; % spread at trade opening time
total_profit=0; % Total profit.
 Transaction_cost=0; % Transaction cost
%% Main Trading Algotrithm
stop=0; % Stoping rule
data(:,1)=cumsum(randn(505,1));
data(:,2)=cumsum(randn(505,1))+randn(505,1); % Example of data set. It can be retrieved inside the main while loop instead.
t=0;
while stop==0
    t=t+1;
    data0=data(t:t+252,:);
    D1w0=modwt(data0(:,1),char(wavelet),level);
    D2w0=modwt(data0(:,2),char(wavelet),level);
    dataw0=[D1w0(end,:)' D2w0(end,:)'];
    if t>505-253 % end of sample period.
        stop=1; % loop will stop 
    end
    if isempty(thresh) % Compute Threshold if it has not bee computed before
        Pw0=dataw0(1:end-1,:); % T0 observation closest to the most recent observation
        [thresh,a,b,ncons]=threshold_determination(Pw0,a,b,rho);
    end
    Pnew=data0(end,:);
    Pwnew=dataw0(end,:);
    if Trade_open==0 && stop==0 % If trade is not opened previously, check trade opening opportunities
        [spread]=spread_determination(Pwnew,a,b,ncons); % Compute the spread

        if spread>thresh % Check whether trade should be opened
            Trade_open=1; % if Trade is opened, display infor regarding transactions.
            disp(['Long-buy ' num2str(b) '$ worth stock 1 and Short-sell ' num2str(1) '$ worth Stock 2'])
            Stocks=[abs(b)/Pnew(1) 1/Pnew(2)]; % How many stocks to transact for each security
            Transaction_price=[Pnew(1) Pnew(2)]; % Transaction Price
            spread_open=spread; % Save trade opening spread
        end

        if spread<-thresh
            Trade_open=1;
            disp(['Short-sell ' num2str(b) '$ worth stock 1 and Long-buy ' num2str(1) '$ worth Stock 2'])
            Stocks=[abs(b)/Pnew(1) 1/Pnew(2)];
            Transaction_price=[Pnew(1) Pnew(2)];
            spread_open=spread;
        end

    end

    if Trade_open==1 % Check whether trade should be closed.
        [spread]=spread_determination(Pwnew,a,b,ncons);
        if spread_open>0 && (spread<=0 || stop==1)
            Trade_close=1;
            disp(['Close the position: Long-buy ' num2str(b) '$ worth stock 1 and Short-sell ' num2str(1) '$ worth Stock 2'])
            Trade_profit_Long=Stocks(1)*(-Transaction_price(1)+Pnew(1)); % profit from long position
            Trade_profit_Short=Stocks(2)*(Transaction_price(2)-Pnew(2)); % profit from short position
            Transaction_cost=tc*(Stocks(1)*(Transaction_price(1)+Pnew(1))+Stocks(2)*(Transaction_price(2)+Pnew(2))); % transaction cost paid
            Trade_profit=Trade_profit_Long+Trade_profit_Short-Transaction_cost; % Total profit from the trade
        end

        if spread_open<0 && (spread>=0 || stop==1)
            Trade_close=1; % if Trade is closed, display infor regarding transactions.
            disp(['Close the position: Short-sell ' num2str(b) '$ worth stock 1 and Long-buy ' num2str(1) '$ worth Stock 2'])
            Trade_profit_Short=Stocks(1)*(Transaction_price(1)-Pnew(1));
            Trade_profit_Long=Stocks(2)*(-Transaction_price(2)+Pnew(2));
            Transaction_cost=tc*(Stocks(1)*(Transaction_price(1)+Pnew(1))+Stocks(2)*(Transaction_price(2)+Pnew(2)));
            Trade_profit=Trade_profit_Long+Trade_profit_Short-Transaction_cost;
        end
        if Trade_close==1 % Reset all dynamic parameters.
            total_profit=total_profit+Trade_profit;
            % One can save these parameters to monitor the trading
            % algorithm
            thresh=[];
            a=[];
            b=[];
            Trade_open=0;
            Trade_profit_Short=[];
            Trade_profit_Long=[];
            Trade_profit=[];
            Stocks=[];
            Transaction_price=[];
            spread=[];
            spread_open=[];
            % save relevant trade outputs such as Stocks, profit etc.
            Trade_close=0;
            transaction_cost=0;
            
        end
    end
end