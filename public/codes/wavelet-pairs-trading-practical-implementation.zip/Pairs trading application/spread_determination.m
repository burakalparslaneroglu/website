function [spread]=spread_determination(P,a,b,ncons)
% This function computes the spread given (INPUTS) 1) P: 1x2 the most
% recent price 2) a: intercept parameter 3) b: slope parameter 4) scaling
% factors for the Prices
if a==0 && b==1
    spread=P(1)/ncons(1)-a-b*P(2)/ncons(2); % Gatev type spread
else
    spread=P(1)/ncons(1)-b*P(2)/ncons(2)-a; %residuals from cointegrating regression
end