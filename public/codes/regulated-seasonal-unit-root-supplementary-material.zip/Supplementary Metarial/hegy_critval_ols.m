function [result]=hegy_critval_ols(T,S,rep,detrending)
for r=1:rep
    eps=randn(T,S);
    eps=eps*inv(chol(cov(eps)));
    S_star=floor((S-1)/2);
    W_0=[0;cumsum(eps(:,1))];
 
    if detrending==1
        z=ones(length(W_0),1);
    elseif detrending==2
        z=[ones(length(W_0),1) (1:length(W_0))'/length(W_0)];
    else
        z=[];
    end
        [W_0,~]=olsd(W_0,z);
        dW_0=diffk(W_0,1);
        W_s2=[0;cumsum(eps(:,2))];
        [W_s2,~]=olsd(W_s2,z);
        dW_s2=diffk(W_s2,1);
        W_i=[zeros(1,S_star);cumsum(eps(:,3:S_star+2))];
        for k=1:size(W_i,2)
            [W_i(:,k),~]=olsd(W_i(:,k),z);
        end
        dW_i=diffk(W_i,1);
        W_i_star=[zeros(1,S_star);cumsum(eps(:,S_star+3:S_star+2+S_star))];
        for k=1:size(W_i_star,2)
            [W_i_star(:,k),~]=olsd(W_i_star(:,k),z);
        end
        dW_i_star=diffk(W_i_star,1);
        
        S_star=floor((S-1)/2);
        
        result.t_0(r)=(W_0(1:end-1)'*dW_0(2:end)/(T))/sqrt(W_0(1:end-1)'*W_0(1:end-1)/(T^2));
        result.t_s2(r)=(W_s2(1:end-1)'*dW_s2(2:end)/(T))/sqrt(W_s2(1:end-1)'*W_s2(1:end-1)/(T^2));
        
        for i=1:S_star
            result.F_i(r,i)=(((((W_i(1:end-1,i)'*dW_i(2:end,i)/(T)))+((W_i_star(1:end-1,i)'*dW_i_star(2:end,i)/(T))))^2)+...
                ((((W_i(1:end-1,i)'*dW_i_star(2:end,i)/(T)))-((W_i_star(1:end-1,i)'*dW_i(2:end,i)/(T))))^2))/...
                (2*(((W_i(1:end-1,i)'*W_i(1:end-1,i)/(T^2)))+((W_i_star(1:end-1,i)'*W_i_star(1:end-1,i)/(T^2)))));
        end
        result.F_1s2(r)=(1/(S-1))*(result.t_s2(r)^2+2*sum(result.F_i(r,:)));
        result.F_0s2(r)=(1/S)*(result.t_0(r)^2+result.t_s2(r)^2+2*sum(result.F_i(r,:)));
        
        
    end
    
    
