function eps_s=svec(eps,S);
if size(eps,2)==1
    for i=0:S-1
        eps_s(:,1+i)=eps(1+i:S:end);
    end
end
if size(eps,2)>1
    eps_s=zeros(size(eps,2)*size(eps,1),1);
    for i=0:S-1
        eps_s(1+i:S:end)=eps(:,1+i);
    end
end