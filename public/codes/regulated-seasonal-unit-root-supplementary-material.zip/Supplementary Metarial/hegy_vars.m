function [y_0,y_s2,y_i,y_i_star]=hegy_vars(y,S);
T=length(y);
S_star=floor((S-1)/2);
y_0=zeros(T,1);
y_s2=zeros(T,1);
for j=0:S-1
    y_0=y_0+lagn(y,1+j);
    y_s2=y_s2+cos((1+j)*pi)*lagn(y,1+j);
end
y_i=[];
y_i_star=[];
for i=1:S_star
    eval(['y_' num2str(i) '=zeros(T,1);'])
    eval(['y_' num2str(i) '_star=zeros(T,1);'])
    for j=0:S-1
    eval(['y_' num2str(i) '=y_' num2str(i) '+lagn(y,1+j)*cos((1+j)*2*pi*i/S);'])
    eval(['y_' num2str(i) '_star=y_' num2str(i) '_star-lagn(y,1+j)*sin((1+j)*2*pi*i/S);'])

    end
    eval(['y_i=[y_i y_' num2str(i) '];'])
    eval(['y_i_star=[y_i_star y_' num2str(i) '_star];'])
end