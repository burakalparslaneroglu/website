% myCluster = parcluster('local')
% myCluster.NumWorkers=16
% parpool(16)

clear
clc
close all
S=4;
stationary=0;
modelar={'ar1','ar2','ar4'}
modelma={'ma1','ma2','ma4'}
C_0=ones(S,S);
v_s2=((-1).^(1:S))';
C_s2=v_s2*v_s2';
w_1=2*pi*1/S;
v_1=[cos(w_1*(1-S:0));sin(w_1*(1-S:0))]';
v_1_star=[-sin(w_1*(1-S:0));cos(w_1*(1-S:0))]';
C_1=v_1*v_1';
C_1_star=v_1*v_1_star';
for N=[100 1000] % Sample size
    
    S=4; %Number of seasons
    T=S*N;
    MC=10000; % Number of Monte Carlo Replication
    for detrending=[1] % Only mean case for detrending=1 and mean and trend case for detrending=2
        for md=1:5 % Type of serial correlation
            
            if md==1
                ar_coeffs=[0];
                ar_coeff=0;
                ma_coeff=0;
                ma_coeffs=[0.8];
                mdar=1;
                mdma=1;
            end
            
            if md==2
                ar_coeffs=0;
                ma_coeffs=[0 0 0 0.5];
                ar_coeff=0;
                ma_coeff=0.5;
                mdar=1;
                mdma=1;
            end
            
            if md==3
                ar_coeffs=0;
                ma_coeffs=[0 0 0 -0.5];
                ar_coeff=0;
                ma_coeff=-0.5;
                mdar=1;
                mdma=1;
            end
            if md==4
                ar_coeffs=[0 0 0 0.5];
                ma_coeffs=[0];
                ar_coeff=0.5;
                ma_coeff=0;
                mdar=2;
                mdma=2;
            end
            if md==5
                ar_coeffs=[0 0 0 -0.5];
                ma_coeffs=[0];
                ar_coeff=-0.5;
                ma_coeff=0;
                mdar=2;
                mdma=2;
            end
            kmin=0;
            kmax=floor(12*(T/100)^(0.25));
            
            
            for asym=[0]
                bb=0;
                for bound=[0.3 0.6 inf]
                    bb=bb+1;
                    if asym==0
                        cu=bound;
                        cl=-bound;
                    else
                        cu=2*bound;
                        cl=0;
                    end
                    % The asymptotic Bounds
                    lambda=((1+sum(ma_coeffs))^2)/(1-sum(ar_coeffs))^2;
                    
                    bl=cl*sqrt(lambda)*sqrt(T);
                    bu=cu*sqrt(lambda)*sqrt(T);
                    % The asymptotic Bounds
                    
                    % Standard HEGY critical values
                    result_asym_nb=hegy_critval_ols(T,S,MC,detrending);
                    rr=0;
                    tic;
                    
                    for rho=[1 0.99 0.9] % 1 for size and other values for power exercise
                        rr=rr+1
                        roots0=[rho 1 0 1]; % roots of seasonal polynomial
                        
                        parfor mc=1:MC
                            %% Simulation of bounded seasonal unit root process
                            y_s0=zeros(S,1);
                            eps=randn(T,1);
                            eps=arima_sim(eps,ar_coeffs,ma_coeffs,[],[]);
                            [y_s,regu,regl]=seasonal_bounded_unit_root_sim_v2(eps,S,roots0,y_s0,bl,bu);
                            y_sn_t0=y_s;
                            %% Detrending observed series by using OLS
                            z=[];
                            if detrending==1
                                y_sn_t0=zeros(T,1);
                                for i=0:S-1
                                    z=ones(length(y_s(1+i:S:end)),1);
                                    [y_sn_t0(1+i:S:end),~]=olsd(y_s(1+i:S:end),z);
                                end
                            end
                            if detrending==2
                                y_sn_t0=zeros(T,1);
                                for i=0:S-1
                                    z=[ones(length(y_s(1+i:S:end)),1) (1:length(y_s(1+i:S:end)))'];
                                    [y_sn_t0(1+i:S:end),~]=olsd(y_s(1+i:S:end),z);
                                end
                            end
                            y_sn_ts2=y_s;
                            
                            if detrending==1
                                y_sn_ts2=zeros(T,1);
                                for i=0:S-1
                                    z=ones(length(y_s(1+i:S:end)),1);
                                    [y_sn_ts2(1+i:S:end),~]=olsd(y_s(1+i:S:end),z);
                                end
                            end
                            if detrending==2
                                y_sn_ts2=zeros(T,1);
                                for i=0:S-1
                                    z=[ones(length(y_s(1+i:S:end)),1) (1:length(y_s(1+i:S:end)))'];
                                    [y_sn_ts2(1+i:S:end),~]=olsd(y_s(1+i:S:end),z);
                                end
                            end
                            
                            y_sn_F_i=y_s;
                            
                            if detrending==1
                                y_sn_F_i=zeros(T,1);
                                for i=0:S-1
                                    z=ones(length(y_s(1+i:S:end)),1);
                                    [y_sn_F_i(1+i:S:end),~]=olsd(y_s(1+i:S:end),z);
                                end
                            end
                            if detrending==2
                                y_sn_F_i=zeros(T,1);
                                for i=0:S-1
                                    z=[ones(length(y_s(1+i:S:end)),1) (1:length(y_s(1+i:S:end)))'];
                                    [y_sn_F_i(1+i:S:end),~]=olsd(y_s(1+i:S:end),z);
                                end
                            end
                            %% Calculating Long-run covariance 
                            [sigma_t0,~,~,~,~]=covvar(diff(svec(y_sn_t0,S)));
                            [sigma_ts2,~,~,~,~]=covvar(diff(svec(y_sn_ts2,S)));
                            [sigma_F_i,~,~,~,~]=covvar(diff(svec(y_sn_F_i,S)));
                            %% Estimating the seasonal model and constrcting the test statistics
                            [result_est_t0]=hegy_reg_opt(y_sn_t0,S,kmin,kmax,0,[]);
                            est_sigma_t0=result_est_t0.sigma_hat_est;
                            t_0(mc)=result_est_t0.t_0;
                            
                            [result_est_ts2]=hegy_reg_opt(y_sn_ts2,S,kmin,kmax,0,[]);
                            t_s2(mc)=result_est_ts2.t_s2;
                            est_sigma_ts2=result_est_ts2.sigma_hat_est;
                            
                            [result_est_F_i]=hegy_reg_opt(y_sn_F_i,S,kmin,kmax,0,[]);
                            F_i(mc)=result_est_F_i.F_i;
                            est_sigma_F_i=result_est_F_i.sigma_hat_est;
                            
                            F_1s2(mc)=(t_s2(mc)^2+2*F_i(mc))/(S-1);
                            F_0s2(mc)=(t_0(mc)^2+t_s2(mc)^2+2*F_i(mc))/(S);
                            
                            %% Asymptotics for the seasonal bounded process
                            N1=N;
                            [result_t0]=bounded_HEGY_OLS_Critical_val(N1,S,sigma_t0,bl,bu,detrending,1);
                            result_asym_t_0(mc)=result_t0.asym_t_0;
                            
                            [result_ts2]=bounded_HEGY_OLS_Critical_val(N1,S,sigma_ts2,bl,bu,detrending,1);
                            result_asym_t_s2(mc)=result_ts2.asym_t_s2;
                            
                            [result_F_i]=bounded_HEGY_OLS_Critical_val(N1,S,sigma_F_i,bl,bu,detrending,1);
                            result_asym_F_i(mc)=result_F_i.asym_F_i;
                            
                            result_asym_F_1s2(mc)=(result_asym_t_s2(mc)^2+2*result_asym_F_i(mc))/(S-1);
                            result_asym_F_0s2(mc)=(result_asym_t_0(mc)^2+result_asym_t_s2(mc)^2+2*result_asym_F_i(mc))/(S);
                            
                            
                            B=result_est_t0.coeff_lag_delta_S;
                            [result_recolored_t0]=bounded_HEGY_OLS_recolored_Critical_val(N1,S,bl,bu,detrending,1,B,sigma_t0);
                            result_asym_t_0_recolored(mc)=result_recolored_t0.asym_t_0;
                            
                            [result_recolored_ts2]=bounded_HEGY_OLS_recolored_Critical_val(N1,S,bl,bu,detrending,1,B,sigma_ts2);
                            result_asym_t_s2_recolored(mc)=result_recolored_ts2.asym_t_s2;
                            
                            [result_recolored_F_i]=bounded_HEGY_OLS_recolored_Critical_val(N1,S,bl,bu,detrending,1,B,sigma_F_i);
                            result_asym_F_i_recolored(mc)=result_recolored_F_i.asym_F_i;
                            
                            result_asym_F_1s2_recolored(mc)=(result_asym_t_s2_recolored(mc)^2+2*result_asym_F_i_recolored(mc))/(S-1);
                            result_asym_F_0s2_recolored(mc)=(result_asym_t_0_recolored(mc)^2+result_asym_t_s2_recolored(mc)^2+2*result_asym_F_i_recolored(mc))/(S);
                            
                        end
                        %% For size-adjusted power exercise
                        if rho==1
                            result_asym_t_0sa=t_0;
                            result_asym_t_s2sa=t_s2;
                            result_asym_F_isa=F_i;
                            result_asym_F_1s2sa=F_1s2;
                            result_asym_F_0s2sa=F_0s2;
                        end
                        %% Obtaning the rejection frequnecies
                        rp.t0_recolored(rr,md,bb)=sum(t_0<=quantile(result_asym_t_0_recolored,0.05))/MC;
                        rp.ts2_recolored(rr,md,bb)=sum(t_s2<=quantile(result_asym_t_s2_recolored,0.05))/MC;
                        rp.F_i_recolored(rr,md,bb)=sum(F_i>=quantile(result_asym_F_i_recolored,0.95))/MC;
                        rp.F_1s2_recolored(rr,md,bb)=sum(F_1s2>=quantile(result_asym_F_1s2_recolored,0.95))/MC;
                        rp.F_0s2_recolored(rr,md,bb)=sum(F_0s2>=quantile(result_asym_F_0s2_recolored,0.95))/MC;
                        
                        rp.t0(rr,md,bb)=sum(t_0<=quantile(result_asym_t_0,0.05))/MC;
                        rp.ts2(rr,md,bb)=sum(t_s2<=quantile(result_asym_t_s2,0.05))/MC;
                        rp.F_i(rr,md,bb)=sum(F_i>=quantile(result_asym_F_i,0.95))/MC;
                        rp.F_1s2(rr,md,bb)=sum(F_1s2>=quantile(result_asym_F_1s2,0.95))/MC;
                        rp.F_0s2(rr,md,bb)=sum(F_0s2>=quantile(result_asym_F_0s2,0.95))/MC;
                        
                        rp.t0sa(rr,md,bb)=sum(t_0<=quantile(result_asym_t_0sa,0.05))/MC;
                        rp.ts2sa(rr,md,bb)=sum(t_s2<=quantile(result_asym_t_s2sa,0.05))/MC;
                        rp.F_isa(rr,md,bb)=sum(F_i>=quantile(result_asym_F_isa,0.95))/MC;
                        rp.F_1s2sa(rr,md,bb)=sum(F_1s2>=quantile(result_asym_F_1s2sa,0.95))/MC;
                        rp.F_0s2sa(rr,md,bb)=sum(F_0s2>=quantile(result_asym_F_0s2sa,0.95))/MC;
                        
                        rp.t0_nb(rr,md,bb)=sum(t_0<=quantile(result_asym_nb.t_0,0.05))/MC;
                        rp.ts2_nb(rr,md,bb)=sum(t_s2<=quantile(result_asym_nb.t_s2,0.05))/MC;
                        rp.F_i_nb(rr,md,bb)=sum(F_i>=quantile(result_asym_nb.F_i,0.95))/MC;
                        rp.F_1s2_nb(rr,md,bb)=sum(F_1s2>=quantile(result_asym_nb.F_1s2,0.95))/MC;
                        rp.F_0s2_nb(rr,md,bb)=sum(F_0s2>=quantile(result_asym_nb.F_0s2,0.95))/MC;
                        
                    end
                    
                    bname=num2str(bound);
                    bname=strrep(bname, '.', '_');
                    bname=strrep(bname, '-', 'n');
                    dname=num2str(detrending+1);
                    dname=strrep(dname, '.', '_');
                    dname=strrep(dname, '-', 'n');
                    if asym==1
                        aname='asymmetric';
                    else
                        aname='symmetric';
                    end
                    
                    toc;
                end
            end
            
        end
        %% Saving the results. A practitioner should change the directory accordingly
        savename=['D:\Dropbox\Seasonal Bounded unit roots\results bounded hegy\results_S' num2str(S) '_N_' num2str(N) '_olsdetrend' dname '_model_' num2str(md) aname '_bound_' bname '_t0'];
        save(savename,'rp');
    end
end

%% We repeat the same procedure above for testing at Nyquist Frequency
%%%%%%%% t_s2 %%%%%%%%%%%%%%%%%
clear
clc
close all
S=4;
stationary=0;
modelar={'ar1','ar2','ar4'}
modelma={'ma1','ma2','ma4'}
C_0=ones(S,S);
v_s2=((-1).^(1:S))';
C_s2=v_s2*v_s2';
w_1=2*pi*1/S;
v_1=[cos(w_1*(1-S:0));sin(w_1*(1-S:0))]';
v_1_star=[-sin(w_1*(1-S:0));cos(w_1*(1-S:0))]';
C_1=v_1*v_1';
C_1_star=v_1*v_1_star';
for N=[1000]
    
    S=4;
    T=S*N;
    MC=10000;
    for detrending=[1]
        for md=1:5
            
            if md==1
                ar_coeffs=[0];
                ar_coeff=0;
                ma_coeff=0;
                ma_coeffs=[0.8];
                mdar=1;
                mdma=1;
            end
            
            if md==2
                ar_coeffs=0;
                ma_coeffs=[0 0 0 0.5];
                ar_coeff=0;
                ma_coeff=0.5;
                mdar=1;
                mdma=1;
            end
            
            if md==3
                ar_coeffs=0;
                ma_coeffs=[0 0 0 -0.5];
                ar_coeff=0;
                ma_coeff=-0.5;
                mdar=1;
                mdma=1;
            end
            if md==4
                ar_coeffs=[0 0 0 0.5];
                ma_coeffs=[0];
                ar_coeff=0.5;
                ma_coeff=0;
                mdar=2;
                mdma=2;
            end
            if md==5
                ar_coeffs=[0 0 0 -0.5];
                ma_coeffs=[0];
                ar_coeff=-0.5;
                ma_coeff=0;
                mdar=2;
                mdma=2;
            end
            kmin=0;
            kmax=floor(12*(T/100)^(0.25));
            
            
            for asym=[0]
                bb=0;
                for bound=[0.3 0.6 inf]
                    bb=bb+1;
                    if asym==0
                        cu=bound;
                        cl=-bound;
                    else
                        cu=2*bound;
                        cl=0;
                    end
                    lambda=((1+sum(ma_coeffs))^2)/(1-sum(ar_coeffs))^2;
                    
                    bl=cl*sqrt(lambda)*sqrt(T);
                    bu=cu*sqrt(lambda)*sqrt(T);

                    result_asym_nb=hegy_critval_ols(T,S,MC,detrending);
                    rr=0;
                    tic;
                    
                    for rho=[1 0.99 0.9]
                        rr=rr+1
                        roots0=[1 1 0 rho];
                        
                        parfor mc=1:MC
                            y_s0=zeros(S,1);
                            eps=randn(T,1);
                            eps=arima_sim(eps,ar_coeffs,ma_coeffs,[],[]);
                            [y_s,regu,regl]=seasonal_bounded_unit_root_sim_v2(eps,S,roots0,y_s0,bl,bu);
                            y_sn_t0=y_s;
                            z=[];
                            if detrending==1
                                y_sn_t0=zeros(T,1);
                                for i=0:S-1
                                    z=ones(length(y_s(1+i:S:end)),1);
                                    [y_sn_t0(1+i:S:end),~]=olsd(y_s(1+i:S:end),z);
                                end
                            end
                            if detrending==2
                                y_sn_t0=zeros(T,1);
                                for i=0:S-1
                                    z=[ones(length(y_s(1+i:S:end)),1) (1:length(y_s(1+i:S:end)))'];
                                    [y_sn_t0(1+i:S:end),~]=olsd(y_s(1+i:S:end),z);
                                end
                            end
                            y_sn_ts2=y_s;
                            
                            if detrending==1
                                y_sn_ts2=zeros(T,1);
                                for i=0:S-1
                                    z=ones(length(y_s(1+i:S:end)),1);
                                    [y_sn_ts2(1+i:S:end),~]=olsd(y_s(1+i:S:end),z);
                                end
                            end
                            if detrending==2
                                y_sn_ts2=zeros(T,1);
                                for i=0:S-1
                                    z=[ones(length(y_s(1+i:S:end)),1) (1:length(y_s(1+i:S:end)))'];
                                    [y_sn_ts2(1+i:S:end),~]=olsd(y_s(1+i:S:end),z);
                                end
                            end
                            
                            y_sn_F_i=y_s;
                            
                            if detrending==1
                                y_sn_F_i=zeros(T,1);
                                for i=0:S-1
                                    z=ones(length(y_s(1+i:S:end)),1);
                                    [y_sn_F_i(1+i:S:end),~]=olsd(y_s(1+i:S:end),z);
                                end
                            end
                            if detrending==2
                                y_sn_F_i=zeros(T,1);
                                for i=0:S-1
                                    z=[ones(length(y_s(1+i:S:end)),1) (1:length(y_s(1+i:S:end)))'];
                                    [y_sn_F_i(1+i:S:end),~]=olsd(y_s(1+i:S:end),z);
                                end
                            end
                            [sigma_t0,~,~,~,~]=covvar(diff(svec(y_sn_t0,S)));
                            [sigma_ts2,~,~,~,~]=covvar(diff(svec(y_sn_ts2,S)));
                            [sigma_F_i,~,~,~,~]=covvar(diff(svec(y_sn_F_i,S)));
                            
                            [result_est_t0]=hegy_reg_opt(y_sn_t0,S,kmin,kmax,0,[]);
                            est_sigma_t0=result_est_t0.sigma_hat_est;
                            t_0(mc)=result_est_t0.t_0;
                            
                            [result_est_ts2]=hegy_reg_opt(y_sn_ts2,S,kmin,kmax,0,[]);
                            t_s2(mc)=result_est_ts2.t_s2;
                            est_sigma_ts2=result_est_ts2.sigma_hat_est;
                            
                            [result_est_F_i]=hegy_reg_opt(y_sn_F_i,S,kmin,kmax,0,[]);
                            F_i(mc)=result_est_F_i.F_i;
                            est_sigma_F_i=result_est_F_i.sigma_hat_est;
                            
                            F_1s2(mc)=(t_s2(mc)^2+2*F_i(mc))/(S-1);
                            F_0s2(mc)=(t_0(mc)^2+t_s2(mc)^2+2*F_i(mc))/(S);
                            
                            %                             Asymptotics
                            N1=N;
                            [result_t0]=bounded_HEGY_OLS_Critical_val(N1,S,sigma_t0,bl,bu,detrending,1);
                            result_asym_t_0(mc)=result_t0.asym_t_0;
                            
                            [result_ts2]=bounded_HEGY_OLS_Critical_val(N1,S,sigma_ts2,bl,bu,detrending,1);
                            result_asym_t_s2(mc)=result_ts2.asym_t_s2;
                            
                            [result_F_i]=bounded_HEGY_OLS_Critical_val(N1,S,sigma_F_i,bl,bu,detrending,1);
                            result_asym_F_i(mc)=result_F_i.asym_F_i;
                            
                            result_asym_F_1s2(mc)=(result_asym_t_s2(mc)^2+2*result_asym_F_i(mc))/(S-1);
                            result_asym_F_0s2(mc)=(result_asym_t_0(mc)^2+result_asym_t_s2(mc)^2+2*result_asym_F_i(mc))/(S);
                            
                            
                            B=result_est_t0.coeff_lag_delta_S;
                            [result_recolored_t0]=bounded_HEGY_OLS_recolored_Critical_val(N1,S,bl,bu,detrending,1,B,sigma_t0);
                            result_asym_t_0_recolored(mc)=result_recolored_t0.asym_t_0;
                            
                            [result_recolored_ts2]=bounded_HEGY_OLS_recolored_Critical_val(N1,S,bl,bu,detrending,1,B,sigma_ts2);
                            result_asym_t_s2_recolored(mc)=result_recolored_ts2.asym_t_s2;
                            
                            [result_recolored_F_i]=bounded_HEGY_OLS_recolored_Critical_val(N1,S,bl,bu,detrending,1,B,sigma_F_i);
                            result_asym_F_i_recolored(mc)=result_recolored_F_i.asym_F_i;
                            
                            result_asym_F_1s2_recolored(mc)=(result_asym_t_s2_recolored(mc)^2+2*result_asym_F_i_recolored(mc))/(S-1);
                            result_asym_F_0s2_recolored(mc)=(result_asym_t_0_recolored(mc)^2+result_asym_t_s2_recolored(mc)^2+2*result_asym_F_i_recolored(mc))/(S);
                            
                        end
                        
                        if rho==1
                            result_asym_t_0sa=t_0;
                            result_asym_t_s2sa=t_s2;
                            result_asym_F_isa=F_i;
                            result_asym_F_1s2sa=F_1s2;
                            result_asym_F_0s2sa=F_0s2;
                        end
                        rp.t0_recolored(rr,md,bb)=sum(t_0<=quantile(result_asym_t_0_recolored,0.05))/MC;
                        rp.ts2_recolored(rr,md,bb)=sum(t_s2<=quantile(result_asym_t_s2_recolored,0.05))/MC;
                        rp.F_i_recolored(rr,md,bb)=sum(F_i>=quantile(result_asym_F_i_recolored,0.95))/MC;
                        rp.F_1s2_recolored(rr,md,bb)=sum(F_1s2>=quantile(result_asym_F_1s2_recolored,0.95))/MC;
                        rp.F_0s2_recolored(rr,md,bb)=sum(F_0s2>=quantile(result_asym_F_0s2_recolored,0.95))/MC;
                        
                        rp.t0(rr,md,bb)=sum(t_0<=quantile(result_asym_t_0,0.05))/MC;
                        rp.ts2(rr,md,bb)=sum(t_s2<=quantile(result_asym_t_s2,0.05))/MC;
                        rp.F_i(rr,md,bb)=sum(F_i>=quantile(result_asym_F_i,0.95))/MC;
                        rp.F_1s2(rr,md,bb)=sum(F_1s2>=quantile(result_asym_F_1s2,0.95))/MC;
                        rp.F_0s2(rr,md,bb)=sum(F_0s2>=quantile(result_asym_F_0s2,0.95))/MC;
                        
                        rp.t0sa(rr,md,bb)=sum(t_0<=quantile(result_asym_t_0sa,0.05))/MC;
                        rp.ts2sa(rr,md,bb)=sum(t_s2<=quantile(result_asym_t_s2sa,0.05))/MC;
                        rp.F_isa(rr,md,bb)=sum(F_i>=quantile(result_asym_F_isa,0.95))/MC;
                        rp.F_1s2sa(rr,md,bb)=sum(F_1s2>=quantile(result_asym_F_1s2sa,0.95))/MC;
                        rp.F_0s2sa(rr,md,bb)=sum(F_0s2>=quantile(result_asym_F_0s2sa,0.95))/MC;
                        
                        rp.t0_nb(rr,md,bb)=sum(t_0<=quantile(result_asym_nb.t_0,0.05))/MC;
                        rp.ts2_nb(rr,md,bb)=sum(t_s2<=quantile(result_asym_nb.t_s2,0.05))/MC;
                        rp.F_i_nb(rr,md,bb)=sum(F_i>=quantile(result_asym_nb.F_i,0.95))/MC;
                        rp.F_1s2_nb(rr,md,bb)=sum(F_1s2>=quantile(result_asym_nb.F_1s2,0.95))/MC;
                        rp.F_0s2_nb(rr,md,bb)=sum(F_0s2>=quantile(result_asym_nb.F_0s2,0.95))/MC;
                        
                    end
                    
                    bname=num2str(bound);
                    bname=strrep(bname, '.', '_');
                    bname=strrep(bname, '-', 'n');
                    dname=num2str(detrending+1);
                    dname=strrep(dname, '.', '_');
                    dname=strrep(dname, '-', 'n');
                    if asym==1
                        aname='asymmetric';
                    else
                        aname='symmetric';
                    end
                    
                    toc;
                end
            end
            
        end
        savename=['D:\Dropbox\Seasonal Bounded unit roots\results bounded hegy\results_S' num2str(S) '_N_' num2str(N) '_olsdetrend' dname '_model_' num2str(md) aname '_bound_' bname '_ts2'];
        save(savename,'rp');
    end
end
%% We repeat the same procedure above for testing at Harmonic Frequencies
%%%%%%%%%%%%%%  F_i %%%%%%%%%%%%
clear
clc
close all
S=4;
stationary=0;
modelar={'ar1','ar2','ar4'}
modelma={'ma1','ma2','ma4'}
C_0=ones(S,S);
v_s2=((-1).^(1:S))';
C_s2=v_s2*v_s2';
w_1=2*pi*1/S;
v_1=[cos(w_1*(1-S:0));sin(w_1*(1-S:0))]';
v_1_star=[-sin(w_1*(1-S:0));cos(w_1*(1-S:0))]';
C_1=v_1*v_1';
C_1_star=v_1*v_1_star';
for N=[100 1000]
    
    S=4;
    T=S*N;
    MC=10000;
    for detrending=[1]
        for md=1:5
            
            if md==1
                ar_coeffs=[0];
                ar_coeff=0;
                ma_coeff=0;
                ma_coeffs=[0.8];
                mdar=1;
                mdma=1;
            end
            
            if md==2
                ar_coeffs=0;
                ma_coeffs=[0 0 0 0.5];
                ar_coeff=0;
                ma_coeff=0.5;
                mdar=1;
                mdma=1;
            end
            
            if md==3
                ar_coeffs=0;
                ma_coeffs=[0 0 0 -0.5];
                ar_coeff=0;
                ma_coeff=-0.5;
                mdar=1;
                mdma=1;
            end
            if md==4
                ar_coeffs=[0 0 0 0.5];
                ma_coeffs=[0];
                ar_coeff=0.5;
                ma_coeff=0;
                mdar=2;
                mdma=2;
            end
            if md==5
                ar_coeffs=[0 0 0 -0.5];
                ma_coeffs=[0];
                ar_coeff=-0.5;
                ma_coeff=0;
                mdar=2;
                mdma=2;
            end
            kmin=0;
            kmax=floor(12*(T/100)^(0.25));
            
            
            for asym=[0]
                bb=0;
                for bound=[0.3 0.6 inf]
                    bb=bb+1;
                    if asym==0
                        cu=bound;
                        cl=-bound;
                    else
                        cu=2*bound;
                        cl=0;
                    end
                    lambda=((1+sum(ma_coeffs))^2)/(1-sum(ar_coeffs))^2;
                    
                    bl=cl*sqrt(lambda)*sqrt(T);
                    bu=cu*sqrt(lambda)*sqrt(T);
                   
                    result_asym_nb=hegy_critval_ols(T,S,MC,detrending);
                    rr=0;
                    tic;
                    
                    for rho=[1 0.99 0.9]
                        rr=rr+1
                        roots0=[1 rho 0 1];
                        
                        parfor mc=1:MC
                            y_s0=zeros(S,1);
                            eps=randn(T,1);
                            eps=arima_sim(eps,ar_coeffs,ma_coeffs,[],[]);
                            [y_s,regu,regl]=seasonal_bounded_unit_root_sim_v2(eps,S,roots0,y_s0,bl,bu);
                            y_sn_t0=y_s;
                            z=[];
                            if detrending==1
                                y_sn_t0=zeros(T,1);
                                for i=0:S-1
                                    z=ones(length(y_s(1+i:S:end)),1);
                                    [y_sn_t0(1+i:S:end),~]=olsd(y_s(1+i:S:end),z);
                                end
                            end
                            if detrending==2
                                y_sn_t0=zeros(T,1);
                                for i=0:S-1
                                    z=[ones(length(y_s(1+i:S:end)),1) (1:length(y_s(1+i:S:end)))'];
                                    [y_sn_t0(1+i:S:end),~]=olsd(y_s(1+i:S:end),z);
                                end
                            end
                            y_sn_ts2=y_s;
                            
                            if detrending==1
                                y_sn_ts2=zeros(T,1);
                                for i=0:S-1
                                    z=ones(length(y_s(1+i:S:end)),1);
                                    [y_sn_ts2(1+i:S:end),~]=olsd(y_s(1+i:S:end),z);
                                end
                            end
                            if detrending==2
                                y_sn_ts2=zeros(T,1);
                                for i=0:S-1
                                    z=[ones(length(y_s(1+i:S:end)),1) (1:length(y_s(1+i:S:end)))'];
                                    [y_sn_ts2(1+i:S:end),~]=olsd(y_s(1+i:S:end),z);
                                end
                            end
                            
                            y_sn_F_i=y_s;
                            
                            if detrending==1
                                y_sn_F_i=zeros(T,1);
                                for i=0:S-1
                                    z=ones(length(y_s(1+i:S:end)),1);
                                    [y_sn_F_i(1+i:S:end),~]=olsd(y_s(1+i:S:end),z);
                                end
                            end
                            if detrending==2
                                y_sn_F_i=zeros(T,1);
                                for i=0:S-1
                                    z=[ones(length(y_s(1+i:S:end)),1) (1:length(y_s(1+i:S:end)))'];
                                    [y_sn_F_i(1+i:S:end),~]=olsd(y_s(1+i:S:end),z);
                                end
                            end
                            [sigma_t0,~,~,~,~]=covvar(diff(svec(y_sn_t0,S)));
                            [sigma_ts2,~,~,~,~]=covvar(diff(svec(y_sn_ts2,S)));
                            [sigma_F_i,~,~,~,~]=covvar(diff(svec(y_sn_F_i,S)));
                            
                            [result_est_t0]=hegy_reg_opt(y_sn_t0,S,kmin,kmax,0,[]);
                            est_sigma_t0=result_est_t0.sigma_hat_est;
                            t_0(mc)=result_est_t0.t_0;
                            
                            [result_est_ts2]=hegy_reg_opt(y_sn_ts2,S,kmin,kmax,0,[]);
                            t_s2(mc)=result_est_ts2.t_s2;
                            est_sigma_ts2=result_est_ts2.sigma_hat_est;
                            
                            [result_est_F_i]=hegy_reg_opt(y_sn_F_i,S,kmin,kmax,0,[]);
                            F_i(mc)=result_est_F_i.F_i;
                            est_sigma_F_i=result_est_F_i.sigma_hat_est;
                            
                            F_1s2(mc)=(t_s2(mc)^2+2*F_i(mc))/(S-1);
                            F_0s2(mc)=(t_0(mc)^2+t_s2(mc)^2+2*F_i(mc))/(S);
                            
                            %                             Asymptotics
                            N1=N;
                            [result_t0]=bounded_HEGY_OLS_Critical_val(N1,S,sigma_t0,bl,bu,detrending,1);
                            result_asym_t_0(mc)=result_t0.asym_t_0;
                            
                            [result_ts2]=bounded_HEGY_OLS_Critical_val(N1,S,sigma_ts2,bl,bu,detrending,1);
                            result_asym_t_s2(mc)=result_ts2.asym_t_s2;
                            
                            [result_F_i]=bounded_HEGY_OLS_Critical_val(N1,S,sigma_F_i,bl,bu,detrending,1);
                            result_asym_F_i(mc)=result_F_i.asym_F_i;
                            
                            result_asym_F_1s2(mc)=(result_asym_t_s2(mc)^2+2*result_asym_F_i(mc))/(S-1);
                            result_asym_F_0s2(mc)=(result_asym_t_0(mc)^2+result_asym_t_s2(mc)^2+2*result_asym_F_i(mc))/(S);
                            
                            
                            B=result_est_t0.coeff_lag_delta_S;
                            [result_recolored_t0]=bounded_HEGY_OLS_recolored_Critical_val(N1,S,bl,bu,detrending,1,B,sigma_t0);
                            result_asym_t_0_recolored(mc)=result_recolored_t0.asym_t_0;
                            
                            [result_recolored_ts2]=bounded_HEGY_OLS_recolored_Critical_val(N1,S,bl,bu,detrending,1,B,sigma_ts2);
                            result_asym_t_s2_recolored(mc)=result_recolored_ts2.asym_t_s2;
                            
                            [result_recolored_F_i]=bounded_HEGY_OLS_recolored_Critical_val(N1,S,bl,bu,detrending,1,B,sigma_F_i);
                            result_asym_F_i_recolored(mc)=result_recolored_F_i.asym_F_i;
                            
                            result_asym_F_1s2_recolored(mc)=(result_asym_t_s2_recolored(mc)^2+2*result_asym_F_i_recolored(mc))/(S-1);
                            result_asym_F_0s2_recolored(mc)=(result_asym_t_0_recolored(mc)^2+result_asym_t_s2_recolored(mc)^2+2*result_asym_F_i_recolored(mc))/(S);
                            
                        end
                        
                        if rho==1
                            result_asym_t_0sa=t_0;
                            result_asym_t_s2sa=t_s2;
                            result_asym_F_isa=F_i;
                            result_asym_F_1s2sa=F_1s2;
                            result_asym_F_0s2sa=F_0s2;
                        end
                        rp.t0_recolored(rr,md,bb)=sum(t_0<=quantile(result_asym_t_0_recolored,0.05))/MC;
                        rp.ts2_recolored(rr,md,bb)=sum(t_s2<=quantile(result_asym_t_s2_recolored,0.05))/MC;
                        rp.F_i_recolored(rr,md,bb)=sum(F_i>=quantile(result_asym_F_i_recolored,0.95))/MC;
                        rp.F_1s2_recolored(rr,md,bb)=sum(F_1s2>=quantile(result_asym_F_1s2_recolored,0.95))/MC;
                        rp.F_0s2_recolored(rr,md,bb)=sum(F_0s2>=quantile(result_asym_F_0s2_recolored,0.95))/MC;
                        
                        rp.t0(rr,md,bb)=sum(t_0<=quantile(result_asym_t_0,0.05))/MC;
                        rp.ts2(rr,md,bb)=sum(t_s2<=quantile(result_asym_t_s2,0.05))/MC;
                        rp.F_i(rr,md,bb)=sum(F_i>=quantile(result_asym_F_i,0.95))/MC;
                        rp.F_1s2(rr,md,bb)=sum(F_1s2>=quantile(result_asym_F_1s2,0.95))/MC;
                        rp.F_0s2(rr,md,bb)=sum(F_0s2>=quantile(result_asym_F_0s2,0.95))/MC;
                        
                        rp.t0sa(rr,md,bb)=sum(t_0<=quantile(result_asym_t_0sa,0.05))/MC;
                        rp.ts2sa(rr,md,bb)=sum(t_s2<=quantile(result_asym_t_s2sa,0.05))/MC;
                        rp.F_isa(rr,md,bb)=sum(F_i>=quantile(result_asym_F_isa,0.95))/MC;
                        rp.F_1s2sa(rr,md,bb)=sum(F_1s2>=quantile(result_asym_F_1s2sa,0.95))/MC;
                        rp.F_0s2sa(rr,md,bb)=sum(F_0s2>=quantile(result_asym_F_0s2sa,0.95))/MC;
                        
                        rp.t0_nb(rr,md,bb)=sum(t_0<=quantile(result_asym_nb.t_0,0.05))/MC;
                        rp.ts2_nb(rr,md,bb)=sum(t_s2<=quantile(result_asym_nb.t_s2,0.05))/MC;
                        rp.F_i_nb(rr,md,bb)=sum(F_i>=quantile(result_asym_nb.F_i,0.95))/MC;
                        rp.F_1s2_nb(rr,md,bb)=sum(F_1s2>=quantile(result_asym_nb.F_1s2,0.95))/MC;
                        rp.F_0s2_nb(rr,md,bb)=sum(F_0s2>=quantile(result_asym_nb.F_0s2,0.95))/MC;
                        
                    end
                    
                    bname=num2str(bound);
                    bname=strrep(bname, '.', '_');
                    bname=strrep(bname, '-', 'n');
                    dname=num2str(detrending+1);
                    dname=strrep(dname, '.', '_');
                    dname=strrep(dname, '-', 'n');
                    if asym==1
                        aname='asymmetric';
                    else
                        aname='symmetric';
                    end
                    
                    toc;
                end
            end
            
        end
        savename=['D:\Dropbox\Seasonal Bounded unit roots\results bounded hegy\results_S' num2str(S) '_N_' num2str(N) '_olsdetrend' dname '_model_' num2str(md) aname '_bound_' bname '_F_i'];
        save(savename,'rp');
    end
end


