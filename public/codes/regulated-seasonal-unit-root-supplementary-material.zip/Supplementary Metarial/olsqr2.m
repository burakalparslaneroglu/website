function [beta_OLS,r,fit]=olsqr2(y,x)
if isempty(x)
    beta_OLS=[];
    r=y;
    fit=y-r;
else
    beta_OLS=inv(x'*x)*x'*y;
    r=y-x*beta_OLS;
    fit=x*beta_OLS;
end