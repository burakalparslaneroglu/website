function [kopt]=s2ar(yts,penalty,kmax,kmin);
if kmin==0 & kmax==0;
    kopt=0;
else
nt=size(yts,1);
% min=9999999999;
tau=zeros(kmax+1,1);
s2e=999*ones(kmax+1,1);


dyts=diffk(yts,1);
reg=lagn(yts,1);

i=1;
while i <= kmax;
reg=[reg lagn(dyts,i)];
i=i+1;
end;
dyts0=dyts;
reg0=reg;
% /*loop over k*/
dyts0=trimr(dyts,kmax+1,0);
reg0=trimr(reg,kmax+1,0);
sumy=sum(reg0(:,1).*reg0(:,1));
nef=nt-kmax-1;
k=kmin;
while k <= kmax;
[b,e,fit]=olsqr2(dyts0,reg0(:,1:k+1));
% b=dyts0/reg0(.,1:k+1);
e=dyts0-reg0(:,1:k+1)*b;
s2e(k+1)=e'*e/nef;
tau(k+1)=(b(1)*b(1))*sumy/s2e(k+1);
k=k+1;
end;
kk=(0:1:kmax)';
if penalty == 0;
mic=log(s2e)+2*(kk+tau)./nef;
else;
mic=log(s2e)+ln(nef)*(tau+kk)./nef;
end;
[~,minindc]=min(mic);
kopt=minindc-1;
end

