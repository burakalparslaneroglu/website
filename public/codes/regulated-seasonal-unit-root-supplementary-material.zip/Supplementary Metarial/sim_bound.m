function [y,regl,regu]=sim_bound(eps,bl,bu);
T=length(eps);
regu=zeros(T,1);
regl=zeros(T,1);
if size(bl,1)==1;
bl=bl*ones(T,1);
bu=bu*ones(T,1);
end;
y(1)=eps(1);
if eps(1)>bu(1);
    y(1)=bu(1);
    regu(1)=eps(1)-bu(1);
elseif eps(1)<bl(1);
    y(1)=bl(1);
    regl(1)=-eps(1)+bl(1);
end

for i=2:length(eps)
    s(i)=y(i-1)+eps(i);
    if s(i)<bl(i)
        y(i)=bl(i);
        regl(i)=-s(i)+bl(i);
    elseif s(i)>bu(i)
        y(i)=bu(i);
        regu(i)=s(i)-bu(i);
    else
        y(i)=s(i);
    end
end
if size(y,1)<size(y,2)
    y=y';
end
