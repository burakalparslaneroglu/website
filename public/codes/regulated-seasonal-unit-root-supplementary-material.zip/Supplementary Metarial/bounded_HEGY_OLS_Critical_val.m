function [result]=bounded_HEGY_OLS_Critical_val(N1,S,sigma,bl,bu,detrending,rep)
if isempty(rep)==1
    rep=1;
end
T1=N1*S;
C_0=ones(S,S);
v_s2=((-1).^(1:S))';
C_s2=v_s2*v_s2';
w_1=2*pi*1/S;
v_1=[cos(w_1*(1-S:0));sin(w_1*(1-S:0))]';
v_1_star=[-sin(w_1*(1-S:0));cos(w_1*(1-S:0))]';
C_1=v_1*v_1';
C_1_star=v_1*v_1_star';
for mc=1:rep
    eps0=randn(N1,S);
    eps0=eps0*inv(chol(cov(eps0)));
    eps0=eps0*chol(sigma);
    
    W_star=[];
    DW_star=[];
    cl_hat=bl*ones(S,1);
    cu_hat=bu*ones(S,1);
    
    z=[];
    if detrending==1
        z=ones(N1,1);
    end
    if detrending==2
        z=[ones(N1,1) (1:N1)'];
    end
    
    
    for i=1:S
        W1=sim_bound(eps0(:,i),cl_hat(i),cu_hat(i));
        [W1,~]=olsd(W1,z);
        W_star=[W_star W1];
        DW_star=[DW_star diffk(W1,1)];
    end
    DW_star=DW_star*inv(chol(sigma));
    num_0=0;
    num_s2=0;
    denom_s2=0;
    denom_0=0;
    num_1=0;
    num_1_star=0;
    denom_1=0;
    denom_1_star=0;
    
    for t=2:N1
        denom_0=denom_0+S*(W_star(t-1,:)*C_0*W_star(t-1,:)')/(T1^2);
        denom_s2=denom_s2+S*(W_star(t-1,:)*C_s2*W_star(t-1,:)')/(T1^2);
        num_0=num_0+(W_star(t-1,:)*C_0*DW_star(t,:)')/(T1);
        num_s2=num_s2+(W_star(t-1,:)*C_s2*DW_star(t,:)'/(T1));
        denom_1=denom_1+(S/2)*(W_star(t-1,:)*C_1*W_star(t-1,:)')/(T1^2);
        denom_1_star=denom_1_star+(S/2)*(W_star(t-1,:)*C_1*W_star(t-1,:)')/(T1^2);
        num_1=num_1+(W_star(t-1,:)*C_1*DW_star(t,:)')/(T1);
        num_1_star=num_1_star+(W_star(t-1,:)*C_1_star*DW_star(t,:)'/(T1));
    end
    result.asym_t_0(mc)=num_0/sqrt(denom_0);
    result.asym_t_s2(mc)=num_s2/sqrt(denom_s2);
    result.asym_F_i(mc)=((num_1/sqrt(denom_1))^2+(num_1_star/sqrt(denom_1_star))^2)/2;
    result.asym_F_1s2(mc)=(result.asym_t_s2(mc)^2+2*result.asym_F_i(mc))/(S-1);
    result.asym_F_0s2(mc)=(result.asym_t_0(mc)^2+result.asym_t_s2(mc)^2+2*result.asym_F_i(mc))/(S);
end