These codes are for replicating the results presented in "Regulated seasonal unit root process". 

arima_sim: Simulates an ARIMA(p,q) process
bounded_HEGY_OLS_Critical_val: Simulates the asymptotic distribution of the bounded seasonal unit root tests
bounded_HEGY_OLS_recolored_Critical_val: Simulates the asymptotic distribution of the bounded seasonal unit root tests (recolored version)
covvar: Estimates the long-run variance -covariance matrix of a vector process
diffk: Takes k order difference of the observed series
fracdiff: Fractional differencing function
hegy_critval_ols: Simulates the asymptotic distribution of the standard HEGY seasonal unit root tests
hegy_reg_opt: Estimates the seasonal unit root model and generates the test statistics
hegy_vars: Generates the HEGY transformations
lagn: Generate the k order lag of a time series 
newlagmatrix: Construction of a matrix of lags (X) and a vector (Y) for use in an autoregression
olsd: OLS detrending algorithm
olsqr2: Basic OLS algorithm
Replication_files (main file): Replicates the simulation results in the paper
seasonal_bounded_unit_root_sim_v2: Simulates the regulated seasonal process
sim_bound: Simulates the standard regulated unit root process.
svec: Converts a univariate time series into a seasonal vector process and converts a seasonal vector process into a univariate process
trimr: return a matrix (or vector) x stripped of the specified rows.

