function [y_s,regu,regl]=seasonal_bounded_unit_root_sim_v2(eps,S,roots0,y_s0,bl,bu)
T=length(eps);
y_s=zeros(T,1);
regu=zeros(T,1);
regl=zeros(T,1);
if S==1
    coeffs=[roots0(1);0;0;0];
else
    a1=roots0(1);
    i=1;
    a2=-2*(roots0(2+2*(i-1))*cos(2*pi*i/S)-roots0(3+2*(i-1))*sin(2*pi*i/2));
    a3=(roots0(2+2*(i-1))^2+roots0(3+2*(i-1))^2);
    a4=roots0(end);
    coeffs=[-(a4-a2-a1);-(a3-a2*a4-a1*a4+a1*a2);-(a3*a4+a1*a2*a4-a1*a3);a1*a3*a4];
end
y_s(1:S)=y_s0;
for t=1:S
    laggedy=0;
    if t==2
        laggedy=coeffs(1)*y_s(t-1);
    elseif t==3
        laggedy=coeffs(1)*y_s(t-1)+coeffs(2)*y_s(t-2);
    elseif t==4
        laggedy=coeffs(1)*y_s(t-1)+coeffs(2)*y_s(t-2)+coeffs(3)*y_s(t-3);
    end
    y_s(t)=eps(t)+laggedy;
    if y_s(t)<bl
        regl(t)=bl-y_s(t);
        y_s(t)=bl;
    end
    if y_s(t)>bu
        regu(t)=y_s(t)-bu;
        y_s(t)=bu;
    end
end

for t=S+1:T
    if S==1
        y_s(t)=eps(t)+coeffs(1)*y_s(t-1);
    else
        y_s(t)=eps(t)+coeffs(1)*y_s(t-1)+coeffs(2)*y_s(t-2)+coeffs(3)*y_s(t-3)+coeffs(4)*y_s(t-4);
    end
    if y_s(t)<bl
        regl(t)=bl-y_s(t);
        y_s(t)=bl;
    end
    if y_s(t)>bu
        regu(t)=y_s(t)-bu;
        y_s(t)=bu;
    end
end