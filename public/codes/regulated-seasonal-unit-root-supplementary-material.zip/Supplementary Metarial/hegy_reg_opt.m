function [result]=hegy_reg_opt(y,S,kmin,kmax,penalty,known_sigma)
[y_0,y_s2,y_i,y_i_star]=hegy_vars(y,S);
T=length(y);
delta_S_y=diffk(y,S);
lag_delta_S_y=[];
tau=zeros(kmax+1,1);
s2e=999*ones(kmax+1,1);
for p=1:kmax
    lag_delta_S_y=[lag_delta_S_y lagn(delta_S_y,p)];
end
i_k=size(y_i,2);
i_star_k=size(y_i_star,2);


reg=[y_0 y_s2 y_i y_i_star lag_delta_S_y];


if kmax==0 & kmin==0
    kopt=0;
else
    
    % % % % % % % % % % % % % % % % % % % % % %
    dyts0=delta_S_y;
    reg0=reg;
    % /*loop over k*/
    dyts0=trimr(delta_S_y,kmax+1,0);
    reg0=trimr(reg,kmax+1,0);
    sumy=sum(reg0(:,1).*reg0(:,1));
    nef=T-(kmax+2+i_k+i_star_k)-1;
    k=kmin;
    while k <= kmax;
        [b,e,fit]=olsqr2(dyts0,reg0(:,1:k+2+i_k+i_star_k));
        % b=dyts0/reg0(.,1:k+1);
        e=dyts0-reg0(:,1:k+2+i_k+i_star_k)*b;
        s2e(k+1)=e'*e/nef;
        tau(k+1)=0;
        for i=1:i_k+i_star_k+2
            tau(k+1)=tau(k+1)+(b(i)*b(i)*reg0(:,i)'*reg0(:,i))/s2e(k+1);
        end
        k=k+1;
    end;
    kk=(0:1:kmax)';
    if penalty == 0;
        mic=log(s2e)+2*(kk+tau)./nef;
    else;
        mic=log(s2e)+log(nef)*(tau+kk)./nef;
    end;
    [~,minindc]=min(mic);
    kopt=minindc-1;
    
    result.kopt=kopt;
end

reg=[y_0 y_s2 y_i y_i_star lag_delta_S_y(:,1:kopt)];
% % % % % % % % % % % % % % % % % % % % % %
result.reg=reg;
coeff=(reg'*reg)\(reg'*delta_S_y);
res=delta_S_y-reg*coeff;
result.res=res;
result.fit=reg*coeff;
result.sigma_hat_est=(1/(length(y)-size(reg,2)))*sum(res.^2);
if known_sigma>0
    result.sigma_hat=known_sigma;
else
    result.sigma_hat=result.sigma_hat_est;
end
result.var_mat=result.sigma_hat*inv(reg'*reg);
result.std_errors=sqrt(diag(result.sigma_hat*inv(reg'*reg)));
result.coeff_0=coeff(1);
result.coeff_s2=coeff(2);
result.coeff_i=coeff(3:size(y_i,2)+2);
result.coeff_i_star=coeff(size(y_i,2)+3:size(y_i,2)+2+size(y_i_star,2));
result.coeff_lag_delta_S=coeff(size(y_i,2)+3+size(y_i_star,2):end);

result.t_0=result.coeff_0/result.std_errors(1);
result.t_s2=result.coeff_s2/result.std_errors(2);
result.t_i=result.coeff_i./result.std_errors(3:size(y_i,2)+2);
result.t_i_star=result.coeff_i_star./result.std_errors((size(y_i,2)+3:size(y_i,2)+2+size(y_i_star,2)));
for i=1:i_k
    result.F_i(i)=(result.t_i(i)^2+result.t_i_star(i)^2)/2;
end

result.F_0s2=result.t_0^2+result.t_s2^2;
result.F_1s2=result.t_s2^2;
for i=1:i_k
    result.F_1s2=result.F_1s2+result.t_i(i)^2+result.t_i_star(i)^2;
    result.F_0s2=result.F_0s2+result.t_i(i)^2+result.t_i_star(i)^2;
end
result.F_1s2=result.F_1s2/(S-1);
result.F_0s2=result.F_0s2/S;


