function [ind_BB]=BB_ind(T,m,stationary,varargin)
% Loop over B bootstraps
if ~isempty(varargin)==1
    data=varargin{1};
    mm=opt_block_length_REV_dec07(data);
else
    mm(1)=m;
    mm(2)=m;
end
    
if stationary==0
    m=ceil(mm(2));
    % ceil(T/m) Uniform random numbers over 1...T-m+1
    u = ceil((T-m+1)*rand(ceil(T/m),1));
    u = bsxfun(@plus,u,0:m-1)';
    % Transform to col vector, and remove excess
    u = u(:);
    ind_BB = u(1:T);
    % y-star sample simulation
else
    m=mm(1);
    u(1) = ceil(T*rand);
    for t=2:T
        if rand<1/m
            u(t) = ceil(T*rand);
        else
            u(t) = u(t-1) + 1;
            if u(t)>T
                u(t)=ceil(T*rand);
            end
        end
    end
    ind_BB=u(1:T);
end