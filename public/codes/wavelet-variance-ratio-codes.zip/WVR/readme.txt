These code can be used to replicate the results in 
Eroğlu, B. A. (2019). Wavelet variance ratio cointegration test and wavestrapping.
Journal of Multivariate Analysis. Volume 171, Pages 298-319
The codes author: Burak Alparslan Eroğlu

MAIN FILES:
	example.m: This m file provides an example of the proposed routines in the abovementioned article.
	
AUXILLIARY FILES: 
	BB_ind.m: implements various bootsrap algorithms such as block, stationary block and standard bootsrap
	detrending.m: implements detrending algorithm used in the articl. This function can be replaced with built in detrend 		function of MATLAB
	fracdiff.m: Fast Fractional Integration poposed by "Jensen, A. N., & Nielsen, M. Ø. (2014). A fast fractional 			difference algorithm. Journal of Time Series Analysis, 35(5), 428-436."
	wavestrap.m: conducts wavelet based cointergation test.
	wavestrap_dwt_m1.m: generates wavestrapped data.
	