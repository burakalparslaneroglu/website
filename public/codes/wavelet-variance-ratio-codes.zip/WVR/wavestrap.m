function [rhows]=wavestrap(data,d,level,r,wavelet,dtrndng)
%% This function generates wavestrapped wavelet variance ratio test statistics
%INPUTS: 1) data: Txp data matrix 2) d: fractional integration parameter d1 3) level:
% wavelet level, 4) r: cointegrating rank 5) wavelet: a char indicating
% wavelet filter. 6) dtrndng: 0 if only demeaning, if dtndng=i>0 add t^i as
% trend.
%OUTPUT: rhow: Wavestrapped wavelet variance ratio test statistics
%% 
% detrend the data before applying this function
[Lo_D,Hi_D] = wfilters(wavelet,'d');
T=size(data,1);
p=size(data,2);
%% Obtain the eigen vector from original data
Yn=data';
dataf=[];
% Fractional transform of the original data
for i=1:p
    dataf=[dataf fracdiff(data(:,i),-d)];
end
Yfn=dataf';
ATn=0;
BTn=0;
for i=1:T
    ATn=ATn+Yn(:,i)*Yn(:,i)';
    BTn=BTn+Yfn(:,i)*Yfn(:,i)';
end
[Vn,Dn1] = eig(ATn*inv(BTn));

mat0n=[diag(Dn1)';Vn]';
mat1n=sortrows(mat0n,1)';
Vsn=mat1n(2:end,1:p-r);
%% Obtain the stochastic trends (non-cointegrated cpomponents ) from the original data
Ys=(Yn'*Vsn);
Yss=(Ys)*inv(chol(cov((Ys))));
% Wavestrap according to wavelet packet transform
[yws]=wavestrap_dwt_m1(Ys,level,wavelet);
for ii=1:p-r
    yws(:,ii)=detrending(yws(:,ii),dtrndng);
end
% Wavelet Transform the wavestrapped data.
for ii=1:p-r
    [caws(:,ii),~] = dwt(yws(:,ii),Lo_D,Hi_D);
    ywsf(:,ii)=fracdiff(yws(:,ii),-d);
    cawsf(:,ii)=fracdiff(caws(:,ii),-d);
end
Yws=caws';
Ywsf=cawsf';

BTws=0; ATws=0;
for i=1:length(Yws)
    ATws=ATws+Yws(:,i)*Yws(:,i)';
    BTws=BTws+Ywsf(:,i)*Ywsf(:,i)';
end

[Vws,Dws] = eig(ATws*inv(BTws));
Dws=sort(diag(Dws),'ascend');
% wavestrapper wavelet variance ratio statistic
rhows=(length(Yws)^(2*d))*sum(Dws(1:p-r));

