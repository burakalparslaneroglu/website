%% This code conducts Wavelet Variance Ratio Cointegration Test proposed in 
% Eroğlu, B. A. (2019). Wavelet variance ratio cointegration test and wavestrapping.
% Journal of Multivariate Analysis. Volume 171, Pages 298-319
% The code author: Burak Alparslan Eroğlu
clear
clc

X=cumsum(randn(100,3)); % Please replace X with your observed or simulated data
T=size(X,1);
p=size(X,2);
wavelet='db2'; % You can change wavelet type
    [Lo_D,Hi_D] = wfilters(wavelet,'d');
    level= wmaxlev(T,wavelet)-1;
    B=999; % # of bootstrap iterations
    MC=10000; % # of Monte Carlo simulations to obtain Asymptotic critical values
    dtrndng=-1;% type of deterministic adjustment: -1 no trend or mean, 0 only mean, 1 mean and trend
    d=1; %Integration order of X, see Nielsen (2010). You can estimate this. If you think X~I(1) set d=1.
    if dtrndng==0
        X=demean(X);
    elseif dtrndng==1
        X=detrend(X,'linear');
    end

    
    for r=0:p-1
        % Asymptotic Distribution
        parfor mc=1:MC
            eps=randn(T,p-r);
            eps=eps*inv(chol(cov(eps)));
            yf=[];
            y=[];
            ca=[];
            caf=[];
            for pp=1:p-r
                y0=cumsum(eps(:,pp));
                y0=detrending(y0,dtrndng);
                y=[y y0];
                [ca10,cd1] = dwt(y0,Lo_D,Hi_D);
                ca=[ca ca10];
                yf0=fracdiff(y0,-d);
                yf=[yf yf0];
                caf0=fracdiff(ca10,-d);
                caf=[caf caf0];
            end
            Y=ca';
            Yf=caf';
            AT=0;
            BT=0;
            for i=1:length(Y)
                AT=AT+Y(:,i)*Y(:,i)';
                BT=BT+Yf(:,i)*Yf(:,i)';
            end
            [V,D] = eig(AT*inv(BT));
            D=sort(diag(D),'ascend');
            
            fwer(mc)=(length(Y)^(2*d))*sum(D(1:p-r));
            
        end
        % Asymptotic Distribution
        
        % Testing starts here
        yf=[];
        y=[];
        ca=[];
        caf=[];
        for pp=1:p
            
            y0=detrending(X(:,pp),dtrndng);
            y=[y y0];
            [ca10,cd1] = dwt(y0,Lo_D,Hi_D);
            ca=[ca ca10];
            yf0=fracdiff(y0,-d);
            yf=[yf yf0];
            caf0=fracdiff(ca10,-d);
            caf=[caf caf0];
        end
        Y=ca';
        Yf=caf';
        AT=0;
        BT=0;
        for i=1:length(Y)
            AT=AT+Y(:,i)*Y(:,i)';
            BT=BT+Yf(:,i)*Yf(:,i)';
        end
        [V,D] = eig(AT*inv(BT));
        D=sort(diag(D),'ascend');
        data=y;
        rhow=(length(Y)^(2*d))*sum(D(1:p-r));
        % Wavestrap
        parfor mc=1:B
            [r11]=wavestrap(data,d,level,r,wavelet,dtrndng);
            rhows(mc)=r11;
        end
        % Wavestrap
        rdw(r+1,:)=[(rhow>quantile(fwer,0.95)) sum(rhow<fwer)/MC] ; % Rejection decision and p-values based on asymptotic distribution
        rdws(r+1,:)=[(rhow>quantile(rhows,0.95)) sum(rhow<rhows)/B]; % Rejection decision and p-values based on wavestrap distribution
        rhowall(r+1)=rhow; % Test statistic
        % Testing ends here
    end