function [dx]=fracdiff(x,d)
% See "Jensen, A. N., & Nielsen, M. Ø. (2014). A fast fractional 
% difference algorithm. Journal of Time Series Analysis, 35(5), 428-436.
T=length(x);
np2=2.^nextpow2(2*T-1);
k=(1:T-1)';
b=[1;cumprod((k-d-1)./k)];
dx=ifft(fft(x,np2).*fft(b,np2));
dx=dx(1:T,:);

