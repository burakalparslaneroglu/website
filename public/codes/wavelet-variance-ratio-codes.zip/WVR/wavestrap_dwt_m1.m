function yb=wavestrap_dwt_m1(y0,level,wavelet)
% This function generates wavestrapped data
% INPUTS: 1) y0: Txp data 2) level: wavelet level, 3) wavelet: a char
% indicating wavelet filter.
%OUTPUTS: yb: wavestrapped data.

y=[diff(y0)]; % take the first difference of the originald ata
DEC = mdwtdec('c',y,level,wavelet); % compute the DWT based wavelet packed transform.

for i=1:level
    T=size(DEC.cd{1,i},1);
    ind=BB_ind(T,1,0); % obtain bootstrapping index
    DEC.cd{1,i}=DEC.cd{1,i}(ind,:); % obtain bootstrapped wavelet components.
end
yb= mdwtrec(DEC); % reconstruct the series.

yb=cumsum([y0(1,:);yb]); % integrate to obtain the wavestrapped version of the original series

