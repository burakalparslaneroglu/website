
# This code replicates the results in the paper


rm(list=ls(all=TRUE))
library(FKF)
library(foreach)
library(doParallel)
library("dplyr")
library("ggpubr")
library(ggplot2)
library("gridExtra")

# Set directory
directory="D:/Dropbox/RKAL"
setwd(directory)
#setup parallel backend to use many processors
cores=detectCores()
cl <- makeCluster(cores[1]-1) #not to overload your computer
registerDoParallel(cl)

source('kal_fun2.R')

funs=c('boots_Q','inverse_AR1','boots_theta','objective_Q','objective_theta','objective','TVPss_Q','TVPss_theta','TVPss','arima_sim'
       ,'arima_sim_w','lagn','objective_thetaQ','TVPss_thetaQ','boots_thetaQ','roots.to.poly','nwwhit','park.hahn.TVC.test')

for (jjj in 2:2){ 
  ptime<-system.time({
    RAW<-read.csv(file=paste0("TVSpur2.csv"))
    
    x=data.matrix(RAW[,2+jjj], rownames.force = NA)
    y=data.matrix(RAW[,2], rownames.force = NA)
    n=dim(x)[2]
    T=dim(x)[1]
    params=matrix(rep(0,13*(6+n-1+12)),ncol = 13)
    sic=matrix(rep(0,13,ncol = 13))
    for (lags in 0:12){
      count=0
      a0 <- c(0.47,rep(0,(lags+1)))
      P0 <- diag(2+lags)
      parT<-0
      repeat{
        if (count==1 && parT>=0)  break
        
        theta <- c(rnorm(1,mean = 0,sd=0.5),(runif(1,min=0,max=1)),runif(1,min=-1,max=1),rnorm(1,mean = 0,sd=0.5),
                   (runif(1,min=0,max=0.4)),runif(1,min=-1,max=1))
        theta<- cbind(matrix(theta,ncol=6),t(rnorm(lags,mean=0,sd=0.5)),t(rnorm(n-1,mean=0,sd=1)))
        fit <- try({optim(theta, objective,y=y,x=x,T=T,method='BFGS',lags=lags,a0=a0,P0=P0, hessian = TRUE)}, silent=TRUE)
        
        hes<-try({solve(fit$hessian)},silent=TRUE)
        if ('try-error' %in% class(fit) |'try-error' %in% class(hes)) next
        else{
          count=1
          parT<-fit$par[3]
        }
      }
      
      params[1:dim(fit$par)[2],(lags+1)]=fit$par
      yt=t(y)
      sp <- TVPss(x,fit$par,T,lags,a0,P0)
      ans <- fkf(a0 = sp$a0, P0 = sp$P0, dt = sp$dt, ct = sp$ct, Tt = sp$Tt,
                 Zt = sp$Zt, HHt = sp$HHt, GGt = sp$GGt, yt = yt)
      
      sic[lags+1]=-2*ans$logLik+dim(fit$par)[2]*log(T)
    }
    optlag=which(sic==min(sic))
    pars=params[params[,optlag]!=0,(optlag)]
    lags=optlag-1
    yt=t(y)
    a0 <- c(0.47,rep(0,(lags+1)))
    P0 <- diag(2+lags)
    sp <- TVPss(x,pars,T,lags,a0,P0)
    ans <- fkf(a0 = sp$a0, P0 = sp$P0, dt = sp$dt, ct = sp$ct, Tt = sp$Tt,
               Zt = sp$Zt, HHt = sp$HHt, GGt = sp$GGt, yt = yt)
    B<-999
    
    par_pos=6
    par_val_theta=1
    par_val_Q=0
    comb <- function(...) {
      mapply('cbind', ..., SIMPLIFY=FALSE)
    }
    MC=1
    
    param_ests=list()
    tempparam_est={}
    tempparam_est0=matrix(rep(0,3*(6+lags+n-1)+2),nrow=3*(6+lags+n-1)+2,ncol=1)
    
    count<-0
    parT<-0
    repeat{
      if (count==1 && parT>=0) break
      
      
      theta <- c(0,(1+runif(1,min=0,max=0.2)),runif(1,min=-1,max=1),runif(1,min=-1,max=1),(runif(1,min=0,max=0.4)),runif(1,min=-1,max=1))
      theta<- cbind(matrix(theta,ncol=6),t(rnorm(lags,mean=0,sd=0.2)),t(rnorm(n-1,mean=0,sd=1)))
      
      
      fit <- try({optim(theta, objective,y=y,x=x,T=T,method='BFGS',lags=lags,a0=a0,P0=P0, hessian = TRUE)}, silent=TRUE)
      
      hes<-try({solve(fit$hessian)},silent=TRUE)
      if ('try-error' %in% class(fit) |'try-error' %in% class(hes)) next
      else {
        fit<-fit
        parT<-fit$par[3]
        tempparam_est0[1:(lags+6),1]<-fit$par
        sd=matrix(diag(solve(fit$hessian)),nrow=(lags+6),ncol=1)
        if (any(sd<0)==TRUE) next
        tempparam_est0[(lags+7):(2*(lags+6)),1]<-sd
        for (i in 1:(lags+6)){
          tempparam_est0[(2*(lags+6)+i),1]=(fit$par[i])/sqrt(sd[i])
          if (i==2|i==5){
            tempparam_est0[(2*(lags+6)+i),1]=((fit$par[i])^2)/sqrt((4*(fit$par[i])^2)*(sd[i]))  
          }
          
        }
        tempparam_est0[(2*lags+18),1]=(fit$par[6]-1)/sqrt(sd[6])
        sd2=matrix(solve(fit$hessian),ncol=lags+6)
        sd2=sd2[5:6,5:6]
        rb=matrix(c((fit$par[6]-par_val_theta),fit$par[5]),ncol=1)
        tempparam_est0[(3*(6+lags)+1)]=t(rb)%*%solve(sd2)%*%rb/T
        tempparam_est0[(3*(lags+6)+2)]=matrix(fit$convergence)
        if (any(is.nan(tempparam_est0))==TRUE) next
        else {
          result_theta<-try({boots_theta(y,x,T,fit$par,par_val_theta,1,lags,a0,P0)},silent=TRUE)
          result_Q<-try({boots_Q(y,x,T,fit$par,par_val_Q,1,lags,a0,P0)},silent=TRUE)
          result_thetaQ<-try({boots_thetaQ(y,x,T,fit$par,par_val_theta,par_val_Q,1,lags,a0,P0)},silent=TRUE)
          if (any(is.nan(result_theta))==TRUE | any(is.nan(result_thetaQ))==TRUE |any(is.nan(result_Q))==TRUE | 'try-error' %in% class(result_theta) |'try-error' %in% class(result_thetaQ) |'try-error' %in% class(result_Q)) next
          
          else count=1
        }
        
      }
    }
    
    yt=t(y)
    sp <- TVPss(x,fit$par,T,lags,a0,P0)
    ans <- fkf(a0 = sp$a0, P0 = sp$P0, dt = sp$dt, ct = sp$ct, Tt = sp$Tt,
               Zt = sp$Zt, HHt = sp$HHt, GGt = sp$GGt, yt = yt)
    
    data0=t(ans$vt)
    # pt1=ggdensity(data0, 
    #           main = "Density plot of residuals",
    #           xlab = "Tooth length")
    pt1<-hist(data0, probability=TRUE, breaks=10, col="red", xlab="Residuals",
              main="Histogram of Empirical Distribution")
    x <- seq(min(data0), max(data0), length=40)
    hx <- dnorm(x,mean(data0),sd(data0))
    lines(x,hx, col="blue", lwd=2)
    pt2=ggqqplot(data0)
    
    # windows()
    # grid.arrange(pt1, pt2, nrow=2)
    shapiro.test(data0)
    
    tempparam_est<-tempparam_est0
    param_est <- foreach(mcs=1:MC,  .combine='comb', .multicombine=TRUE,.packages='FKF')%dopar% {
      
      count<-0
      repeat{
        if (count==1) break
        result_theta<-try({boots_theta(y,x,T,fit$par,par_val_theta,B,lags,a0,P0)},silent=TRUE)
        result_Q<-try({boots_Q(y,x,T,fit$par,par_val_Q,B,lags,a0,P0)},silent=TRUE)
        result_thetaQ<-try({boots_thetaQ(y,x,T,fit$par,par_val_theta,par_val_Q,B,lags,a0,P0)},silent=TRUE)
        if (any(is.nan(result_theta))==TRUE | any(is.nan(result_thetaQ))==TRUE |any(is.nan(result_Q))==TRUE | 'try-error' %in% class(result_theta) |'try-error' %in% class(result_thetaQ) |'try-error' %in% class(result_Q)) next
        else count=1
      }
      list(result_theta,result_Q,result_thetaQ)
    }
    
    
  })
  tstat_theta=tempparam_est
  tstat_theta=tstat_theta[(2*(6+lags+n-1)+6),]
  par_est=param_est[[1]]
  tstat_boot_theta=c(tstat_theta,par_est[(2*(6+lags+n-1)+6),])
  pval_theta=sum(tstat_theta>tstat_boot_theta)/(B+1)
  if (tstat_theta<=quantile(tstat_boot_theta,prob=0.05)) print(paste0('Reject the null of theta=1 with  p value= ',pval_theta)) else print(paste0('Do not Reject the null of theta=1 with  p value= ',pval_theta))
  
  
  tstat_Q=tempparam_est
  tstat_Q=tstat_Q[(2*(6+lags+n-1)+5),]
  par_est=param_est[[2]]
  tstat_boot_Q=c(tstat_Q,par_est[(2*(6+lags+n-1)+5),])
  pval_Q=sum(tstat_Q<tstat_boot_Q)/(B+1)
  if (tstat_Q>=quantile(tstat_boot_Q,prob=0.95)) print(paste0('Reject the null of Q=0 with  p value= ',pval_Q)) else print(paste0('Do not Reject the null of Q=0 with  p value= ',pval_Q))
  
  tstat_thetaQ=tempparam_est
  tstat_thetaQ=tstat_thetaQ[(3*(6+lags+n-1)+1),]
  tstat_boot_thetaQ=c(tstat_thetaQ,param_est[[3]][(3*(6+lags+n-1)+1),])
  pval_thetaQ=sum(tstat_thetaQ<tstat_boot_thetaQ)/(B+1)
  if (tstat_thetaQ>=quantile(tstat_boot_thetaQ,prob=0.95)) print(paste0('Reject the null of theta=1 and Q=0 with  p value= ',pval_thetaQ)) else print(paste0('Do not Reject the null of theta=1 and Q=0 with  p value= ',pval_thetaQ))
}
stopCluster(cl)
print(ptime)