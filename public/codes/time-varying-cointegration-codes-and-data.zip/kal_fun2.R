############################# All relevant Functions #################################

nwwhit<-function(uv,l) {
  n=nrow(uv);
  omeo=t(uv)%*%uv*(1/n)
  j=1
  while (j<l){
    w=1-j/l;
    ome=t(uv[(j+1):n,])%*%(uv[1:(n-j),]*(1/n)) 
    omeo=omeo+w*(ome+t(ome))
    j = j + 1
  }
  return(omeo)
}


park.hahn.TVC.test<-function(y,x,T){
  ########## FC residuals ###########
  xmat<-cbind(rep(1,T),x)
  bols.fc=solve(t(xmat)%*%xmat)%*%(t(xmat)%*%y)
  res.fc=y-xmat%*%bols.fc
  rss.res.fc=t(res.fc)%*%res.fc
  st=cumsum(res.fc)
  ########## FC residuals ###########
  
  ########## FC Superflous residuals ###########
  trend=matrix(seq(from=1,to=T,by=1))/T
  xmat.sup<-cbind(rep(1,T),x,trend,trend^2,trend^3,trend^4)
  bols.fc.sup=solve(t(xmat.sup)%*%xmat.sup)%*%(t(xmat.sup)%*%y)
  res.fc.sup=y-xmat.sup%*%bols.fc.sup
  rss.res.fc.sup=t(res.fc.sup)%*%res.fc.sup
  ########## FC Superflous residuals ###########
  
  ########## TVC residuals ###########
  xmatf=cbind(rep(1,T),trend,(trend)^2,cos(2*pi*trend),sin(2*pi*trend),cos(4*pi*trend),sin(4*pi*trend))
  xmat.tvc<-matrix(rep(0,ncol(xmatf)*T),ncol=ncol(xmatf))
  for (i in 1:ncol(xmatf)){
    xmat.tvc[,i]<-x*xmatf[,i]
  }
  # xmat.tvc=cbind(rep(1,T),xmat.tvc)
  
  bols.tvc=solve(t(xmat.tvc)%*%xmat.tvc)%*%(t(xmat.tvc)%*%y)
  res.tvc=y-xmat.tvc%*%bols.tvc
  rss.res.tvc=t(res.tvc)%*%res.tvc
  vcov=nwwhit(res.tvc,(T^(1/3))) 
  ########## TVC residuals ###########
  
  ########## TVC Superflous residuals ###########
  xmat.tvc.sup<-cbind(xmat.tvc,trend,trend^2,trend^3,trend^4)
  bols.tvc.sup=solve(t(xmat.tvc.sup)%*%xmat.tvc.sup)%*%(t(xmat.tvc.sup)%*%y)
  res.tvc.sup=y-xmat.tvc.sup%*%bols.tvc.sup
  rss.res.tvc.sup=t(res.tvc.sup)%*%res.tvc.sup
  ########## TVC Superflous residuals ###########
  
  ########## Tests ###########
  phtau1=(rss.res.fc-rss.res.fc.sup)/vcov
  phtau2=sum(st^2)/(vcov*T^2)
  phtau=(rss.res.tvc-rss.res.tvc.sup)/vcov
  ########## Tests ###########
  return(cbind(phtau1,phtau2,phtau))
}

roots.to.poly<-function(z){
  
  n=length(z)
  p = matrix(rep(0,n+1)); 
  p[1] = 1;
  for (j in 1:n){
    p[2:(j+1)] = p[2:(j+1)]-z[j]*p[1:j];
  }
  
  coeffs=p[2:(n+1)]
  return(coeffs)
}
################ ARMA Simulation ##################
arima_sim<-function(eps_0,ar_coeff,ma_coeff){
  
  eps_0=matrix(eps_0)
  T=nrow(eps_0)
  ar_coeff<-matrix(ar_coeff)
  ma_coeff<-matrix(ma_coeff)
  ar_lag<-length(ar_coeff)
  ma_lag<-length(ma_coeff)
  max_lag<-max(c(ar_lag,ma_lag))
  
  y=matrix(rep(0,T+max_lag),nrow = T+max_lag,ncol = 1)
  eps=matrix(rbind(matrix(rep(0,max_lag),nrow = max_lag,ncol = 1),eps_0))
  
  for (i in (max_lag+1):(T+max_lag)){
    for (p in 1:ar_lag)y[i]=y[i]+ar_coeff[p]*y[i-p]
    for (q in 1:ma_lag)y[i]=y[i]+ma_coeff[q]*eps[i-p]
    y[i]=y[i]+eps[i]
  }
  return(y=matrix(y[(max_lag+1):(T+max_lag)]))
}

################ ARMA Simulation for w_t ##################
arima_sim_w<-function(eps_0,ar1_coeff,ar_coeff){
  
  eps_0=matrix(eps_0)
  T=nrow(eps_0)
  ar_coeff<-matrix(ar_coeff)
  ar_lag<-length(ar_coeff)
  max_lag<-ar_lag+1
  
  y=matrix(rep(0,T+max_lag),nrow = T+max_lag,ncol = 1)
  eps=matrix(rbind(matrix(rep(0,max_lag),nrow = max_lag,ncol = 1),eps_0))
  
  for (i in (max_lag+1):(T+max_lag)){
    y[i]=y[i]+ar1_coeff*y[i-1]
    for (q in 1:ar_lag)y[i]=y[i]+ar_coeff[q]*(y[i-q]-y[i-q-1])
    y[i]=y[i]+eps[i]
  }
  return(y=matrix(y[(max_lag+1):(T+max_lag)]))
}

######### Create a state space representation out of the TVP###################
TVPss <- function(x,pars,T,lags,a0,P0) {
  # Tt: State transition matrix
  Tt<-matrix(rep(0,(lags+2)^2),ncol=lags+2)
  Tt[1,]=cbind(pars[3],t(rep(0,lags+1)))
  if (lags>0){
    Tt[2,]=cbind(0,pars[6],t(pars[7:(lags+6)]))
    Tt[3,]=cbind(0,pars[6]-1,t(pars[7:(lags+6)]))
    if (lags>1){
      Tt[4:(2+lags),3:(2+(lags-1))]=(diag(rep(1,(lags-1))))
    }
  } else Tt[2,]=cbind(0,pars[6])
  # Z_t: Measurement observation vector y_t=Z_r\times state
  if (lags>0) xones=rbind(t(x),matrix(rep(1,T),nrow=1,ncol=T),matrix(rep(0,(lags*T)),nrow=lags,ncol=T)) else xones=rbind(t(x),matrix(rep(1,T),nrow=1,ncol=T))
  Zt <- array(data=xones,dim=c(1,(2+lags),T))
  # ct: measurement constant (this corresponds to intercept term in regression)
  ct <- matrix(pars[1])
  # dt: transition intercept terms
  dt <- matrix(cbind(pars[4],0,t(rep(0,lags))), nrow = (2+lags))
  # GGt: variance of measurement equation noise
  GGt <- matrix(0)
  # HHt<-matrix(rep(0,(lags+2)^2),ncol=lags+2)
  # Rt: multiplacative term of state noise
  Rt=matrix(rep(0,2*(2+lags)),ncol=2)
  Rt[1,1]=1
  Rt[2:(2+1*((lags>0))),2]=1
  Qt=diag(c((pars[5])^2,(pars[2])^2))
  # HHt: variance of state noise
  HHt=Rt%*%Qt%*%t(Rt)
  #  initial condtions
  if (is.null(a0)) a0 <- (rep(0,2+lags))
  if (is.null(P0)) P0 <- diag(2+lags)
  return(list(a0 = a0, P0 = P0, ct = ct, dt = dt, Zt = Zt, Tt = Tt, GGt = GGt,
              HHt = HHt))
}

######### Create a state space representation out of the TVP with given theta###################
TVPss_theta <- function(x,pars,T,val_theta,lags,a0,P0) {
  Tt<-matrix(rep(0,(lags+2)^2),ncol=lags+2)
  Tt[1,]=cbind(pars[3],t(rep(0,lags+1)))
  if (lags>0){
    Tt[2,]=cbind(0,val_theta,t(pars[6:(lags+5)]))
    Tt[3,]=cbind(0,val_theta-1,t(pars[6:(lags+5)]))
    if (lags>1){
      Tt[4:(2+lags),3:(2+(lags-1))]=(diag(rep(1,(lags-1))))
    }
  } else Tt[2,]=cbind(0,val_theta)
  if (lags>0) xones=rbind(t(x),matrix(rep(1,T),nrow=1,ncol=T),matrix(rep(0,(lags*T)),nrow=lags,ncol=T)) else xones=rbind(t(x),matrix(rep(1,T),nrow=1,ncol=T))
  Zt <- array(data=xones,dim=c(1,(2+lags),T))
  ct <- matrix(pars[1])
  dt <- matrix(cbind(pars[4],0,t(rep(0,lags))), nrow = (2+lags))
  GGt <- matrix(0)
  Rt=matrix(rep(0,2*(2+lags)),ncol=2)
  Rt[1,1]=1
  Rt[2:(2+1*((lags>0))),2]=1
  Qt=diag(c((pars[5])^2,(pars[2])^2))
  HHt=Rt%*%Qt%*%t(Rt)
  # HHt <- H %*% t(H)
  if (is.null(a0)) a0 <- (rep(0,2+lags))
  if (is.null(P0)) P0 <- diag(2+lags)
  return(list(a0 = a0, P0 = P0, ct = ct, dt = dt, Zt = Zt, Tt = Tt, GGt = GGt,
              HHt = HHt))
}
################# SS for theta and Q joint bootstrap
TVPss_thetaQ <- function(x,pars,T,val_theta,val_Q,lags,a0,P0) {
  Tt<-matrix(rep(0,(lags+2)^2),ncol=lags+2)
  Tt[1,]=cbind(pars[3],t(rep(0,lags+1)))
  if (lags>0){
    Tt[2,]=cbind(0,val_theta,t(pars[5:(lags+4)]))
    Tt[3,]=cbind(0,val_theta-1,t(pars[5:(lags+4)]))
    if (lags>1){
      Tt[4:(2+lags),3:(2+(lags-1))]=(diag(rep(1,(lags-1))))
    }
  } else Tt[2,]=cbind(0,val_theta)
  if (lags>0) xones=rbind(t(x),matrix(rep(1,T),nrow=1,ncol=T),matrix(rep(0,(lags*T)),nrow=lags,ncol=T)) else xones=rbind(t(x),matrix(rep(1,T),nrow=1,ncol=T))
  Zt <- array(data=xones,dim=c(1,(2+lags),T))
  ct <- matrix(pars[1])
  dt <- matrix(cbind(pars[4],0,t(rep(0,lags))), nrow = (2+lags))
  GGt <- matrix(0)
  Rt=matrix(rep(0,2*(2+lags)),ncol=2)
  Rt[1,1]=1
  Rt[2:(2+1*((lags>0))),2]=1
  Qt=diag(c((val_Q)^2,(pars[2])^2))
  HHt=Rt%*%Qt%*%t(Rt)
  # HHt <- H %*% t(H)
  if (is.null(a0)) a0 <- (rep(0,2+lags))
  if (is.null(P0)) P0 <- diag(2+lags)
  return(list(a0 = a0, P0 = P0, ct = ct, dt = dt, Zt = Zt, Tt = Tt, GGt = GGt,
              HHt = HHt))
}

######### Create a state space representation out of the TVP with given Q###################
TVPss_Q <- function(x,pars,T,val_Q,lags,a0,P0) {
  Tt<-matrix(rep(0,(lags+2)^2),ncol=lags+2)
  Tt[1,]=cbind(pars[3],t(rep(0,lags+1)))
  if (lags>0){
    Tt[2,]=cbind(0,pars[5],t(pars[6:(lags+5)]))
    Tt[3,]=cbind(0,pars[5]-1,t(pars[6:(lags+5)]))
    if (lags>1){
      Tt[4:(2+lags),3:(2+(lags-1))]=(diag(rep(1,(lags-1))))
    }
  } else Tt[2,]=cbind(0,pars[5])
  if (lags>0) xones=rbind(t(x),matrix(rep(1,T),nrow=1,ncol=T),matrix(rep(0,(lags*T)),nrow=lags,ncol=T)) else xones=rbind(t(x),matrix(rep(1,T),nrow=1,ncol=T))
  Zt <- array(data=xones,dim=c(1,(2+lags),T))
  ct <- matrix(pars[1])
  dt <- matrix(cbind(pars[4],0,t(rep(0,lags))), nrow = (2+lags))
  GGt <- matrix(0)
  Rt=matrix(rep(0,2*(2+lags)),ncol=2)
  Rt[1,1]=1
  Rt[2:(2+1*((lags>0))),2]=1
  Qt=diag(c(val_Q^2,(pars[2])^2))
  HHt=Rt%*%Qt%*%t(Rt)
  if (is.null(a0)) a0 <- (rep(0,2+lags))
  if (is.null(P0)) P0 <- diag(2+lags)
  return(list(a0 = a0, P0 = P0, ct = ct, dt = dt, Zt = Zt, Tt = Tt, GGt = GGt,
              HHt = HHt))
}

############# The objective function passed to 'optim': this creates -likelihood #########################
objective <- function(theta,y,x,T,lags,a0,P0) {
  yt=t(y)
  sp <- TVPss(x,theta,T,lags,a0,P0)
  ans <- fkf(a0 = sp$a0, P0 = sp$P0, dt = sp$dt, ct = sp$ct, Tt = sp$Tt,
             Zt = sp$Zt, HHt = sp$HHt, GGt = sp$GGt, yt = yt)
  return(-ans$logLik)
}

############# The objective function passed to 'optim' for theta#########################
objective_theta <- function(theta,y,x,T,val_theta,lags,a0,P0) {
  yt=t(y)
  sp <- TVPss_theta(x,theta,T,val_theta,lags,a0,P0)
  ans <- fkf(a0 = sp$a0, P0 = sp$P0, dt = sp$dt, ct = sp$ct, Tt = sp$Tt,
             Zt = sp$Zt, HHt = sp$HHt, GGt = sp$GGt, yt = yt)
  return(-ans$logLik)
}
############# The objective function passed to 'optim' for theta and Q joint#########################
objective_thetaQ <- function(theta,y,x,T,val_theta,val_Q,lags,a0,P0) {
  yt=t(y)
  sp <- TVPss_thetaQ(x,theta,T,val_theta,val_Q,lags,a0,P0)
  ans <- fkf(a0 = sp$a0, P0 = sp$P0, dt = sp$dt, ct = sp$ct, Tt = sp$Tt,
             Zt = sp$Zt, HHt = sp$HHt, GGt = sp$GGt, yt = yt)
  return(-ans$logLik)
}

############ Lag Operator with zero initial values ################################
lagn<-function(data,lags){
  T=dim(data)[1]
  p=dim(data)[2]
  dataf=matrix(rep(0,(p*T)),nrow=T)
  for (ii in 1:p){
    dataf[(1+lags):T,ii]<-data[1:(T-lags),ii]
  }
  return(dataf)
}

############# The objective function passed to 'optim' for Q#########################
objective_Q <- function(theta,y,x,T,val_Q,lags,a0,P0) {
  yt=t(y)
  sp <- TVPss_Q(x,theta,T,val_Q,lags,a0,P0)
  ans <- fkf(a0 = sp$a0, P0 = sp$P0, dt = sp$dt, ct = sp$ct, Tt = sp$Tt,
             Zt = sp$Zt, HHt = sp$HHt, GGt = sp$GGt, yt = yt)
  return(-ans$logLik)
}
############ Bootstrapping H0:\theta=1 ##############################
boots_theta<-function(y,x,T,params,par_val,B,lags,a0,P0){
  yt=t(y)
  #  initial conditions for optimization
  theta <- c(params[1]+rnorm(n=1,mean=0,sd=0.1),params[2]+runif(n=1,min=0,max=0.1),params[3]-runif(n=1,min=0,max=0.2),
             params[4]+rnorm(n=1,mean=0,sd=0.1),params[5]+runif(n=1,min=0,max=0.1))
  theta <- cbind(matrix(theta,ncol=5),t(params[(7):(6+lags)]+rnorm(lags,mean=0,sd=0.2)))
  # theta[par_pos]=par_val
  #  estimate the model with \theta=1
  fit <- try({optim(theta, objective_theta, method="BFGS",y=y,x=x,T=T,val_theta=par_val,lags=lags,a0=a0,P0=P0, hessian = TRUE)}, silent=TRUE)
  param_theta=fit$par
  sp <- TVPss_theta(x,param_theta,T,par_val,lags,a0,P0)
  kal <- fkf(a0 = sp$a0, P0 = sp$P0, dt = sp$dt, ct = sp$ct, Tt = sp$Tt,
             Zt = sp$Zt, HHt = sp$HHt, GGt = sp$GGt, yt = yt)
  #  obtain the serially uncorrelated residuals from w_t=w_{t-1}+\gamma \Delta w_{t-1}+....+eps_est_t
  eps_est0=matrix(rbind(kal$att[2,1],matrix(diff(kal$att[2,]))),nrow=T,ncol=1)
  eps_est=eps_est0
  if (lags>0){
    for (j in 1:lags){
      eps_est=eps_est-(fit$par[5+j])*lagn(eps_est0,j)
    }
  }
  eps_est=(eps_est-mean(eps_est))/sd(eps_est)
  tempparam_est_star=matrix(rep(0,(3*(6+lags)+2)*B),nrow=(3*(6+lags)+2),ncol=B)
  bb=1
  count1<-0
  while (bb<=B){
    # count1<-count1+1
    # if (count1>3) break
    
    count<-0
    count2<-0
    repeat{
      # resample residuals 
      eps_star0<-sample(eps_est, T, replace = TRUE, prob = NULL)
      #  reconstruct w_t
      if (lags>0) w_star<-matrix(arima_sim_w(eps_star0,par_val,param_theta[6:(5+lags)]),nrow=T) else w_star<-matrix(arima_sim_w(eps_star0,par_val,0),nrow=T)
      # reconstruct y
      y_star<-param_theta[1]+matrix(kal$att[1,])*x+w_star
      
      count2=count2+1
      if (count==1 | count2==10) break
      
      theta <- c(params[1]+rnorm(n=1,mean=0,sd=0.1),params[2]+runif(n=1,min=0,max=0.1),params[3]-runif(n=1,min=0,max=0.02),
                 params[4]+rnorm(n=1,mean=0,sd=0.1),params[5]+runif(n=1,min=0,max=0.1),params[6]-runif(n=1,min=0,max=0.02))
      theta <- cbind(matrix(theta,ncol=6),t(params[(7):(6+lags)]+rnorm(lags,mean=0,sd=0.2)))
      # theta[par_pos]=par_val
      fit <- try({optim(theta, objective, method="BFGS",y=y_star,x=x,T=T,lags=lags,a0=a0,P0=P0, hessian = TRUE)}, silent=TRUE)
      hes<-try({solve(fit$hessian)},silent=TRUE)
      if ('try-error' %in% class(fit) |'try-error' %in% class(hes)) next
      else {
        fit<-fit
        tempparam_est_star[1:(6+lags),bb]<-fit$par
        sd=matrix(diag(solve(fit$hessian)),nrow=(6+lags),ncol=1)
        if (any(sd<0)==TRUE) next
        tempparam_est_star[(7+lags):(2*(6+lags)),bb]<-sd
        for (i in 1:(lags+6)){
          tempparam_est_star[(2*(lags+6)+i),bb]=(fit$par[i])/sqrt(sd[i])
          if (i==2|i==5){
            tempparam_est_star[(2*(lags+6)+i),bb]=((fit$par[i])^2)/sqrt((4*(fit$par[i])^2)*(sd[i]))  
          }
          
        }
        tempparam_est_star[(2*(6+lags))+6,bb]=(fit$par[6]-par_val)/sqrt(sd[6])
        sd2=matrix(solve(fit$hessian),ncol=lags+6)
        sd2=sd2[5:6,5:6]
        rb=matrix(c((fit$par[6]-par_val),fit$par[5]),ncol=1)
        tempparam_est_star[(3*(6+lags)+1),bb]=t(rb)%*%solve(sd2)%*%rb/T
        tempparam_est_star[(3*(6+lags)+2),bb]=matrix(fit$convergence)
        if (any(is.nan(tempparam_est_star))==TRUE ) next
        else count=1
      }
      
      
    }
    if (all(tempparam_est_star[,bb]==0)) bb=bb
    else bb=bb+1
  }
  return(result=tempparam_est_star)
}

############ Bootstrapping theta ##############################
boots_thetaQ<-function(y,x,T,params,par_val_t,par_val_Q,B,lags,a0,P0){
  yt=t(y)
  
  theta <- c(params[1]+rnorm(n=1,mean=0,sd=0.1),params[2]+runif(n=1,min=0,max=0.1),params[3]-runif(n=1,min=0,max=0.2),
             params[4]+rnorm(n=1,mean=0,sd=0.1))
  theta <- cbind(matrix(theta,ncol=4),t(params[(7):(6+lags)]+rnorm(lags,mean=0,sd=0.2)))
  # theta[par_pos]=par_val
  fit <- try({optim(theta, objective_thetaQ, method="BFGS",y=y,x=x,T=T,val_theta=par_val_t,val_Q=par_val_Q,lags=lags, a0=a0,P0=P0,hessian = TRUE)}, silent=TRUE)
  param_thetaQ=fit$par
  sp <- TVPss_thetaQ(x,param_thetaQ,T,par_val_t,par_val_Q,lags,a0,P0)
  kal <- fkf(a0 = sp$a0, P0 = sp$P0, dt = sp$dt, ct = sp$ct, Tt = sp$Tt,
             Zt = sp$Zt, HHt = sp$HHt, GGt = sp$GGt, yt = yt)
  
  eps_est0=matrix(kal$att[2,],nrow=T,ncol=1)
  eps_est=eps_est0-par_val_t*lagn(eps_est0,1)
  d_eps_est0=matrix(rbind(kal$att[2,1],matrix(diff(kal$att[2,]))),nrow=T,ncol=1)
  if (lags>0){
    for (j in 1:lags){
      eps_est=eps_est-(param_thetaQ[4+j])*lagn(eps_est0,j)
    }
  }
  eps_est=(eps_est-mean(eps_est))/sd(eps_est)
  tempparam_est_star=matrix(rep(0,(3*(6+lags)+2)*B),nrow=(3*(6+lags)+2),ncol=B)
  bb=1
  count1<-0
  while (bb<=B){
    # count1<-count1+1
    # if (count1>3) break
    
    count<-0
    count2<-0
    repeat{
      eps_star0<-sample(eps_est, T, replace = TRUE, prob = NULL)
      if (lags>0) w_star<-matrix(arima_sim_w(eps_star0,par_val_t,param_thetaQ[5:(4+lags)]),nrow=T) else w_star<-matrix(arima_sim_w(eps_star0,par_val_t,0),nrow=T)
      y_star<-param_thetaQ[1]+matrix(kal$att[1,])*x+w_star
      
      count2=count2+1
      if (count==1 | count2==10) break
      
      theta <- c(params[1]+rnorm(n=1,mean=0,sd=0.1),params[2]+runif(n=1,min=0,max=0.1),params[3]-runif(n=1,min=0,max=0.2),
                 params[4]+rnorm(n=1,mean=0,sd=0.1),params[5]+runif(n=1,min=0,max=0.1),params[6]-runif(n=1,min=0,max=0.2))
      theta <- cbind(matrix(theta,ncol=6),t(params[(7):(6+lags)]+rnorm(lags,mean=0,sd=0.2)))
      # theta[par_pos]=par_val
      fit <- try({optim(theta, objective, method="BFGS",y=y_star,x=x,T=T,lags=lags,a0=a0,P0=P0, hessian = TRUE)}, silent=TRUE)
      hes<-try({solve(fit$hessian)},silent=TRUE)
      if ('try-error' %in% class(fit) |'try-error' %in% class(hes)) next
      else {
        fit<-fit
        tempparam_est_star[1:(6+lags),bb]<-fit$par
        sd=matrix(diag(solve(fit$hessian)),nrow=(6+lags),ncol=1)
        if (any(sd<0)==TRUE) next
        tempparam_est_star[(7+lags):(2*(6+lags)),bb]<-sd
        for (i in 1:(lags+6)){
          tempparam_est_star[(2*(lags+6)+i),bb]=(fit$par[i])/sqrt(sd[i])
          if (i==2|i==5){
            tempparam_est_star[(2*(lags+6)+i),bb]=((fit$par[i])^2-par_val_Q^2)/sqrt((4*(fit$par[i])^2)*(sd[i]))  
          }
          
        }
        tempparam_est_star[(2*(6+lags))+6,bb]=(fit$par[6]-par_val_t)/sqrt(sd[6])
        sd2=matrix(solve(fit$hessian),ncol=lags+6)
        sd2=sd2[5:6,5:6]
        rb=matrix(c((fit$par[6]-par_val_t),fit$par[5]-par_val_Q),ncol=1)
        tempparam_est_star[(3*(6+lags)+1),bb]=t(rb)%*%solve(sd2)%*%rb/T
        tempparam_est_star[(3*(6+lags)+2),bb]=matrix(fit$convergence)
        if (any(is.nan(tempparam_est_star))==TRUE ) next
        else count=1
      }
      
      
    }
    if (all(tempparam_est_star[,bb]==0)) bb=bb
    else bb=bb+1
  }
  return(result=tempparam_est_star)
}
#################### Inverting AR process ####################
inverse_AR1<-function(y,y0,rho){
  T=nrow(y)
  matt1<-rep(0,T-1)
  matt2<-c(-rho,1)  
  matt<-c(matt2,matt1)
  mat1<-toeplitz(matt)
  mat1<-mat1[1:(T),]
  mat2<-matrix(rep(0,T*(T+1)),nrow=T,ncol=(T+1))
  mat2[2:T,1:T-1]=diag(rep(1,(T-1)))
  mat3<-mat1-mat2
  y1<-rbind(y0,matrix(y))
  eps_est=mat3%*%y1
  return(result=eps_est)
}

############# Bootstrapping Q #######################
boots_Q<-function(y,x,T,params,par_val,B,lags,a0,P0){
  yt=t(y)
  theta <- c(params[1]+rnorm(n=1,mean=0,sd=0.1),params[2]+runif(n=1,min=0,max=0.1),params[3]-runif(n=1,min=0,max=0.2),
             params[4]+rnorm(n=1,mean=0,sd=0.1),params[6]-runif(n=1,min=0,max=0.02))
  theta <- cbind(matrix(theta,ncol=5),t(params[(7):(6+lags)]+rnorm(lags,mean=0,sd=0.2)))
  # theta[par_pos]=par_val
  fit <- try({optim(theta, objective_Q, method="BFGS",y=y,x=x,T=T,val_Q=par_val, lags=lags,a0=a0,P0=P0,hessian = TRUE)}, silent=TRUE)
  param_Q=fit$par
  sp <- TVPss_Q(x,param_Q,T,par_val,lags=lags,a0,P0)
  kal <- fkf(a0 = sp$a0, P0 = sp$P0, dt = sp$dt, ct = sp$ct, Tt = sp$Tt,
             Zt = sp$Zt, HHt = sp$HHt, GGt = sp$GGt, yt = yt)
  
  eps_est0=matrix(kal$att[2,],nrow=T,ncol=1)
  eps_est=eps_est0-param_Q[5]*lagn(eps_est0,1)
  d_eps_est0=matrix(rbind(kal$att[2,1],matrix(diff(kal$att[2,]))),nrow=T,ncol=1)
  if (lags>0){
    for (j in 1:lags){
      eps_est=eps_est-(fit$par[5+j])*lagn(d_eps_est0,j)
    }
  }
  eps_est=(eps_est-mean(eps_est))/sd(eps_est)
  tempparam_est_star=matrix(rep(0,(3*(6+lags)+2)*B),nrow=(3*(6+lags)+2),ncol=B)
  bb=1
  count1<-0
  while (bb<=B){
    # count1<-count1+1
    # if (count1>3) break
    
    count<-0
    count2<-0
    repeat{
      eps_star0<-sample(eps_est, T, replace = TRUE, prob = NULL)
      if (lags>0) w_star<-matrix(arima_sim_w(eps_star0,param_Q[5],param_Q[6:(5+lags)]),nrow=T) else w_star<-matrix(arima_sim_w(eps_star0,param_Q[5],0),nrow=T)
      y_star<-param_Q[1]+matrix(kal$att[1,])*x+w_star
      
      count2=count2+1
      if (count==1 | count2==10) break
      
      theta <- c(params[1]+rnorm(n=1,mean=0,sd=0.1),params[2]+runif(n=1,min=0,max=0.1),params[3]-runif(n=1,min=0,max=0.02),
                 params[4]+rnorm(n=1,mean=0,sd=0.1),params[5]+runif(n=1,min=0,max=0.1),params[6]-runif(n=1,min=0,max=0.02))
      theta <- cbind(matrix(theta,ncol=6),t(params[(7):(6+lags)]+rnorm(lags,mean=0,sd=0.2)))
      # theta[par_pos]=par_val
      fit <- try({optim(theta, objective, method="BFGS",y=y_star,x=x,T=T, lags=lags,a0=a0,P0=P0,hessian = TRUE)}, silent=TRUE)
      hes<-try({solve(fit$hessian)},silent=TRUE)
      if ('try-error' %in% class(fit) |'try-error' %in% class(hes)) next
      else {
        fit<-fit
        tempparam_est_star[1:(6+lags),bb]<-fit$par
        sd=matrix(diag(solve(fit$hessian)),nrow=(6+lags),ncol=1)
        if (any(sd<0)==TRUE) next
        tempparam_est_star[(7+lags):(2*(6+lags)),bb]<-sd
        for (i in 1:(lags+6)){
          tempparam_est_star[(2*(lags+6)+i),bb]=(fit$par[i])/sqrt(sd[i])
          if (i==2){
            tempparam_est_star[(2*(lags+6)+i),bb]=((fit$par[i])^2)/sqrt((4*(fit$par[i])^2)*(sd[i]))  
          }
          if (i==5){
            tempparam_est_star[(2*(lags+6)+i),bb]=((fit$par[i]^2)-par_val)/sqrt((4*(fit$par[i])^2)*(sd[i]))  
          }
          
        }
        tempparam_est_star[(2*(6+lags)+6),bb]=(fit$par[6]-1)/sqrt(sd[6])
        sd2=matrix(solve(fit$hessian),ncol=lags+6)
        sd2=sd2[5:6,5:6]
        rb=matrix(c((fit$par[6]-1),fit$par[5]-par_val),ncol=1)
        tempparam_est_star[(3*(6+lags)+1),bb]=t(rb)%*%solve(sd2)%*%rb/T
        tempparam_est_star[(3*(6+lags)+2),bb]=matrix(fit$convergence)
        if (any(is.nan(tempparam_est_star))==TRUE) next
        else count=1
      }
      
      
    }
    if (all(tempparam_est_star[,bb]==0)) bb=bb
    else bb=bb+1
  }
  return(result=tempparam_est_star)
}
