Readme for Ms. No.: 19-576 
These codes replicate the main findings of the paper titled “Heterogeneous effects of unconventional monetary policy on the bond yields across the euro area”. 
One can find the data and the main MATLAB (2018 or later) functions listed below:

This code replicates the event study findings in the fifth section. You can find the data and the stata code below:
•	ecbfactor2.dta: contains the estimated factors. 

•	events2.dta: contains the dates for the three types of unconventional policy announcements.
	sovbondpurc: dummy variable which takes the value of 1 on the sovereign bond purchase announcement days.
	liqprov:     dummy variable which takes the value of 1 on the liquidity providing announcement days.
	app: 	     dummy variable which takes the value of 1 on the asset 	purchase program announcement days.

•	eventstudy2.do: merges the two data set specified above and replicates the findings in Table 2. 
-	Open eventstudy2.do file and change the data address line on the top of the code before you run the code. (Open ecbfactor2.dta file and copy the data code you see on the main screen. Then, replace the data address line in the do file with the code you copy.)
-	Run the code.

