

//

clear

// You should change the data adress written below before you run the code. Open ecbfactor2.dta file and copy the data code you see on the main screen. 

use "C:\Users\ydsec\Dropbox\Secil Ishak proje\ECBeventstudy\ecbfactor2.dta"  

generate date=mdy(month,day,year)

format date %td

set more off


merge m:m date using events2


local events "liqprov sovbondpurc app"


foreach var of varlist `events' {
replace `var'=0 if `var'==.
}

egen time = seq()

tsset time, daily


local factors "f1 f2 f3 f4"

foreach var of varlist `factors' {
gen d`var'=`var'-l.`var'
}

local dfactors "df1 df2 df3 df4"

foreach var of varlist `dfactors' {
regress `var' liqprov sovbondpurc app
}


