function [R1,sigma1,sigma0,V0,V1]=HBI_R(y,evars,pol,nlag,param0)
% This function employs the Heteroscedasticy-based-identification
% Inputs:
% y: endogenous variables
% evars: exogenous variables
% pol: policy days dummy
% nlag: lag length for VARX
% param0: starting values for optimization
% Outputs: 
% R1: Estimated R parameter
% sigma1: variance-covariance matrix of the policy-day residuals
% sigma0: variance-covariance matrix of the non-policy-day residuals
% V1: variance-coriance matrix of the variance-covariance matrix of the policy-day residuals
% V0: variance-coriance matrix of the variance-covariance matrix of the non-policy-day residuals

Mdl = varm(size(y,2),nlag); % setup VARX(nlag) model
[~,~,~,res]=estimate(Mdl,y,'X',evars); 
n=size(y,2);
res1=res(pol(length(y)-length(res)+1:end)==1,:);
res0=res(pol(length(y)-length(res)+1:end)==0,:);

X1 = ones(size(res1,1),1);
X0 = ones(size(res0,1),1);
[~,sigma1,~,CovB1,~] = mvregress(X1,res1,'varformat','full');
[~,sigma0,~,CovB0,~] = mvregress(X0,res0,'varformat','full');

V1=CovB1(end-length(vech(sigma1))+1:end,end-length(vech(sigma1))+1:end);
V0=CovB0(end-length(vech(sigma0))+1:end,end-length(vech(sigma0))+1:end);

options=optimset('MaxFunEvals',100000,'MaxIter',100000); 
if isempty(param0) % initial condtion for minimization
    gstart=ones(n,1)/n;
else
    gstart=param0;
end
R1=fminsearch(@(g) myfunc(g,vech(sigma1)-vech(sigma0),(V0+V1)),gstart,options); % minimization in equation (4).

    function obj = myfunc(g,p,v);
        %Find the matrix of rank L that is as close as possible to p (vcov matrix: v)
        obj=(vech(g*g')-p)'*inv(v)*(vech(g*g')-p);
    end
end