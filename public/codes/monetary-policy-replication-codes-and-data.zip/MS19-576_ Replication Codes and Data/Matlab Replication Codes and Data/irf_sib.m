function [irf]=irf_sib(beta,R,shock,h,nlag,q)
% This function generats IRF from VAR estimates
% Input: 
% beta: VARX estimates of endogenous varians in campanion form
% R: estimated R; shock: impulse magnititude; h: maximum horizon
% nlag: VARX's lag length; q: # of endogenous variables in VARX
% Output: Impulse response function
U=zeros(h+nlag+1,q);
U(nlag+1,:)=R'*shock;
y=zeros(h+nlag+1,q);
for t=nlag+1:length(y)
    y0=lagmatrix(y,1:nlag);
    y(t,:)=y0(t,:)*beta(2:end,:)+U(t,:);
end
irf=y(nlag+1:end-1,:);
