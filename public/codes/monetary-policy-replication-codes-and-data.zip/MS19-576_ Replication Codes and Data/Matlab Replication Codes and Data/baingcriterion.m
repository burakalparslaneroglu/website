function [PC, IC, nfact_HL] = baingcriterion(X, rmax, rvar)
if nargin == 2
    rvar = rmax;
end
N = size(X, 2);
T = size(X, 1);
W = diag(std(X));
x = (X - ones(T,1)*(sum(X)/T))*(W^-1);

Gamma0 = cov(x);
opts.disp = 0;
[H, D] = eigs(Gamma0, rmax,'LM',opts);

for r = 1:rmax
I = x*(eye(N) - H(:,1:r)*H(:,1:r)');
V(r) = sum(sum(I.^2))/(N*T);
end
e = (N + T)/(N*T);

penalty1 = (1:rmax)*e*log(1/e);
penalty2 = (1:rmax)*e*log(min(N,T));
penalty3 = (1:rmax)*(log(min(N,T))/min(N,T));

PC = [V + V(rvar)*penalty1; V + V(rvar)*penalty2; V + V(rvar)*penalty3]';
IC = [log(V) + penalty1; log(V) + penalty2; log(V) + penalty3]';
[nfact_HL, ~, ~] = numfactors_nonstd_nolog(X,rmax)% Hallin and Liska
end


function [nfact, v_nfact, cr] = numfactors_nonstd_nolog(panel, q_max,plot_opt)
% log criterion to determine the number of dynamic factors according to
% Hallin and Liska (2007) "Determining the Number of Factors in the General 
% Dynamic Factor Model", Journal of the American Statistical Association, 
% 102, 603-617 
if nargin == 2;  plot_opt=0; end
[T,n] = size(panel);

demean=0;
if demean==1
    % Mean-standardize data
    m_X = mean(panel);
    % s_X = std(panel);
    X = (panel - ones(T,1)*m_X);
else
    X=panel;
end

%Compute the number of dynamic factors
nbck = floor(n/4);
    stp = 1;
    c_max = 3;
    penalty = 'p1';
    cf = 1000;
    m = floor(sqrt(T));
    h = m;
    plot_opt = 1;
s=0;
for N = n-nbck:stp:n
    disp(sprintf('subsample size %d',N));
    s = s+1;
    [a rv] = sort(rand(n,1));                                                 % select randomly N series
    subpanel = X(1:T,rv(1:N));

    m_subpanel = mean(subpanel);
%     s_subpanel = std(subpanel);
    subpanel = (subpanel - ones(T,1)*m_subpanel);                           % standardize the subpanel

    [P_X, D_X, Sigma_X] = spectral(subpanel, N, h, m);                      % in this case we use spectral with q = N
    E = [D_X(:,h+1)  D_X(:,h+2:2*h+1)*2]*ones(h+1,1)/(2*h+1);               % all the n dynamic eigenvalues
    IC1 = flipud(cumsum(flipud(E)));                                        % compute information criterion
    IC1 = IC1(1:q_max+1,:);
    
    if strcmp(penalty, 'p1') == 1                                   
        p = ((m/T)^0.5 + m^(-2) + N^(-1))*log(min([(T/m)^0.5;  m^2; N]))*ones(q_max+1,1);  
    elseif strcmp(penalty, 'p2') == 1
        p = (min([(T/m)^0.5;  m^2; N])).^(-1/2)*ones(q_max+1,1);  
    elseif strcmp(penalty, 'p3') == 1    
        p = (min([(T/m)^0.5;  m^2; N])).^(-1)*log(min([(T/m)^0.5;  m^2; N]))*ones(q_max+1,1);  
    end

    for c = 1:floor(c_max*cf)
        cc = c/cf;
        IC = log(IC1./N) + (0:q_max)'.*p*cc;
        rr = find((IC == ones(q_max+1,1)*min(IC))==1);              % compute minimum of IC
        o(s,c) = rr-1;
    end
end

cr = (1:floor(c_max*cf))'/cf;
nfact = o(end,:);                                                       % number of factors when N = n
v_nfact = std(o);
%% Plot if needed
if plot_opt == 1
    figure
    plot(cr,5*v_nfact,'b-')
    hold all
    plot(cr,nfact,'r-')
    xlabel('c')
    axis tight
    legend('S_c','q^{*T}_{c;n}')
    title('estimated number of factors - log criterion')
end
end


function [P_chi, D_chi, Sigma_chi] = spectral(X, q, m, h)
% Computes spectral decomposition for the data matrix in input.
% INPUT:    X               :   T x n data matrix
%                               data should be covariance stationary and
%                               mean standardized
%           q               :   dimension of the common space
%                               (i.e. number of dynamic factors)
%           m               :   covariogram truncation
%                               (default value: floor(sqrt(T)))
%           h               :   number of points in which the spectral
%                               density is computed (default value: m)
%
% OUTPUT:   P_chi           :   n x q x 2*h+1 matrix of dynamic eigenvectors
%                               associated with the q largest dynamic eigenvalues
%                               for different frequency levels
%           D_chi           :   q x 2*h+1 matrix of dynamic eigenvalues
%                               for different frequency levels
%           Sigma_chi       :   (n x n x 2*h+1) spectral density matrix
%                               of common components with the 2*h+1 density
%                               matrices for different frequency levels
%% Preliminary settings
[T,n] = size(X);

if nargin < 2
    disp('ERROR MESSAGE: Too few input arguments');
    return
end

if nargin == 2
    m = floor(sqrt(T));
    h = m;
end

if nargin == 3
    h = m;
end

%% Compute M covariances
M = 2*m+1;
B = triang(M);                                                              % Triangular window (similar Bartlett)
Gamma_k = zeros(n,n,M);
for k = 1:m+1,
    Gamma_k(:,:,m+k) = B(m+k)*(X(k:T,:))'*(X(1:T+1-k,:))/(T-k);
    Gamma_k(:,:,m-k+2) = Gamma_k(:,:,m+k)';
end

%% Compute the spectral density matrix in H points
H = 2*h+1;
Factor = exp(-sqrt(-1)*(-m:m)'*(-2*pi*h/H:2*pi/H:2*pi*h/H));
Sigma_X = zeros(n,n,H);
for j = 1:n
    Sigma_X(j,:,:) = squeeze(Gamma_k(j,:,:))*Factor;
end

%% Create output elements
P_chi = zeros(n,q,H);
D_chi = zeros(q,H);
Sigma_chi = zeros(n,n,H);

%% Compute eigenvalues and eigenvectors
%% case with q < n-1 we can use eigs, fast method
if q < n-1 
    opt.disp = 0;
    [P, D] = eigs(squeeze(Sigma_X(:,:,h+1)),q,'LM',opt);                    % frequency zero
    D_chi(:,h+1) = diag(D);
    P_chi(:,:,h+1) = P;
    Sigma_chi(:,:,h+1) = P*D*P';

    for j = 1:h
        [P, D] = eigs(squeeze(Sigma_X(:,:,j)),q,'LM',opt);                  % other frequencies
        D_chi(:,j) = diag(D);
        D_chi(:,H+1-j) = diag(D);
        P_chi(:,:,j) = P;
        P_chi(:,:,H+1-j) = conj(P);

        Sigma_chi(:,:,j) = P*D*P';
        Sigma_chi(:,:,H+1-j) = conj(P*D*P');
    end
end

%% case with q >= n-1, we must use eig, slow method
if q >= n-1 
    [P, D] = eig(squeeze(Sigma_X(:,:,h+1)));                                % frequency zero
    [D,IX] = sort((diag(D)));                                               % sort eigenvalues and eigenvectors
    D = flipud(D);
    IX = flipud(IX);
    P = P(:,IX);
    D = diag(D);
    D_chi(:,h+1) = real(diag(D));
    P_chi(:,:,h+1) = P;
    Sigma_chi(:,:,h+1) = P*D*P';

    for j = 1:h
        [P, D] = eig(squeeze(Sigma_X(:,:,j)));                              % other frequencies
        [D,IX] = sort((diag(D)));                                           % sort eigenvalues and eigenvectors
        D = flipud(D);
        IX = flipud(IX);
        P = P(:,IX);
        D = diag(D);
        D_chi(:,j) = real(diag(D));
        D_chi(:,H+1-j) = real(diag(D));
        P_chi(:,:,j) = P;
        Sigma_chi(:,:,j) = P*D*P';
        P_chi(:,:,H+1-j) = conj(P);
        Sigma_chi(:,:,H+1-j) = conj(P*D*P');
    end 
end
end

