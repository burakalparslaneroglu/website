function [testStat,df]=boxm(sigma0,sigma1,p,nlag0,nlag1,n0,n1)
% df0=n0-1;
% df1=n1-1;
% k=2;
% C=(df0*sigma0+df1*sigma1)/(df1+df0);
% M=(df1+df0)*log(det(C))-(df0*log(det(sigma0))+df1*log(det(sigma1)));
% h=1-((2*p^2+3*p-1)/(6*(p+1)*(k-1)))*((1/df0)+(1/df1)-((1/(df0+df1))));
% testStat=M*h;
% df=p*(p+1)*(k-1)/2;

df0=n0-p*nlag0-1;
df1=n1-p*nlag1-1;
k=2;
C=(df0*sigma0+df1*sigma1)/(df1+df0);
M=(df1+df0)*log(det(C))-(df0*log(det(sigma0))+df1*log(det(sigma1)));
h=1-((2*p^2+3*p-1)/(6*(p+1)*(k-1)))*((1/df0)+(1/df1)-((1/(df0+df1))));
testStat=M*h;
df=p*(p+1)*(k-1)/2;

