clear
clc
close all
load data.mat % Load data from the directory
Countries={'Germany','France','Austria','Netherlands','Belgium','Italy','Spain','Portugal'}; % Country names in the sample
kkk=[1 11;12 22; 23 31; 32 41;42 52;53 62;63 72;73 78]; % Identifier of variables that belong to different countries
kk=[0;11;11;9;10;11;10;10;6]; %# number of variables for each country
X=double(data(:,1:80)); 
T=length(X);
data0=data;
rrr=2; 
cont_ind=4; % # of factors
for gind=cont_ind
    data=data0; 
    if rrr==2
        maxind=2846; % Up to January 2020
        data=data0(1:maxind,:);
        param0=[];
    end
    if rrr==3
        maxind=2103; % original dataset up to November 2016
        data=data0(1:maxind,:);
        param0=[];
    end
    X=double(data(:,1:80));
    Exo1=double(data.Exo); 
    Exo0=double(data.FedPol);
    T=length(X);
    
    r=gind;%  number of common factors = 4
    
    pol0=data.unpolicy2; 
    pol0(pol0(:)>=1)=1; 
    pol=pol0;
    fact=1; 
    m=10; 
    jj=7; 
    mm=2; % 1 if demeaned; 2 if data is standardized
    nlag=4; % Max number of lags in VAR
    nrep=1999; % Number of bootstrap replicates
    var_type=[2]; 
    h=360; % number of horizon
    stationary=1; 
    diff_data=0; 
    shock=1; 
    Restboot=0; 
    normalize=0; 
    scale=[]; % scale the IRF 
    scale_pos=[];
    control=1; 
    detrending=0; 
    cons_out=0; 
    if detrending==1
        X=detrend(X,'linear');
    end
    if fact==1
        dX=diff(X);
        out=onatski(dX,12); 
        if mm==1
            dX=demean(dX);
        end
        if mm==2
            dX=standard(dX);
        end
        if control==1
            dcvar=[];
            cvar0=fillmissing(double(data.VIX),'previous'); % holiday days mismatch
            cvar0=[cvar0 fillmissing(double(data.gb10yUS),'previous');];
            dcvar(:,1)=standard(diff(cvar0(:,1))); 
            dcvar(:,2)=standard(diff(cvar0(:,2)));
        end
        X0=dX;
        if cons_out==1
            [~,~,dX,~,~] = mvregress([Exo0(2:end) Exo1(2:end)],dX);
        end
        [ehat,Fhat0,lambda,ss,ve2]=pc(dX,r);
        
    elseif fact==2
        if mm==1
            X=demean(X);
        end
        if mm==2
            X=standard(X);
        end
        [ehat,Fhat0,lambda,ss,ve2]=pc(X,r);
        out=onatski(X,12);
        X0=X;
    else
        Fhat0=diff(X);
        X0=Fhat0;
        ehat=zeros(size(X0,1),size(X0,2));
        lambda=eye(size(X,2));
    end
    Fhat=Fhat0;
    if diff_data==0 && fact==1
        Fhat=cumsum(Fhat0);
    end
    if fact==0 || fact==1 || fact==2
        pol=pol0(2:end);
        Exo0=Exo0(2:end);
        Exo1=Exo1(2:end);
        cvar=(cvar0(2:end,1));
    end
    
    y=[Fhat cvar]; % the VAR data
    evars=[Exo1 Exo0]; 
    [opt_lag]=optimal_lag_exo(y,evars,nlag); % optimal lag for the VARX
    nlag=opt_lag.sic; % 
    Mdl = varm(size(y,2),nlag); % varm(number of endo vars,lag length);
    
    [estmdl,~,~,U]=estimate(Mdl,y,'X',evars); % Estimate VARX
    
    A=[];
    for ii=1:nlag % reshape
        A=[A estmdl.AR{1,ii}];
    end
    [t,q]=size(y);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [R,sigma1,sigma0,V0,V1]=HBI_R(y,evars,pol,nlag,param0); 
    capa=[A;[eye(q*(nlag-1)) zeros(q*(nlag-1),q)]]; 
    
    clear IRF00;
    for i=0:h % Create IRF form the VARX
        irfh0=(capa^i)*[R;zeros(q*(nlag-1),1)];
        IRF00(i+1,:)=irfh0(1:q)';
    end
    
    IRF0=IRF00(:,1:r); % note that we are interested in the IRF of the factors.
    [lCI,uCI,IRFrmat,Rmat]=boot_HBI(r,y,evars,nlag,h,pol,nrep,shock,R,IRF0,lambda,size(X,2),m,stationary,normalize,scale,scale_pos,Restboot); 
    IRF=IRF0*lambda';
    normalizpar=-(1/IRF(1,end-1))*0.50; %Normalize the shock )
    eval(['IRF' num2str(gind) '=IRF*normalizpar;']);
    eval(['IRF0_' num2str(gind) '=IRF*normalizpar;']);
    eval(['lCI' num2str(gind) '=lCI*normalizpar;']);
    eval(['uCI' num2str(gind) '=uCI*normalizpar;']);
    eval(['IRFrmat' num2str(gind) '=IRFrmat*normalizpar;']);
end

%% IRF plots
ii=0;
cols= {'k','b','y','g','r',[.5 .6 .7],[.8 .2 .6],rand(1,3),rand(1,3),rand(1,3),rand(1,3),rand(1,3),rand(1,3),rand(1,3),rand(1,3),rand(1,3),rand(1,3),rand(1,3)}
cont_ind2=cont_ind(cont_ind>=3);
param_est_all_ind=[];
for k=1:length(Countries)
     if kkk(k,1)~=kkk(k,2)
        f=figure('units','normalized','outerposition',[0 0 1 1])
        jj=0;
        for j=kkk(k,1):kkk(k,2)
            ii=ii+1;
            jj=jj+1;
            
            subplot(ceil(kk(k+1)/2),2,jj)
            mmin=[];
            mmax=[];
            name=[];
            for gind=cont_ind2
                eval(['IRFc=IRF' num2str(gind) ';']);
                eval(['lCIc=IRF' num2str(gind) ';']);
                eval(['uCIc=IRF' num2str(gind) ';']);
                eval(['lCIc=lCI' num2str(gind) ';']);
                eval(['uCIc=uCI' num2str(gind) ';']);
                eval(['IRFrmatc=IRFrmat' num2str(gind) ';']);
                plot(IRFc(:,j),'color',cols{gind+1}, 'LineWidth',2);hold on;
                plot([lCIc(:,j) uCIc(:,j)],'b:', 'LineWidth',1)
                if gind<10
                    name1=['IRF' num2str(0) num2str(gind)];
                else
                    name1=['IRF' num2str(gind)];
                end
      
                mmin=[mmin;[lCIc(:,j);uCIc(:,j)]];
                name=[name;name1];
            end
            cn=string(data.Properties.VarNames(j));
            cns{ii}=cn;
            lc=length(char(cn));
            if lc==9
                title(strcat(Countries{k},  cn{1}(1:5)));
            else
                title(strcat(Countries{k},  cn{1}(1:4)));
            end
            ylim([min(mmin)-0.01 max(mmin)+0.01]);
            xlim([0 360]);
            legend(name)
        end
    end
    
end


nEA=2;
if nEA>0
    figure
    for jj=1:nEA
        j=78+jj; subplot(2,ceil(nEA/2),jj)
        for gind=cont_ind2
            eval(['IRFc=IRF' num2str(gind) ';']);
            eval(['lCIc=lCI' num2str(gind) ';']);
            eval(['uCIc=uCI' num2str(gind) ';']);
            eval(['IRFrmatc=IRFrmat' num2str(gind) ';']);
            plot(IRFc(:,j),'color',cols{gind+1}, 'LineWidth',2);hold on;
            if j==79
                title('EA5')
            else
                title('EA10')
            end
            plot([lCIc(:,j) uCIc(:,j)],'b:', 'LineWidth',1)
            name1=['IRF' num2str(gind) ];
        end
        legend(name)
    end
end