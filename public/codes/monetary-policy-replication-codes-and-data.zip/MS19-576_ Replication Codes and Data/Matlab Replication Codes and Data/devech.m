function [ymat]=devech( x,q)
%x vectorized vector
%q is the row and column of q\times q matrix
 y = zeros(q);
 upperTriangleIndices = triu(true(q));
 y(upperTriangleIndices) = x; % Fill in the upper piece
 ymat = y + y.' - diag(diag(y));