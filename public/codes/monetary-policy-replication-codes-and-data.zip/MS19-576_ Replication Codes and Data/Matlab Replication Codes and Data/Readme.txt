Readme for Ms. No.: 19-576  
These codes replicate the main findings of the paper titled “Heterogeneous effects of unconventional monetary policy on the bond yields across the euro area”. One can find the data and the main MATLAB (2018 or later) functions listed below:
Data:
•	data.mat: The data used in the paper. It contains 88 columns and 3009 daily observations. data.csv is the csv version of this dataset. The following list exhibits variable names
1.	Dates: date of the observation
2.	‘gb’ # ‘y_’+ country name: # year government bond yield of ‘country name’. country name consists of the set {Ger (Germany),Fra (France),Aus (Austria),Net (Netherlands),Bel (Belgium),Ita (Italy),Spa (Spain), Por (Portugal)}
3.	‘gb’ # ‘y_ EA: # year bond yields from ECB
4.	VIX: volatility index of US stock markets
5.	gb10yUS: 10 year US government bond yield
6.	Exo: one month OIS rate change in the press release window from the Euro Area Monetary Policy Event Study Database.
7.	Unpolicy2: Unconventional policy days dummy version 2
8.	FedPol: Fed policy days dummy
Matlab Codes
We list below the various matlab codes in alphabetical order

1.	Boot_HBI.m: generates bootstrap confidence bands for the IRFs of both factors and yields.
2.	Boxm.m: conducts Box’s M test
3.	Irf_sib.m: generates IRF for VARX model
4.	Mainfile_HBI.m: this function replicates the IRF functions and their confidence bands.
5.	Optimal_lag_exo.m: provides lag length selection for VARX model.
6.	Pc.m: conducts PCA
7.	Wright_HBI.mhe main function that estimates the crucial parameter R in Wright’s (2012) algorithm,
8.	The rest of the functions are auxiliary functions used in numerous places of the main code.
