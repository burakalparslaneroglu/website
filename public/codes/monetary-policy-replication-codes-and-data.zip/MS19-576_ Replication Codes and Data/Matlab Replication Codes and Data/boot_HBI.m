function [lCI,uCI,IRFrmat,Rmat,lCIf,uCIf,IRFfmat]=boot_HBI(r,y,evars,nlag,h,pol,nrep,shock,R,IRF0,lambda,nvar,m,stationary,normalize,scale,scale_pos,Restboot)
% This function is a modified version of boot.m function of Lutz Kilian. It
% generates bootstrapp confidence intervals for IRF
% Inputs:
% r: # of common factors; y: Endegenous variables (factors in our case); evars: Exogenous variables
% nlag: lag length for VARX; h: maximum IRF horizon; pol: policy day dummy
% nrep: # of bootstrap replication; shock: impulse magnititude
% R: estimated R that is required if R ies not etimated in bootstrap
% replications; IRF0: estimated IRF; lambda: factor loadings; nvar: # of
% variables in y; m: stationary bootstra block size; stationary: 1 if
% stationary bootstrap adopted; normalize: 1 if normalization is applied
% scale: normalization parameter; scale_pos: position of the variable in y
% to normalize; Restboot: 1 if R is reestimated in Bootstrap replications
% Outputs: 
% lCI: lower confidence band; uCI: upper confidence band;
% IRFrmat: bootstrapped IRF; Rmat: bootstrap estimate of R (if required)
% lCIf: lower confidence band for factors; uCIf: upper confidence band for factors; 
% IRFfmat: Bootstrap IRF for factors

[t,q]=size(y); % dimonsions of endogenous data
Mdl = varm(q,nlag); % setup VARX model
[estmdl,~,~,U]=estimate(Mdl,y,'X',evars); % estimate VARX model
Rmat=R;
IRFrmat=zeros(h,nvar,nrep);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  start of bootstrap simulation                                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create nboot bootstrap replications of pseudo data
% U=standard(U);
for j=1:nrep
    if m>1
        [index]=BB_ind(length(2:t-nlag+1),m,stationary); % applies general bootstrap algorithms, see BB_ind function
    else
        index=fix(rand(1,size(U,1))*size(U,1))+1; % standard bootstrap
    end
    Ur=U(index,:); % bootstraped residuals
    %% obtain bootstraped factors
    if isempty(evars)
        yr = filter(estmdl,Ur,'Y0',y(1:nlag,:));
    else
        yr = filter(estmdl,Ur,'X', evars,'Y0',y(1:nlag,:));
    end
    %%
    yr = [y(1:nlag,:);yr]; % embed the initial conditions
    polr=pol([1:nlag index]); % obtain bootstrapped version of policy days
    yr=detrend(yr,0); % demean the bootstraped data
    pr=nlag;
    Mdl = varm(q,pr); % setup VARX model for bootstrap data
    [estmdlr,~,~,~]=estimate(Mdl,yr,'X',evars); % estimate VARX model for bootstrap data
    %% reshape bootstraped VARX coefficients
    Ar=[];
    Arc=[];
    if nlag>1
        for ii=1:nlag
            Ar0=estmdlr.AR{1,ii};
            Ar=[Ar Ar0];
            Arc=[Arc [Ar0;eye(size(Ar0,1))]];
        end
    else
        Arc=estmdlr.AR{1,1};
    end
    %%
    SIGMAr=estmdlr.Covariance; % bootstraped variance covariance estimate for residuals
    %% Obtain bootstraped estimates for R (if required)
    [Ar,SIGMAr]=olsvarc(yr,pr);
    Rr=R;
    if Restboot==1
        check=1;
        while check==1
            [Rr,~,~,~,~]=wright_v2_model3(y,evars,polr,nlag,R);
            if sum(sign(Rr)==sign(Rmat(:,1)))==length(Rr)
                check=0;
            end
        end
    end
    %% Bias correction of Kilian (1998)
    if ~ any(abs(eig(Arc))>=1)
        [Arc]=asybc(Arc,SIGMAr,t,pr,q);
    end
    Ar=Arc(1:q,:);
    %%
    Rrf=Rr;
    Rmat=[Rmat Rr];
    if normalize==1 % normalization (if selected)
        Rrf(scale_pos)=scale;
        Rrf(setdiff(1:end,scale_pos))= scale*Rr(setdiff(1:end,scale_pos))/Rr(scale_pos);
    end
    
    [IRFr]=irf_sib([ones(1,q);Ar'],Rrf,shock,h,nlag,q); % generate bootstraped IRF for factors
    IRFfmat(:,:,j)=IRFr(:,1:r); %factor responses
    IRFrmat(:,:,j)=IRFr(:,1:r)*lambda'; % generate IRF for observed data
end

% Calculate 90 percent interval endpoints for Factors
IRF000=IRF0(:,1:r) ;
for i=1:h
    for j=1:r
        lCIf(i,j)=quantile([reshape(IRFfmat(i,j,:),nrep,1);IRF000(i,j)],0.05);
        uCIf(i,j)=quantile([reshape(IRFfmat(i,j,:),nrep,1);IRF000(i,j)],0.95);
    end
end

% Calculate 90 percent interval endpoints
IRF1=IRF0(:,1:r)*lambda' ;
for i=1:h
    for j=1:(nvar)
        lCI(i,j)=quantile([reshape(IRFrmat(i,j,:),nrep,1);IRF1(i,j)],0.05);
        uCI(i,j)=quantile([reshape(IRFrmat(i,j,:),nrep,1);IRF1(i,j)],0.95);
    end
end