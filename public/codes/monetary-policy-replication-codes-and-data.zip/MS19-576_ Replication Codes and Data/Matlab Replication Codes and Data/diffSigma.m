function [fun]=diffSigma(sigma0,sigma1,V0,V1)

V0_hat=vech(V0);
V1_hat=vech(V1);
fun=(vech(sigma1-sigma0))'*inv(V0+V1)*(vech(sigma1-sigma0));