function [opt_lag]=optimal_lag_exo(y,evars,maxlag)
% This function selects the optimal lag length for VARX model.
% Input:
% y: endegonous data for VARX
% evars: exogenous data for VARX
% maxlag: maximum lag
% Output:
% opt_lag: a structure saving the optimal lag for different information
% criterion.
[n,d]=size(y); % dimension of the data
[~,de]=size(evars); % # of exogenous variables
for i=1:maxlag
    Mdl = varm(d,i); % setup the VAR model
estmdl=estimate(Mdl,y,'X',evars); % Estimate VARX model
SIGMA=estmdl.Covariance; % save the estimated variance-covariance matrix
    aic(i)=log(det(SIGMA))+2*(d+(d^2)*i+de*d)/n; % AIC 
    bic(i)=log(det(SIGMA))+2*(d+(d^2)*i+de*d)*log(log(n))/n; % BIC
    sic(i)=log(det(SIGMA))+(d+(d^2)*i+de*d)*log(n)/n; %SIC
    like(i)=log(det(SIGMA)); % Log-likelihood
end
j=maxlag;
ret=0;
% Find the optimal lag
while ret==0 && j>1
    lr=(n-j*d-d*de)*(like(j-1)-like(j));
    rest=(d^2);
    chi_crit=chi2inv(0.95,rest);
    if j==1
        ret=1;
        opt_lag.lr=1;
    end
    if lr>=chi_crit
        ret=1;
        opt_lag.lr=j;
    else
        ret=0;
    end
    j=j-1;
end
% Saving the results.
 opt_lag.aic=find(aic==(min(min(aic))));
 opt_lag.bic=find(bic==(min(min(bic))));
 opt_lag.sic=find(sic==(min(min(sic))));
    
 