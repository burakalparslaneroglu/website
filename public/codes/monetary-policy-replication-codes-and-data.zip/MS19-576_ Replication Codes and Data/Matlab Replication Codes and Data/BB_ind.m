function [ind_BB]=BB_ind(T,m,stationary)
% This function employs different bootstrap methods
% Inputs:
%T: # of observations; m: stationary bootstrap block size; 
% stationary: 1 if stationary bootstrap is chosen
% output: ind_BB: bootstraped indices of the data

% Loop over B bootstraps
if stationary==0
    % ceil(T/m) Uniform random numbers over 1...T-m+1
    u = ceil((T-m+1)*rand(ceil(T/m),1));
    u = bsxfun(@plus,u,0:m-1)';
    % Transform to col vector, and remove excess
    u = u(:);
    ind_BB = u(1:T);
    % y-star sample simulation
else
    u(1) = ceil(T*rand);
    for t=2:T
        if rand<1/m
            u(t) = ceil(T*rand);
        else
            u(t) = u(t-1) + 1;
            if u(t)>T
                u(t)=ceil(T*rand);
            end
        end
    end
    ind_BB=u(1:T);
end