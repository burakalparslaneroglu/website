% This code is the main code file for the Paper "Pairs Trading with Wavelet
% transform". It generates various statistics used in the paper for
% different wavelets, time periods and pairs selection. 
clear
clc
close all
%% Data
% load data_SP500_cleared % Data is not shared becauce of copyright issues.
% data_SP500_cleared contains a dataset called dataff. The first columns is the
% dates, the remaining 415 series are stock prices from SP500 index. The
% below code does minor data cleaning. But one can easily use the remaining
% code for a given data set.
% issues
load pairs_indices % Pairs used in the analysis. Derived from data_SP500_cleared
clearvars data dataf
init=max(find(diff(datenum(dataff.Dates))>5))+1;
dataff0=dataff(init:end,:);
dtrndng=0;
TT=length(dataff0);
TY=floor(TT/252); % The number of years.
nper=TY-1; % number of periods for trading
T=TY*252; % The number of daily observations
data0=double(dataff0(1:T,2:end)); % We restrict the data set as we need a regular data
dates0=dataff0.Dates(253:T); % Dates 
datanames=dataff0.Properties.VarNames(2:end); % Stock names
%%
for mm=1:2 % mm=1: Pairs selected via cointegration, m=2: Pairs selected via Minimum distance 
    % Profit from the pairs chosen with Johansen test
    for per=1:nper
        [mm per]
        % Cointegration Tests
        smpl0=(per-1)*252+1:(per)*252; % Testing period
        smpl1=(per)*252+1:(per+1)*252; % Trading period
        level=1;
        for delay=[22] % Delayin period. Used in Delayed trade.
            dtrndng=[0]; % 0: only intercept, 1: intercept and trend in regression equation.
            if mm==1 % cointegration
                cointj_ind=mat_coint.(['mat_' num2str(per)]); % loaded from pairs_indices file. Contains pairs indices
            end
            if mm==2 % minimum distance 1000 Pairs
                cointj_ind=mat_mindist.(['mat_' num2str(per)]); % loaded from pairs_indices file. Contains pairs indice
            end

            for wavelets0={'haar','db2','db6','db8','db10','db12','db14','db16','db18','db20','db22', 'db24', 'sym2','sym6','sym8','sym10','sym12','sym14','sym16','sym18','sym20','sym22', 'sym24','coif1','coif2','coif3','coif4','coif5'};
                wavelets=wavelets0;
                T0=252; %training sample size. if changed smpl0 and smpl1 should be changed!
                T1=252;%trading sample size
                level=[1]; % wavelet filter length
                theta=0.001; % Transaction cost 0.1%
                % Initiate some matrices
                profitgatevf_org=zeros(length(cointj_ind),length(wavelets));
                profitgatevwf=zeros(length(cointj_ind),length(wavelets));
                tsgatevf_org=zeros(length(cointj_ind),length(wavelets));
                tsgatevwf=zeros(length(cointj_ind),length(wavelets));
                trade_returngatevf_org=zeros(T1,length(cointj_ind),length(wavelets));
                trade_returngatevwf=zeros(T1,length(cointj_ind),length(wavelets));
                postogatevf_org=zeros(T1,length(cointj_ind),length(wavelets));
                postcgatevf_org=zeros(T1,length(cointj_ind),length(wavelets));
                postogatevwf=zeros(T1,length(cointj_ind),length(wavelets));
                postcgatevwf=zeros(T1,length(cointj_ind),length(wavelets));
                spreadgatevf_org=zeros(T1,length(cointj_ind),length(wavelets));
                spreadgatevwf=zeros(T1,length(cointj_ind),length(wavelets));
                Rb_org=zeros(T1,length(cointj_ind),length(wavelets));
                Rbw=zeros(T1,length(cointj_ind),length(wavelets));

                profitgatevwf_v2=zeros(length(cointj_ind),length(wavelets));
                tsgatevwf_v2=zeros(length(cointj_ind),length(wavelets));
                trade_returngatevwf_v2=zeros(T1,length(cointj_ind),length(wavelets));
                postogatevwf_v2=zeros(T1,length(cointj_ind),length(wavelets));
                postcgatevwf_v2=zeros(T1,length(cointj_ind),length(wavelets));
                spreadgatevwf_v2=zeros(T1,length(cointj_ind),length(wavelets));
                Rbw_v2=zeros(T1,length(cointj_ind),length(wavelets));

                profitgatevwf_vmra=zeros(length(cointj_ind),length(wavelets));
                tsgatevwf_vmra=zeros(length(cointj_ind),length(wavelets));
                trade_returngatevwf_vmra=zeros(T1,length(cointj_ind),length(wavelets));
                postogatevwf_vmra=zeros(T1,length(cointj_ind),length(wavelets));
                postcgatevwf_vmra=zeros(T1,length(cointj_ind),length(wavelets));
                spreadgatevwf_vmra=zeros(T1,length(cointj_ind),length(wavelets));
                Rbw_vmra=zeros(T1,length(cointj_ind),length(wavelets));

                profitgatevf_v1=zeros(length(cointj_ind),length(wavelets));
                tsgatevf_v1=zeros(length(cointj_ind),length(wavelets));
                trade_returngatevf_v1=zeros(T1,length(cointj_ind),length(wavelets));
                postogatevf_v1=zeros(T1,length(cointj_ind),length(wavelets));
                postcgatevf_v1=zeros(T1,length(cointj_ind),length(wavelets));
                spreadgatevf_v1=zeros(T1,length(cointj_ind),length(wavelets));
                Rb_v1=zeros(T1,length(cointj_ind),length(wavelets));

                profitgatevf_v2=zeros(length(cointj_ind),length(wavelets));
                tsgatevf_v2=zeros(length(cointj_ind),length(wavelets));
                trade_returngatevf_v2=zeros(T1,length(cointj_ind),length(wavelets));
                postogatevf_v2=zeros(T1,length(cointj_ind),length(wavelets));
                postcgatevf_v2=zeros(T1,length(cointj_ind),length(wavelets));
                spreadgatevf_v2=zeros(T1,length(cointj_ind),length(wavelets));
                Rb_v2=zeros(T1,length(cointj_ind),length(wavelets));

                profitgatevf_v3=zeros(length(cointj_ind),length(wavelets));
                tsgatevf_v3=zeros(length(cointj_ind),length(wavelets));
                trade_returngatevf_v3=zeros(T1,length(cointj_ind),length(wavelets));
                postogatevf_v3=zeros(T1,length(cointj_ind),length(wavelets));
                postcgatevf_v3=zeros(T1,length(cointj_ind),length(wavelets));
                spreadgatevf_v3=zeros(T1,length(cointj_ind),length(wavelets));
                Rb_v3=zeros(T1,length(cointj_ind),length(wavelets));

                profitgatevf_v4=zeros(length(cointj_ind),length(wavelets));
                tsgatevf_v4=zeros(length(cointj_ind),length(wavelets));
                trade_returngatevf_v4=zeros(T1,length(cointj_ind),length(wavelets));
                postogatevf_v4=zeros(T1,length(cointj_ind),length(wavelets));
                postcgatevf_v4=zeros(T1,length(cointj_ind),length(wavelets));
                spreadgatevf_v4=zeros(T1,length(cointj_ind),length(wavelets));
                Rb_v4=zeros(T1,length(cointj_ind),length(wavelets));


                profitgatevf_v5=zeros(length(cointj_ind),length(wavelets));
                tsgatevf_v5=zeros(length(cointj_ind),length(wavelets));
                trade_returngatevf_v5=zeros(T1,length(cointj_ind),length(wavelets));
                postogatevf_v5=zeros(T1,length(cointj_ind),length(wavelets));
                postcgatevf_v5=zeros(T1,length(cointj_ind),length(wavelets));
                spreadgatevf_v5=zeros(T1,length(cointj_ind),length(wavelets));
                Rb_v5=zeros(T1,length(cointj_ind),length(wavelets));

                profitgatevf_v6=zeros(length(cointj_ind),length(wavelets));
                tsgatevf_v6=zeros(length(cointj_ind),length(wavelets));
                trade_returngatevf_v6=zeros(T1,length(cointj_ind),length(wavelets));
                postogatevf_v6=zeros(T1,length(cointj_ind),length(wavelets));
                postcgatevf_v6=zeros(T1,length(cointj_ind),length(wavelets));
                spreadgatevf_v6=zeros(T1,length(cointj_ind),length(wavelets));
                Rb_v6=zeros(T1,length(cointj_ind),length(wavelets));

                profitgatevf_v7=zeros(length(cointj_ind),length(wavelets));
                tsgatevf_v7=zeros(length(cointj_ind),length(wavelets));
                trade_returngatevf_v7=zeros(T1,length(cointj_ind),length(wavelets));
                postogatevf_v7=zeros(T1,length(cointj_ind),length(wavelets));
                postcgatevf_v7=zeros(T1,length(cointj_ind),length(wavelets));
                spreadgatevf_v7=zeros(T1,length(cointj_ind),length(wavelets));
                Rb_v7=zeros(T1,length(cointj_ind),length(wavelets));

                profitgatevf_v8=zeros(length(cointj_ind),length(wavelets));
                tsgatevf_v8=zeros(length(cointj_ind),length(wavelets));
                trade_returngatevf_v8=zeros(T1,length(cointj_ind),length(wavelets));
                postogatevf_v8=zeros(T1,length(cointj_ind),length(wavelets));
                postcgatevf_v8=zeros(T1,length(cointj_ind),length(wavelets));
                spreadgatevf_v8=zeros(T1,length(cointj_ind),length(wavelets));
                Rb_v8=zeros(T1,length(cointj_ind),length(wavelets));

                profitgatevf_v9=zeros(length(cointj_ind),length(wavelets));
                tsgatevf_v9=zeros(length(cointj_ind),length(wavelets));
                trade_returngatevf_v9=zeros(T1,length(cointj_ind),length(wavelets));
                postogatevf_v9=zeros(T1,length(cointj_ind),length(wavelets));
                postcgatevf_v9=zeros(T1,length(cointj_ind),length(wavelets));
                spreadgatevf_v9=zeros(T1,length(cointj_ind),length(wavelets));
                Rb_v9=zeros(T1,length(cointj_ind),length(wavelets));

                profitgatevf_v10=zeros(length(cointj_ind),length(wavelets));
                tsgatevf_v10=zeros(length(cointj_ind),length(wavelets));
                trade_returngatevf_v10=zeros(T1,length(cointj_ind),length(wavelets));
                postogatevf_v10=zeros(T1,length(cointj_ind),length(wavelets));
                postcgatevf_v10=zeros(T1,length(cointj_ind),length(wavelets));
                spreadgatevf_v10=zeros(T1,length(cointj_ind),length(wavelets));
                Rb_v10=zeros(T1,length(cointj_ind),length(wavelets));

                profitgatevf_v11=zeros(length(cointj_ind),length(wavelets));
                tsgatevf_v11=zeros(length(cointj_ind),length(wavelets));
                trade_returngatevf_v11=zeros(T1-22,length(cointj_ind),length(wavelets));
                postogatevf_v11=zeros(T1-22,length(cointj_ind),length(wavelets));
                postcgatevf_v11=zeros(T1-22,length(cointj_ind),length(wavelets));
                spreadgatevf_v11=zeros(T1-22,length(cointj_ind),length(wavelets));
                Rb_v11=zeros(T1,length(cointj_ind),length(wavelets));
                ww=0;
                beta_all=zeros(length(cointj_ind),4);
                alpha_all=zeros(length(cointj_ind),4);
                for wavelet=wavelets
                    ww=ww+1;
                    parfor mc=1:length(cointj_ind) % for each pair, this for loop runs the trading algorithm

                        P=data0([smpl0 smpl1],cointj_ind(mc,1:2)); % Original Price data
                        p1=P(:,1);
                        p2=P(:,2);
                        if dtrndng==0
                            X=[ones(T0,1) p2(1:T0)];
                            Xs=[ones(T0,1) p2(T0+1:T1+T0)];
                        elseif dtrndng==1
                            X=[ones(T0,1) (1:T0)' p2(1:T0)];
                            Xs=[ones(T0,1) (1:T0)' p2(T0+1:T1+T0)];
                        end
                        coeff=inv(X'*X)*X'*p1(1:T0); % OLS coefficients for training sample
                        coeffs=inv(Xs'*Xs)*Xs'*p1(T0+1:T0+T1); % OLS coefficients for trading sample
                        res=p1(1:T0)-X*coeff; 
                        thresh_gatev=2*std(res); % Standard Threshold 
                        %% Wavelet Transform of the Price series
                        P1w0=modwt(P(:,1),char(wavelet),level); 
                        P2w0=modwt(P(:,2),char(wavelet),level);
                        P1wmra0=modwtmra(P1w0,char(wavelet));
                        P2wmra0=modwtmra(P2w0,char(wavelet));
                        P1wmra=P1wmra0(end,:)';
                        P2wmra=P2wmra0(end,:)';
                        Pwmra=[P1wmra P2wmra];
                        Pw=[P1w0(end,:)' P2w0(end,:)'];
                        p1w=Pw(:,1);
                        p2w=Pw(:,2);
                        %%
                        if dtrndng==0
                            Xw=[ones(T0,1) p2w(1:T0)];
                            Xwmra=[ones(T0,1) P2wmra(1:T0)];
                        elseif dtrndng==1
                            Xw=[ones(T0,1) (1:T0)' p2w(1:T0)];
                            Xwmra=[ones(T0,1) (1:T0)' p2wmra(1:T0)];
                        end
                        coeffw=inv(Xw'*Xw)*Xw'*p1w(1:T0); % OLS coefficients for training sample (MODWT)
                        coeffwmra=inv(Xwmra'*Xwmra)*Xwmra'*P1wmra(1:T0); % OLS coefficients for training sample (MRA)
                        %% Finding optimal threshold from the trading period
                        theta0=(coeffw+coeff+coeffs)/3; % Initial condition for optimization
                        options = optimset('Display','off','MaxFunEvals',10000);
                        [coeff_opt,LL2] = fminunc('pairs_trade_profit_fun_optimal',theta0,options,thresh_gatev,P,T0,T1,dtrndng);
                        %%
                        resw=p1w(1:T0)-Xw*coeffw;
                        thresh_gatevw=2*std(resw); % Wavelet Threshold

                        beta_all(mc,:)=[coeff(2) coeffs(2) coeffw(2) coeff_opt(2)]; % Save all  Slope OLS coefficients
                        alpha_all(mc,:)=[coeff(1) coeffs(1) coeffw(1) coeff_opt(2)];% Save all  Intercept OLS coefficients
                        %% Standard Method (Gatev)
                        [profitgatevf0_org,tsgatevf0_org,trade_returngatevf0_org,postgatevf0_org,...
                            spreadgatevf0_org]=pairs_trade_profit_fun_v2([],P,T0,T1,0,0,[],dtrndng); % Main tradin groutine for standard method
                        profitgatevf_org(mc)=profitgatevf0_org; % Total profit from the trade
                        tsgatevf_org(mc)=tsgatevf0_org; % Number of trades
                        spreadgatevf_org(:,mc)=spreadgatevf0_org; % trading period spread
                        trade_returngatevf1_org=zeros(252,1);
                        trade_returngatevf1_org(abs(postgatevf0_org(1:length(trade_returngatevf0_org(trade_returngatevf0_org~=0)),2)))=trade_returngatevf0_org(trade_returngatevf0_org~=0);
                        trade_returngatevf_org(:,mc)=trade_returngatevf1_org; % Trade return 
                        postogatevf1_org=zeros(252,1);
                        postogatevf1_org(1:size(postgatevf0_org,1))=postgatevf0_org(:,1);
                        postogatevf_org(:,mc)=postogatevf1_org; % Trade open periods
                        postcgatevf1_org=zeros(252,1); 
                        postcgatevf1_org(1:size(postgatevf0_org,1))=postgatevf0_org(:,2);
                        postcgatevf_org(:,mc)=postcgatevf1_org; % Trade close periods
                        Rb_org(:,mc)=return_generate(p1,p2,T0,T1,theta,postogatevf1_org,postcgatevf1_org,tsgatevf0_org,coeff);
                        %% Standard Method with OLS coefficients obtained by Wavelet Transform
                        [profitgatevf0_v1,tsgatevf0_v1,trade_returngatevf0_v1,postgatevf0_v1,...
                            spreadgatevf0_v1]=pairs_trade_profit_fun_v2([],P,T0,T1,0,0,coeffw,dtrndng);
                        profitgatevf_v1(mc)=profitgatevf0_v1;
                        tsgatevf_v1(mc)=tsgatevf0_v1;
                        spreadgatevf_v1(:,mc)=spreadgatevf0_v1;
                        trade_returngatevf1_v1=zeros(252,1);
                        trade_returngatevf1_v1(abs(postgatevf0_v1(1:length(trade_returngatevf0_v1(trade_returngatevf0_v1~=0)),2)))=trade_returngatevf0_v1(trade_returngatevf0_v1~=0);
                        trade_returngatevf_v1(:,mc)=trade_returngatevf1_v1;
                        postogatevf1_v1=zeros(252,1);
                        postogatevf1_v1(1:size(postgatevf0_v1,1))=postgatevf0_v1(:,1);
                        postogatevf_v1(:,mc)=postogatevf1_v1;
                        postcgatevf1_v1=zeros(252,1);
                        postcgatevf1_v1(1:size(postgatevf0_v1,1))=postgatevf0_v1(:,2);
                        postcgatevf_v1(:,mc)=postcgatevf1_v1;
                        Rb_v1(:,mc)=return_generate(p1,p2,T0,T1,theta,postogatevf1_v1,postcgatevf1_v1,tsgatevf0_v1,coeffw);
                        %% Standard Method with threshold obtained by Wavelet Transform
                        [profitgatevf0_v2,tsgatevf0_v2,trade_returngatevf0_v2,postgatevf0_v2, ...
                            spreadgatevf0_v2]=pairs_trade_profit_fun_v2(thresh_gatevw,P,T0,T1,0,0,[],dtrndng);
                        profitgatevf_v2(mc)=profitgatevf0_v2;
                        tsgatevf_v2(mc)=tsgatevf0_v2;
                        spreadgatevf_v2(:,mc)=spreadgatevf0_v2;
                        trade_returngatevf1_v2=zeros(252,1);
                        trade_returngatevf1_v2(abs(postgatevf0_v2(1:length(trade_returngatevf0_v2(trade_returngatevf0_v2~=0)),2)))=trade_returngatevf0_v2(trade_returngatevf0_v2~=0);
                        trade_returngatevf_v2(:,mc)=trade_returngatevf1_v2;
                        postogatevf1_v2=zeros(252,1);
                        postogatevf1_v2(1:size(postgatevf0_v2,1))=postgatevf0_v2(:,1);
                        postogatevf_v2(:,mc)=postogatevf1_v2;
                        postcgatevf1_v2=zeros(252,1);
                        postcgatevf1_v2(1:size(postgatevf0_v2,1))=postgatevf0_v2(:,2);
                        postcgatevf_v2(:,mc)=postcgatevf1_v2;
                        Rb_v2(:,mc)=return_generate(p1,p2,T0,T1,theta,postogatevf1_v2,postcgatevf1_v2,tsgatevf0_v2,coeff);
                        %% Standard Method with threshold and OLS coefficients obtained by Wavelet Transform
                        [profitgatevf0_v3,tsgatevf0_v3,trade_returngatevf0_v3,postgatevf0_v3, ...
                            spreadgatevf0_v3]=pairs_trade_profit_fun_v2(thresh_gatevw,P,T0,T1,0,0,coeffw,dtrndng);
                        profitgatevf_v3(mc)=profitgatevf0_v3;
                        tsgatevf_v3(mc)=tsgatevf0_v3;
                        spreadgatevf_v3(:,mc)=spreadgatevf0_v3;
                        trade_returngatevf1_v3=zeros(252,1);
                        trade_returngatevf1_v3(abs(postgatevf0_v3(1:length(trade_returngatevf0_v3(trade_returngatevf0_v3~=0)),2)))=trade_returngatevf0_v3(trade_returngatevf0_v3~=0);
                        trade_returngatevf_v3(:,mc)=trade_returngatevf1_v3;
                        postogatevf1_v3=zeros(252,1);
                        postogatevf1_v3(1:size(postgatevf0_v3,1))=postgatevf0_v3(:,1);
                        postogatevf_v3(:,mc)=postogatevf1_v3;
                        postcgatevf1_v3=zeros(252,1);
                        postcgatevf1_v3(1:size(postgatevf0_v3,1))=postgatevf0_v3(:,2);
                        postcgatevf_v3(:,mc)=postcgatevf1_v3;
                        Rb_v3(:,mc)=return_generate(p1,p2,T0,T1,theta,postogatevf1_v3,postcgatevf1_v3,tsgatevf0_v3,coeffw);
                        %% Standard Method with Delayed Trading
                        [profitgatevf0_v4,tsgatevf0_v4,trade_returngatevf0_v4,postgatevf0_v4, ...
                            spreadgatevf0_v4]=pairs_trade_profit_fun_delayed([],P,T0,T1,0,0,[],dtrndng,delay);
                        profitgatevf_v4(mc)=profitgatevf0_v4;
                        tsgatevf_v4(mc)=tsgatevf0_v4;
                        spreadgatevf_v4(:,mc)=spreadgatevf0_v4;
                        trade_returngatevf1_v4=zeros(252,1);
                        trade_returngatevf1_v4(abs(postgatevf0_v4(1:length(trade_returngatevf0_v4(trade_returngatevf0_v4~=0)),2)))=trade_returngatevf0_v4(trade_returngatevf0_v4~=0);
                        trade_returngatevf_v4(:,mc)=trade_returngatevf1_v4;
                        postogatevf1_v4=zeros(252,1);
                        postogatevf1_v4(1:size(postgatevf0_v4,1))=postgatevf0_v4(:,1);
                        postogatevf_v4(:,mc)=postogatevf1_v4;
                        postcgatevf1_v4=zeros(252,1);
                        postcgatevf1_v4(1:size(postgatevf0_v4,1))=postgatevf0_v4(:,2);
                        postcgatevf_v4(:,mc)=postcgatevf1_v4;
                        Rb_v4(:,mc)=return_generate(p1,p2,T0,T1,theta,postogatevf1_v4,postcgatevf1_v4,tsgatevf0_v4,coeff);
                        %% Standard Method with threshold obtained by Wavelet Transform and Delayed Trading
                        [profitgatevf0_v5,tsgatevf0_v5,trade_returngatevf0_v5,postgatevf0_v5, ...
                            spreadgatevf0_v5]=pairs_trade_profit_fun_delayed(thresh_gatevw,P,T0,T1,0,0,[],dtrndng,delay);
                        profitgatevf_v5(mc)=profitgatevf0_v5;
                        tsgatevf_v5(mc)=tsgatevf0_v5;
                        spreadgatevf_v5(:,mc)=spreadgatevf0_v5;
                        trade_returngatevf1_v5=zeros(252,1);
                        trade_returngatevf1_v5(abs(postgatevf0_v5(1:length(trade_returngatevf0_v5(trade_returngatevf0_v5~=0)),2)))=trade_returngatevf0_v5(trade_returngatevf0_v5~=0);
                        trade_returngatevf_v5(:,mc)=trade_returngatevf1_v5;
                        postogatevf1_v5=zeros(252,1);
                        postogatevf1_v5(1:size(postgatevf0_v5,1))=postgatevf0_v5(:,1);
                        postogatevf_v5(:,mc)=postogatevf1_v5;
                        postcgatevf1_v5=zeros(252,1);
                        postcgatevf1_v5(1:size(postgatevf0_v5,1))=postgatevf0_v5(:,2);
                        postcgatevf_v5(:,mc)=postcgatevf1_v5;
                        Rb_v5(:,mc)=return_generate(p1,p2,T0,T1,theta,postogatevf1_v5,postcgatevf1_v5,tsgatevf0_v5,coeff);
                        %% Standard Method with OLS coefficients obtained by Wavelet Transform and Delayed trading
                        [profitgatevf0_v6,tsgatevf0_v6,trade_returngatevf0_v6,postgatevf0_v6, ...
                            spreadgatevf0_v6]=pairs_trade_profit_fun_delayed([],P,T0,T1,0,0,coeffw,dtrndng,delay);
                        profitgatevf_v6(mc)=profitgatevf0_v6;
                        tsgatevf_v6(mc)=tsgatevf0_v6;
                        spreadgatevf_v6(:,mc)=spreadgatevf0_v6;
                        trade_returngatevf1_v6=zeros(252,1);
                        trade_returngatevf1_v6(abs(postgatevf0_v6(1:length(trade_returngatevf0_v6(trade_returngatevf0_v6~=0)),2)))=trade_returngatevf0_v6(trade_returngatevf0_v6~=0);
                        trade_returngatevf_v6(:,mc)=trade_returngatevf1_v6;
                        postogatevf1_v6=zeros(252,1);
                        postogatevf1_v6(1:size(postgatevf0_v6,1))=postgatevf0_v6(:,1);
                        postogatevf_v6(:,mc)=postogatevf1_v6;
                        postcgatevf1_v6=zeros(252,1);
                        postcgatevf1_v6(1:size(postgatevf0_v6,1))=postgatevf0_v6(:,2);
                        postcgatevf_v6(:,mc)=postcgatevf1_v6;
                        Rb_v6(:,mc)=return_generate(p1,p2,T0,T1,theta,postogatevf1_v6,postcgatevf1_v6,tsgatevf0_v6,coeffw);
                         %% Standard Method with threshold and OLS coefficients obtained by Wavelet Transform and Delayed Trading
                        [profitgatevf0_v7,tsgatevf0_v7,trade_returngatevf0_v7,postgatevf0_v7, ...
                            spreadgatevf0_v7]=pairs_trade_profit_fun_delayed(thresh_gatevw,P,T0,T1,0,0,coeffw,dtrndng,delay);
                        profitgatevf_v7(mc)=profitgatevf0_v7;
                        tsgatevf_v7(mc)=tsgatevf0_v7;
                        spreadgatevf_v7(:,mc)=spreadgatevf0_v7;
                        trade_returngatevf1_v7=zeros(252,1);
                        trade_returngatevf1_v7(abs(postgatevf0_v7(1:length(trade_returngatevf0_v7(trade_returngatevf0_v7~=0)),2)))=trade_returngatevf0_v7(trade_returngatevf0_v7~=0);
                        trade_returngatevf_v7(:,mc)=trade_returngatevf1_v7;
                        postogatevf1_v7=zeros(252,1);
                        postogatevf1_v7(1:size(postgatevf0_v7,1))=postgatevf0_v7(:,1);
                        postogatevf_v7(:,mc)=postogatevf1_v7;
                        postcgatevf1_v7=zeros(252,1);
                        postcgatevf1_v7(1:size(postgatevf0_v7,1))=postgatevf0_v7(:,2);
                        postcgatevf_v7(:,mc)=postcgatevf1_v7;
                        Rb_v7(:,mc)=return_generate(p1,p2,T0,T1,theta,postogatevf1_v7,postcgatevf1_v7,tsgatevf0_v7,coeffw);
                        %% Standard Method with OLS Slope coefficient obtained by Wavelet Transform
                        [profitgatevf0_v8,tsgatevf0_v8,trade_returngatevf0_v8,postgatevf0_v8,...
                            spreadgatevf0_v8]=pairs_trade_profit_fun_v2([],P,T0,T1,0,0,[coeff(1);coeffw(2)],dtrndng);
                        profitgatevf_v8(mc)=profitgatevf0_v8;
                        tsgatevf_v8(mc)=tsgatevf0_v8;
                        spreadgatevf_v8(:,mc)=spreadgatevf0_v8;
                        trade_returngatevf1_v8=zeros(252,1);
                        trade_returngatevf1_v8(abs(postgatevf0_v8(1:length(trade_returngatevf0_v8(trade_returngatevf0_v8~=0)),2)))=trade_returngatevf0_v8(trade_returngatevf0_v8~=0);
                        trade_returngatevf_v8(:,mc)=trade_returngatevf1_v8;
                        postogatevf1_v8=zeros(252,1);
                        postogatevf1_v8(1:size(postgatevf0_v8,1))=postgatevf0_v8(:,1);
                        postogatevf_v8(:,mc)=postogatevf1_v8;
                        postcgatevf1_v8=zeros(252,1);
                        postcgatevf1_v8(1:size(postgatevf0_v8,1))=postgatevf0_v8(:,2);
                        postcgatevf_v8(:,mc)=postcgatevf1_v8;
                        Rb_v8(:,mc)=return_generate(p1,p2,T0,T1,theta,postogatevf1_v8,postcgatevf1_v8,tsgatevf0_v8,[coeff(1);coeffw(2)]);
                        %% Standard Method with OLS coefficients obtained from trading sample
                        [profitgatevf0_v9,tsgatevf0_v9,trade_returngatevf0_v9,postgatevf0_v9, ...
                            spreadgatevf0_v9]=pairs_trade_profit_fun_v2([],P,T0,T1,0,0,[coeffs],dtrndng);
                        profitgatevf_v9(mc)=profitgatevf0_v9;
                        tsgatevf_v9(mc)=tsgatevf0_v9;
                        spreadgatevf_v9(:,mc)=spreadgatevf0_v9;
                        trade_returngatevf1_v9=zeros(252,1);
                        trade_returngatevf1_v9(abs(postgatevf0_v9(1:length(trade_returngatevf0_v9(trade_returngatevf0_v9~=0)),2)))=trade_returngatevf0_v9(trade_returngatevf0_v9~=0);
                        trade_returngatevf_v9(:,mc)=trade_returngatevf1_v9;
                        postogatevf1_v9=zeros(252,1);
                        postogatevf1_v9(1:size(postgatevf0_v9,1))=postgatevf0_v9(:,1);
                        postogatevf_v9(:,mc)=postogatevf1_v9;
                        postcgatevf1_v9=zeros(252,1);
                        postcgatevf1_v9(1:size(postgatevf0_v9,1))=postgatevf0_v9(:,2);
                        postcgatevf_v9(:,mc)=postcgatevf1_v9;
                        Rb_v9(:,mc)=return_generate(p1,p2,T0,T1,theta,postogatevf1_v9,postcgatevf1_v9,tsgatevf0_v9,coeffs);
                         %% Standard Method with Intercept OLS coefficients obtained by Wavelet Transform.
                        [profitgatevf0_v10,tsgatevf0_v10,trade_returngatevf0_v10,postgatevf0_v10,...
                            spreadgatevf0_v10]=pairs_trade_profit_fun_v2([],P,T0,T1,0,0,[coeffw(1);coeff(2)],dtrndng);
                        profitgatevf_v10(mc)=profitgatevf0_v10;
                        tsgatevf_v10(mc)=tsgatevf0_v10;
                        spreadgatevf_v10(:,mc)=spreadgatevf0_v10;
                        trade_returngatevf1_v10=zeros(252,1);
                        trade_returngatevf1_v10(abs(postgatevf0_v10(1:length(trade_returngatevf0_v10(trade_returngatevf0_v10~=0)),2)))=trade_returngatevf0_v10(trade_returngatevf0_v10~=0);
                        trade_returngatevf_v10(:,mc)=trade_returngatevf1_v10;
                        postogatevf1_v10=zeros(252,1);
                        postogatevf1_v10(1:size(postgatevf0_v10,1))=postgatevf0_v10(:,1);
                        postogatevf_v10(:,mc)=postogatevf1_v10;
                        postcgatevf1_v10=zeros(252,1);
                        postcgatevf1_v10(1:size(postgatevf0_v10,1))=postgatevf0_v10(:,2);
                        postcgatevf_v10(:,mc)=postcgatevf1_v10;
                        Rb_v10(:,mc)=return_generate(p1,p2,T0,T1,theta,postogatevf1_v10,postcgatevf1_v10,tsgatevf0_v10,[coeffw(1);coeff(2)]);
                         %% Standard Method Trading stoped 22 days before the sample end
                        [profitgatevf0_v11,tsgatevf0_v11,trade_returngatevf0_v11,postgatevf0_v11,...
                            spreadgatevf0_v11]=pairs_trade_profit_fun_v2([],P,T0,T1-22,0,0,[],dtrndng);
                        profitgatevf_v11(mc)=profitgatevf0_v11;
                        tsgatevf_v11(mc)=tsgatevf0_v11;
                        spreadgatevf_v11(:,mc)=spreadgatevf0_v11;
                        trade_returngatevf1_v11=zeros(230,1);
                        trade_returngatevf1_v11(abs(postgatevf0_v11(1:length(trade_returngatevf0_v11(trade_returngatevf0_v11~=0)),2)))=trade_returngatevf0_v11(trade_returngatevf0_v11~=0);
                        trade_returngatevf_v11(:,mc)=trade_returngatevf1_v11;
                        postogatevf1_v11=zeros(230,1);
                        postogatevf1_v11(1:size(postgatevf0_v11,1))=postgatevf0_v11(:,1);
                        postogatevf_v11(:,mc)=postogatevf1_v11;
                        postcgatevf1_v11=zeros(230,1);
                        postcgatevf1_v11(1:size(postgatevf0_v11,1))=postgatevf0_v11(:,2);
                        postcgatevf_v11(:,mc)=postcgatevf1_v11;
                        Rb_v11(:,mc)=return_generate(p1,p2,T0,T1,theta,postogatevf1_v11,postcgatevf1_v11,tsgatevf0_v11,coeff);
                         %% Wavelet Method with MODWT (Paper's contribution)
                        [profitgatevwf0,tsgatevwf0,trade_returngatevwf0,postgatevwf0,...
                            spreadgatevwf0]=pairs_trade_profit_fun_wave_v2([],P,Pw,T0,T1,0,0,[],dtrndng);
                        profitgatevwf(mc)=profitgatevwf0;
                        tsgatevwf(mc)=tsgatevwf0;
                        spreadgatevwf(:,mc)=spreadgatevwf0;
                        trade_returngatevwf1=zeros(252,1);
                        trade_returngatevwf1(abs(postgatevwf0(1:length(trade_returngatevwf0(trade_returngatevwf0~=0)),2)))=trade_returngatevwf0(trade_returngatevwf0~=0);
                        trade_returngatevwf(:,mc)=trade_returngatevwf1;
                        postogatevwf1=zeros(252,1);
                        postogatevwf1(1:size(postgatevwf0,1))=postgatevwf0(:,1);
                        postogatevwf(:,mc)=postogatevwf1;
                        postcgatevwf1=zeros(252,1);
                        postcgatevwf1(1:size(postgatevwf0,1))=postgatevwf0(:,2);
                        postcgatevwf(:,mc)=postcgatevwf1;
                        Rbw(:,mc)=return_generate(p1,p2,T0,T1,theta,postogatevwf1,postcgatevwf1,tsgatevwf0,coeffw);
                          %% Wavelet Method with OLS coefficients obtained in standard method
                        [profitgatevwf_v20,tsgatevwf_v20,trade_returngatevwf_v20,postgatevwf_v20,...
                            spreadgatevwf_v20]=pairs_trade_profit_fun_wave_v2([],P,Pw,T0,T1,0,0,coeff,dtrndng);
                        profitgatevwf_v2(mc)=profitgatevwf_v20;
                        tsgatevwf_v2(mc)=tsgatevwf_v20;
                        spreadgatevwf_v2(:,mc)=spreadgatevwf_v20;
                        trade_returngatevwf_v21=zeros(252,1);
                        trade_returngatevwf_v21(abs(postgatevwf_v20(1:length(trade_returngatevwf_v20(trade_returngatevwf_v20~=0)),2)))=trade_returngatevwf_v20(trade_returngatevwf_v20~=0);
                        trade_returngatevwf_v2(:,mc)=trade_returngatevwf_v21;
                        postogatevwf_v21=zeros(252,1);
                        postogatevwf_v21(1:size(postgatevwf_v20,1))=postgatevwf_v20(:,1);
                        postogatevwf_v2(:,mc)=postogatevwf_v21;
                        postcgatevwf_v21=zeros(252,1);
                        postcgatevwf_v21(1:size(postgatevwf_v20,1))=postgatevwf_v20(:,2);
                        postcgatevwf_v2(:,mc)=postcgatevwf_v21;
                        Rbw_v2(:,mc)=return_generate(p1,p2,T0,T1,theta,postogatevwf_v21,postcgatevwf_v21,tsgatevwf_v20,coeff);
                          %% Wavelet Method with MRA
                        [profitgatevwf_vmra0,tsgatevwf_vmra0,trade_returngatevwf_vmra0,...
                            postgatevwf_vmra0,spreadgatevwf_vmra0]=pairs_trade_profit_fun_wave_v2([],P,Pwmra,T0,T1,0,0,[],dtrndng);
                        profitgatevwf_vmra(mc)=profitgatevwf_vmra0;
                        tsgatevwf_vmra(mc)=tsgatevwf_vmra0;
                        spreadgatevwf_vmra(:,mc)=spreadgatevwf_vmra0;
                        trade_returngatevwf_vmra1=zeros(252,1);
                        trade_returngatevwf_vmra1(abs(postgatevwf_vmra0(1:length(trade_returngatevwf_vmra0(trade_returngatevwf_vmra0~=0)),2)))=trade_returngatevwf_vmra0(trade_returngatevwf_vmra0~=0);
                        trade_returngatevwf_vmra(:,mc)=trade_returngatevwf_vmra1;
                        postogatevwf_vmra1=zeros(252,1);
                        postogatevwf_vmra1(1:size(postgatevwf_vmra0,1))=postgatevwf_vmra0(:,1);
                        postogatevwf_vmra(:,mc)=postogatevwf_vmra1;
                        postcgatevwf_vmra1=zeros(252,1);
                        postcgatevwf_vmra1(1:size(postgatevwf_vmra0,1))=postgatevwf_vmra0(:,2);
                        postcgatevwf_vmra(:,mc)=postcgatevwf_vmra1;
                        Rbw_vmra(:,mc)=return_generate(p1,p2,T0,T1,theta,postogatevwf_vmra1,postcgatevwf_vmra1,tsgatevwf_vmra0,coeffwmra);

                    end

                end
                % Record the results in a Structure
                profits_j.beta_all=beta_all;
                profits_j.alpha_all=alpha_all;
                profits_j.profitgatevf_org=[cointj_ind profitgatevf_org];
                profits_j.profitgatevwf=[cointj_ind profitgatevwf];
                profits_j.profitgatevwf_v2=[cointj_ind profitgatevwf_v2];

                profits_j.Rb_org=Rb_org;
                profits_j.Rbw=Rbw;
                profits_j.Rbw_v2=Rbw_v2;

                profits_j.tsgatevf_org=[cointj_ind tsgatevf_org];
                profits_j.tsgatevwf=[cointj_ind tsgatevwf];
                profits_j.tsgatevwf_v2=[cointj_ind tsgatevwf_v2];

                profits_j.trade_returngatevwf=trade_returngatevwf;
                profits_j.trade_returngatevwf_v2=trade_returngatevwf_v2;
                profits_j.trade_returngatevf_org=trade_returngatevf_org;

                profits_j.postogatevwf=postogatevwf;
                profits_j.postogatevf_org=postogatevf_org;

                profits_j.postcgatevwf=postcgatevwf;
                profits_j.postcgatevf_org=postcgatevf_org;

                profits_j.spreadgatevf_org=spreadgatevf_org;
                profits_j.spreadgatevwf=spreadgatevwf;

                profits_j.postogatevwf_v2=postogatevwf_v2;
                profits_j.postcgatevwf_v2=postcgatevwf_v2;
                profits_j.spreadgatevwf_v2=spreadgatevwf_v2;

                profits_j.profitgatevwf_vmra=[cointj_ind profitgatevwf_vmra];
                profits_j.tsgatevwf_vmra=[cointj_ind tsgatevwf_vmra];
                profits_j.trade_returngatevwf_vmra=trade_returngatevwf_vmra;
                profits_j.postogatevwf_vmra=postogatevwf_vmra;
                profits_j.postcgatevwf_vmra=postcgatevwf_vmra;
                profits_j.spreadgatevwf_vmra=spreadgatevwf_vmra;
                profits_j.Rbw_vmra=Rbw_vmra;

                profits_j.profitgatevf_v1=[cointj_ind profitgatevf_v1];
                profits_j.tsgatevf_v1=[cointj_ind tsgatevf_v1];
                profits_j.trade_returngatevf_v1=trade_returngatevf_v1;
                profits_j.postogatevf_v1=postogatevf_v1;
                profits_j.postcgatevf_v1=postcgatevf_v1;
                profits_j.spreadgatevf_v1=spreadgatevf_v1;
                profits_j.Rb_v1=Rb_v1;

                profits_j.profitgatevf_v2=[cointj_ind profitgatevf_v2];
                profits_j.tsgatevf_v2=[cointj_ind tsgatevf_v2];
                profits_j.trade_returngatevf_v2=trade_returngatevf_v2;
                profits_j.postogatevf_v2=postogatevf_v2;
                profits_j.postcgatevf_v2=postcgatevf_v2;
                profits_j.spreadgatevf_v2=spreadgatevf_v2;
                profits_j.Rb_v2=Rb_v2;

                profits_j.profitgatevf_v3=[cointj_ind profitgatevf_v3];
                profits_j.tsgatevf_v3=[cointj_ind tsgatevf_v3];
                profits_j.trade_returngatevf_v3=trade_returngatevf_v3;
                profits_j.postogatevf_v3=postogatevf_v3;
                profits_j.postcgatevf_v3=postcgatevf_v3;
                profits_j.spreadgatevf_v3=spreadgatevf_v3;
                profits_j.Rb_v3=Rb_v3;

                profits_j.profitgatevf_v4=[cointj_ind profitgatevf_v4];
                profits_j.tsgatevf_v4=[cointj_ind tsgatevf_v4];
                profits_j.trade_returngatevf_v4=trade_returngatevf_v4;
                profits_j.postogatevf_v4=postogatevf_v4;
                profits_j.postcgatevf_v4=postcgatevf_v4;
                profits_j.spreadgatevf_v4=spreadgatevf_v4;
                profits_j.Rb_v4=Rb_v4;

                profits_j.profitgatevf_v5=[cointj_ind profitgatevf_v5];
                profits_j.tsgatevf_v5=[cointj_ind tsgatevf_v5];
                profits_j.trade_returngatevf_v5=trade_returngatevf_v5;
                profits_j.postogatevf_v5=postogatevf_v5;
                profits_j.postcgatevf_v5=postcgatevf_v5;
                profits_j.spreadgatevf_v5=spreadgatevf_v5;
                profits_j.Rb_v5=Rb_v5;

                profits_j.profitgatevf_v6=[cointj_ind profitgatevf_v6];
                profits_j.tsgatevf_v6=[cointj_ind tsgatevf_v6];
                profits_j.trade_returngatevf_v6=trade_returngatevf_v6;
                profits_j.postogatevf_v6=postogatevf_v6;
                profits_j.postcgatevf_v6=postcgatevf_v6;
                profits_j.spreadgatevf_v6=spreadgatevf_v6;
                profits_j.Rb_v6=Rb_v6;

                profits_j.profitgatevf_v7=[cointj_ind profitgatevf_v7];
                profits_j.tsgatevf_v7=[cointj_ind tsgatevf_v7];
                profits_j.trade_returngatevf_v7=trade_returngatevf_v7;
                profits_j.postogatevf_v7=postogatevf_v7;
                profits_j.postcgatevf_v7=postcgatevf_v7;
                profits_j.spreadgatevf_v7=spreadgatevf_v7;
                profits_j.Rb_v7=Rb_v7;

                profits_j.profitgatevf_v8=[cointj_ind profitgatevf_v8];
                profits_j.tsgatevf_v8=[cointj_ind tsgatevf_v8];
                profits_j.trade_returngatevf_v8=trade_returngatevf_v8;
                profits_j.postogatevf_v8=postogatevf_v8;
                profits_j.postcgatevf_v8=postcgatevf_v8;
                profits_j.spreadgatevf_v8=spreadgatevf_v8;
                profits_j.Rb_v8=Rb_v8;

                profits_j.profitgatevf_v9=[cointj_ind profitgatevf_v9];
                profits_j.tsgatevf_v9=[cointj_ind tsgatevf_v9];
                profits_j.trade_returngatevf_v9=trade_returngatevf_v9;
                profits_j.postogatevf_v9=postogatevf_v9;
                profits_j.postcgatevf_v9=postcgatevf_v9;
                profits_j.spreadgatevf_v9=spreadgatevf_v9;
                profits_j.Rb_v9=Rb_v9;

                profits_j.profitgatevf_v10=[cointj_ind profitgatevf_v10];
                profits_j.tsgatevf_v10=[cointj_ind tsgatevf_v10];
                profits_j.trade_returngatevf_v10=trade_returngatevf_v10;
                profits_j.postogatevf_v10=postogatevf_v10;
                profits_j.postcgatevf_v10=postcgatevf_v10;
                profits_j.spreadgatevf_v10=spreadgatevf_v10;
                profits_j.Rb_v10=Rb_v10;

                profits_j.profitgatevf_v11=[cointj_ind profitgatevf_v11];
                profits_j.tsgatevf_v11=[cointj_ind tsgatevf_v11];
                profits_j.trade_returngatevf_v11=trade_returngatevf_v11;
                profits_j.postogatevf_v11=postogatevf_v11;
                profits_j.postcgatevf_v11=postcgatevf_v11;
                profits_j.spreadgatevf_v11=spreadgatevf_v11;
                profits_j.Rb_v11=Rb_v11;
                % Compute mean profits for each method
                mean_profits_j=[mean(profitgatevwf) mean(profitgatevf_org) mean(profitgatevf_v1) ...
                    mean(profitgatevf_v2) mean(profitgatevf_v3) mean(profitgatevf_v4) mean(profitgatevf_v5) ...
                    mean(profitgatevf_v6) mean(profitgatevf_v7) mean(profitgatevf_v8) mean(profitgatevf_v9) ...
                    mean(profitgatevf_v10 ) mean(profitgatevf_v11 ) mean(profitgatevwf_v2) mean(profitgatevwf_vmra)];

                eval(['save results_pairs_trade_SP500_level_' num2str(level) '_year_' num2str(per) '_detrend_' num2str(dtrndng) 'delay_' num2str(delay) '_model_' num2str(mm) '_wave_' char(wavelets) '_onlygatev theta mean_profits_j profits_j' ])
            end
        end
        clearvars -except data0 per mm
    end
end

%Sample Tables and Figures 
clear
mat=[];
level=1
delay=[22]
matsr=[];

for mm=1:2
    % Profit from the pairs chosen with Johansen test
    mat0=[];
    matsr0=[];
    for per=1:7
        % Cointegration Tests
        ww=0;
        mat00=[];
        matsr00=[];
        for wavelets0={'haar','db2','db6','db8','db10','db12','db14','db16','db18','db20','db22', 'db24', 'sym2','sym6','sym8','sym10','sym12','sym14','sym16','sym18','sym20','sym22', 'sym24','coif1','coif2','coif3','coif4','coif5'};
            ww=ww+1;
            dtrndng=[0];
            eval(['load results_pairs_trade_SP500_level_' num2str(level) '_year_' num2str(per) '_detrend_' num2str(dtrndng) 'delay_' num2str(delay) '_model_' num2str(mm) '_wave_' char(wavelets0) '_onlygatev' ])

            mat00=[mat00 [mm;per;ww;mean(sum(profits_j.Rbw,1))]];
            exreturn=mean(profits_j.Rbw,2);
            matsr00=[matsr00 [mm;per;ww;[sqrt(252)*mean(exreturn)/std(exreturn)]]];
        end
        mat0=[mat0;mat00];
        matsr0=[matsr0;matsr00];
    end
    mat=[mat mat0'];
    matsr=[matsr matsr0'];
end

f = figure();
f.WindowState = 'maximized';
subplot(2,1,1)
matc=mat(:,4:4:7*4);
plot(matc,'LineWidth',2)
labels0 = {'2011-2012','2012-2013','2013-2014','2014-2015',...
    '2015-2016','2016-2017','2017-2018'};
legend(labels0,'Location','bestoutside','Orientation','horizontal')
% a = gca;
waveletsl={'haar','db2','db6','db8','db10','db12','db14','db16','db18','db20','db22', 'db24', 'sym2','sym6','sym8','sym10','sym12','sym14','sym16','sym18','sym20','sym22', 'sym24','coif1','coif2','coif3','coif4','coif5'};
set(gca,'xtick',[1:28],'xticklabel',waveletsl)
% a.XTickLabel = waveletsl;
title("Cointegration")
set(gca,'FontSize', 16)
ylim([-0.1 0.15])
subplot(2,1,2)
matc=mat(:,4*8:4:end);
plot(matc,'LineWidth',2)
labels0 = {'2011-2012','2012-2013','2013-2014','2014-2015',...
    '2015-2016','2016-2017','2017-2018'};
legend(labels0,'Location','bestoutside','Orientation','horizontal')
% a = gca;
waveletsl={'haar','db2','db6','db8','db10','db12','db14','db16','db18','db20','db22', 'db24', 'sym2','sym6','sym8','sym10','sym12','sym14','sym16','sym18','sym20','sym22', 'sym24','coif1','coif2','coif3','coif4','coif5'};
set(gca,'xtick',[1:28],'xticklabel',waveletsl)
% a.XTickLabel = waveletsl;
title("Minimum Distance")
set(gca,'FontSize', 16)
ylim([-0.1 0.15])

