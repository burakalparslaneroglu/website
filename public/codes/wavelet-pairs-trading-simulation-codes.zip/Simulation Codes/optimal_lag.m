function [opt_lag]=optimal_lag(y,maxlag);
[n d]=size(y);
for i=1:maxlag;
    results = uvar(y,i);
%     [A,SIGMA,U,V]=olsvarc(y,i);
%     results.sigma=SIGMA;
    aic(i)=log(det(results.sigma))+2*(d+(d^2)*i)/n;
    bic(i)=log(det(results.sigma))+2*(d+(d^2)*i)*log(log(n))/n;
    sic(i)=log(det(results.sigma))+(d+(d^2)*i)*log(n)/n;
    like(i)=log(det(results.sigma));
end
j=maxlag;
ret=0;
while ret==0 & j>1;
    lr=(n-j*d)*(like(j-1)-like(j));
    rest=(d^2);
    chi_crit=chi2inv(0.95,rest);
    if j==1;
        ret=1
        opt_lag.lr=1;
    end
    if lr>=chi_crit
        ret=1;
        opt_lag.lr=j;
    else
        ret=0;
    end
    j=j-1;
end
 opt_lag.aic=find(aic==(min(min(aic))));
 opt_lag.bic=find(bic==(min(min(bic))));
 opt_lag.sic=find(sic==(min(min(sic))));
    
 