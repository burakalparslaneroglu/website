function [profit,ts,trade_return,post,spread]=pairs_trade_profit_fun_wave_v2(thresh,P,Pw,T0,T1,choose_thresh,b1,coeff,dtrndng)
%This is the main function to determine trading signal threshold, coefficient
%estimates, Spread calculation, trade opening and closing decisions for a
%given training and trading period.
% INPUTS: 1) Thresh (can be empty): User supplied threshold, 2) P: original
% price matrix. The first T0 observation is the training period, and the
% last T1 observation belongs to the trading period. 3) Pw: Wavelet
% transformed version of P, 4) T0: sample size of training period, 5) T1:
% sample size of trading period, 6) choose_thresh (can be empty): 1 if
% threshold needs to be computed inside the function, 0 otherwise.
% This takes value 1 if we only want to compute threshold with this function,
% 7) coeff (can be empty): user supplied spread
% coefficients. If empty, coefficients will be estimated inside the
% function, 8) dtrndng: if 0 only an intercept term is included in spread
% model, if 1 an intercept and trend term are included.
% OUTPUTS: 1) Profit: total profit from the trades, 2) ts: the number of
% trades,  3) trade_return: a matrix containing returns of individual
% trades, 4) post: trade opening and closing times. 5) spread: training
% sample spread.
p1=Pw(:,1); % The Wavelet transformed Price of the first stock (full sample)
p2=Pw(:,2); % The Wavelet transformed Price of the second stock (full sample)
p10=P(:,1); % The Original Price of the first stock (full sample)
p20=P(:,2); % The Original Price of the Second stock (full sample)
p1t=p1(T0+1:T0+T1); % The Wavelet transformed Price of the first stock (trading sample)
p2t=p2(T0+1:T0+T1); % The Wavelet transformed Price of the second stock (trading sample)
p1t0=p10(T0+1:T0+T1); % The Original Price of the first stock (trading sample)
p2t0=p20(T0+1:T0+T1); % The Original Price of the second stock (trading sample)
if choose_thresh==1 % Adjust data for threshold determination from the training sample
    p1t=p1(1:T0);
    p2t=p2(1:T0);
    p1t0=p10(1:T0);
    p2t0=p20(1:T0);
    T1=T0;
end
%% Determination of Spread Coefficients from Training period
if ~isempty(coeff) % if coeff is supplied, use these values
    a=coeff(1); % intercept term
    b=coeff(2); % slope term
else % otherwise estimate the coefficients with OLS.
    if dtrndng==0 %
        [~,~,~,~,reg] = egcitest([p1(1:T0) p2(1:T0)]); %p1=a+b*p2+e
        b=reg(1).coeff(2);
        a=reg(1).coeff(1);
    elseif dtrndng==1
        [~,~,~,~,reg] = egcitest([p1(1:T0) p2(1:T0)],'creg','ct'); %p1=a+b*p2+c*t+e
        b=reg(1).coeff(3);
        a=reg(1).coeff(1);
        c=reg(1).coeff(2); % Trend coefficient
    end
end
%% Trading period Spread computation
if dtrndng==0
    if a==0 && b==1 % Gatev case (normalized prices)
        spread=p1t/p1(T0)-b*p2t/p2(T0);
        ncons1=p1(T0);
        ncons2=p2(T0);
    else
        spread=p1t-b*p2t-a; %residuals from cointegrating regression
        ncons1=1;
        ncons2=1;
    end
elseif dtrndng==1
    if choose_thresh==0
        %         trnd=((T0+1:T0+T1))';
        trnd=((1:T1))';
    else
        trnd=((1:T0))';
    end
    spread=p1t-b*p2t-a-c*trnd; %residuals from cointegrating regression
end
%% Threshold Determination for Training Sample
if isempty(thresh)
    if a==0 && b==1
        if dtrndng==0
            thresh=2*std(p1(1:T0)/p1(1)-a-b*p2(1:T0)/p2(1)); % threshold in Gatev et al.
        elseif dtrndng==1
            thresh=2*std(p1(1:T0)/p1(1)-a-b*p2(1:T0)/p2(1)-c*(1:T0)');
        end
    else
        if dtrndng==0
            thresh=2*std(p1(1:T0)-a-b*p2(1:T0)); % threshold in Gatev et al.
        elseif dtrndng==1
            thresh=2*std(p1(1:T0)-a-b*p2(1:T0)-c*(1:T0)');
        end
    end
end
%% Determination of Trade Open or Close
post=zeros(T1,2);
ts=0;
sign_spread=sign(spread); % Sign of the spread will be used to determine which stock to short and long
change_direction=double([0;diff([sign_spread])]~=0); % this will be used to understand when we need to close the trade
openpos=zeros(T1,1); % This saves the opening times of the trades

if spread(1)>=thresh % Beginning of the sample
    ts=ts+1;
    post(ts,1)=1;
    openpos(1)=1;
elseif spread(1)<=-thresh
    ts=ts+1;
    post(ts,1)=-1;
    openpos(1)=-1;
end

for t=2:T1
    if spread(t)>=thresh && openpos(t-1)==0 % if spread exceeds threshold and the trade has not opened yet.
        ts=ts+1;
        post(ts,1)=t; % Trade opening time
        openpos(t)=1;
    elseif spread(t)<-thresh && openpos(t-1)==0
        ts=ts+1;
        post(ts,1)=-t; % negative sign indicates the position of the spread relative to zero line
        openpos(t)=-1;
    end
    if change_direction(t)==0 && openpos(t-1)==1 % Ensure that routine does not try to open another trade while the other is opened.
        openpos(t)=1;
    elseif change_direction(t)==0 && openpos(t-1)==-1
        openpos(t)=-1;
    end

    if change_direction(t)==1 && openpos(t-1)==1 % If the spread change direction when the trade is opened, we close the trade
        post(ts,2)=t;
    elseif change_direction(t)==1 && openpos(t-1)==-1
        post(ts,2)=-t; % negative sign indicates the position of the spread relative to zero line
    end

end
post=post(1:ts,:); % Remove redundant observations
%% Computation of Profit or Loss
profit_1dollar=0;
% if b1==1
%     b=1;
% end
trade_return=zeros(ts,2); % Individual Trade Return
p1t0=p1t0/ncons1;
p2t0=p2t0/ncons2;
if ts>0
    if post(ts,2)==0 % Force close the trade if it is opened but not closed before the end of the trading period
        post(ts,2)=T1;
    end
    postabs=abs(post); % For indexing
    if ~isempty(post)

        for tr=1:ts
            if sign(post(tr,1))==1 % If spread is positive, we long stock 2 and short stock 1
                trade_return(tr,1)=((p1t0(postabs(tr,1))-p1t0(postabs(tr,2)))/p1t0(postabs(tr,1)))+...
                    abs(b)*((p2t0(postabs(tr,2))-p2t0(postabs(tr,1)))/p2t0(postabs(tr,1)));% Trade return
                profit_1dollar=profit_1dollar+trade_return(tr,1); % Trade profit
            else % If spread is positive, we long stock 1 and short stock 2
                trade_return(tr,2)=((p1t0(postabs(tr,2))-p1t0(postabs(tr,1)))/p1t0(postabs(tr,1)))+...
                    abs(b)*((p2t0(postabs(tr,1))-p2t0(postabs(tr,2)))/p2t0(postabs(tr,1))); % Trade return
                profit_1dollar=profit_1dollar+trade_return(tr,2);
            end

            %             if sign(post(tr,1))==1
            %                 profit_1stock=profit_1stock+((p1t0(postabs(tr,1))-p1t0(postabs(tr,2)))/p1t0(postabs(tr,1)))+...
            %                     abs(b)*((p2t0(postabs(tr,2))-p2t0(postabs(tr,1)))/p2t0(postabs(tr,1)));
            %             else
            %                 profit_1stock=profit_1stock+(p1t0(postabs(tr,2))-p1t0(postabs(tr,1)))+...
            %                     abs(b)*(p2t0(postabs(tr,1))-p2t0(postabs(tr,2)));
            %             end


        end
    end
end
profit=[profit_1dollar]; % Total Profit