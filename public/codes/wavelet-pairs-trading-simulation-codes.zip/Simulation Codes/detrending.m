function [yhat]=detrending(y,p)
T=length(y);
yhat=y;
if p>-1
    reg=[];
    for i=0:p
        reg=[reg (1:T)'.^i];
    end
    yhat=y-reg*((reg'*reg)\(reg'*y));
end
