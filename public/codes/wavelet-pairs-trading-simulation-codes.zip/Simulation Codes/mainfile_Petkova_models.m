% This file runs Petkova Asset pricing tests for the wavelet returns
% OLS estimates, associated t statistics,  and R^2 (standard and adjusted) are saved in an array

clear
clc
close all

%% Data
% load data_SP500_cleared % Data is not shared becauce of copyright issues.
% data_SP500_cleared contains a dataset called dataff. The first columns is the
% dates, the remaining 415 series are stock prices from SP500 index. The
% below code does minor data cleaning. But one can easily use the remaining
% code for a given data set.
load FMdata % Fama French Factors

level=1; % wavelet level
clearvars data dataf
init=max(find(diff(datenum(dataff.Dates))>5))+1;
dataff0=dataff(init:end,:);
dtrndng=0;
TT=length(dataff0);
TY=floor(TT/252);
T=TY*252;
data0=double(dataff0(1:T,2:end));
dates0=dataff0.Dates(253:T);
datanames=dataff0.Properties.VarNames(2:end);
%% Most of the variables defined in this file are same as in mainfile_FM_regressions.m
warning('off')
theta=0; % Transaction cost
if theta==0
load Returns_theta0
elseif theta==0.001
    load Returns_theta1
end
clear -regexp ^mat
dtrndng=[0];
model={'I','II','III','IV'}; % Model type
st={'fc','pc','nc','no'} % State type
mat_full=[];
mat_fc=[];
mat_fcw=[];
mat_transition=[];
for mm=[1 2]
    % For wavelet trade only
    y0d=ywf(:,mm);
    y0d(isnan(y0d))=0;
    [~,ia,~] = intersect(datenum(FM.Date),datenum(dates0));
    X=double(FM(ia,2:end))/100;
    % Petkova Test Starts here
    Y=X(:,[10 18 15 17 16 3 2]);
    Y=detrend(Y,'constant');
    mdl_var=varm(size(Y,2),1);
    mdl_var_est=estimate(mdl_var,Y);
    ehat = infer(mdl_var_est,Y);
    uhat=ehat*inv(chol(cov(ehat)))*sqrt(var(X(:,10)));
    
    mdl = fitlm([X(2:end,10) uhat(:,2:end)],y0d(2:end)-X(2:end,9));
    
    eval(['mat_Petkova_Full_sample(:,:,mm)=[table2array(mdl.Coefficients);[ones(1,2)*mdl.Rsquared.Ordinary ones(1,2)*mdl.Rsquared.Adjusted]];'])
    n=size(table2array(mdl.Coefficients));
    mat0=[table2array(mdl.Coefficients);[ones(1,2)*mdl.Rsquared.Ordinary ones(1,2)*mdl.Rsquared.Adjusted]];
    mat0(isinf(mat0))=NaN;
    mat_full=[mat_full;[mm*ones(n(1)+1,1) [(0:n(1)-1)';999] mat0]];

end
clearvars -except -regexp ^mat
save Results_Petkova_Factor_wavelet_excess_returns