function [dx]=fracdiff(x,d);
T=length(x);
np2=2.^nextpow2(2*T-1);
k=(1:T-1)';
b=[1;cumprod((k-d-1)./k)];
dx=ifft(fft(x,np2).*fft(b,np2));
dx=dx(1:T,:);

