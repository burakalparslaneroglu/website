% This code loads the results from mainfile_basic_simulations and conduct
% unit root tests for the spreads.
clear
close all
clc

level=1; % Wavelet Transform level
nper=7; % Number for trading period
wavelets={'haar','sym12','sym14','sym18','sym22'};
st={'fc','pc','nc','no'}
warning('off')
wavelets0=wavelets{5};

mat_fulls=[];
mat_fullw=[];
mat_fulld=[];
mat_var_exp=[];
stationary_spread=[];
stationary_spread_all_transition=[];
penalty=0; % lag length Selection criterion in unit root tests 0: MIC
for dtrnding=[0 1];
    %% Simulating the unit root critical values
    penalty=0;
    MC=100000;
    mzac=zeros(MC,1);
    mztc=zeros(MC,1);
    msbc=zeros(MC,1);
    parfor mc=1:MC
        ysim=cumsum(randn(1000,1));
        [~,mzac0,msbc0,~,~,~,~,mztc0,~,~,~,~,~,~,~,~,~,~,~,~]=unit_roots(ysim,dtrnding,penalty,0,0);
        y=randn(T,1);
        mzac(mc)=mzac0(1);
        mztc(mc)=mztc0(1);
        msbc(mc)=msbc0(1);
        
    end
    %%   
    for mm=1:2
        
        for per=1:nper
            for s1=1:length(st)
                for s2=1:length(st)
                    eval(['stationary_spread_' st{s1} '_' st{s2} 'w=[];'])
                end
            end
            per
            smpl0=(per-1)*252+1:(per)*252; % Testing period
            smpl1=(per)*252+1:(per+1)*252; % Trading period
             % Load the trading results 
            eval(['load results_pairs_trade_SP500_level_' num2str(level) '_year_' num2str(per) '_detrend_' num2str(dtrndng) 'delay_22_model_' num2str(mm) '_wave_' char(wavelets0) '_onlygatev' ])
            pairs_ind=profits_j.profitgatevf_org(:,1:2);
            pairs_indw=profits_j.profitgatevwf(:,1:2);
            pairs_ind_fc=find((max(abs(profits_j.postcgatevf_org))'~=252&profits_j.tsgatevf_org(:,3)>=1)==1); % Fully convergent (Standard)
            pairs_ind_pc=find((max(abs(profits_j.postcgatevf_org))'==252&profits_j.tsgatevf_org(:,3)>1)==1); % Partially convergent (Standard)
            pairs_ind_nc=find((max(abs(profits_j.postcgatevf_org))'==252&profits_j.tsgatevf_org(:,3)==1)==1); %Nonconvergent (Standard)
            pairs_ind_no=find((profits_j.tsgatevf_org(:,3)==0)); % No Trade (Standard)
            
            pairs_ind_fcw=find((max(abs(profits_j.postcgatevwf))'~=252&profits_j.tsgatevwf(:,3)>=1)==1);% Fully convergent (Wavelet)
            pairs_ind_pcw=find((max(abs(profits_j.postcgatevwf))'==252&profits_j.tsgatevwf(:,3)>1)==1); % Partially convergent (Wavelet)
            pairs_ind_ncw=find((max(abs(profits_j.postcgatevwf))'==252&profits_j.tsgatevwf(:,3)==1)==1); %Nonconvergent (Wavelet)
            pairs_ind_now=find((profits_j.tsgatevwf(:,3)==0)); %No Trade (Wavelet)
            
            pairs_ind_fc0=((max(abs(profits_j.postcgatevf_org))'~=252&profits_j.tsgatevf_org(:,3)>=1)==1);
            pairs_ind_pc0=((max(abs(profits_j.postcgatevf_org))'==252&profits_j.tsgatevf_org(:,3)>1)==1);
            pairs_ind_nc0=((max(abs(profits_j.postcgatevf_org))'==252&profits_j.tsgatevf_org(:,3)==1)==1);
            pairs_ind_no0=((profits_j.tsgatevf_org(:,3)==0));
            
            pairs_ind_fcw0=((max(abs(profits_j.postcgatevwf))'~=252&profits_j.tsgatevwf(:,3)>=1)==1);
            pairs_ind_pcw0=((max(abs(profits_j.postcgatevwf))'==252&profits_j.tsgatevwf(:,3)>1)==1);
            pairs_ind_ncw0=((max(abs(profits_j.postcgatevwf))'==252&profits_j.tsgatevwf(:,3)==1)==1);
            pairs_ind_now0=((profits_j.tsgatevwf(:,3)==0));
            %% Transition indices
            pairs_ind_fc_fcw=find(pairs_ind_fc0+pairs_ind_fcw0==2);
            pairs_ind_fc_pcw=find(pairs_ind_fc0+pairs_ind_pcw0==2);
            pairs_ind_fc_ncw=find(pairs_ind_fc0+pairs_ind_ncw0==2);
            pairs_ind_fc_now=find(pairs_ind_fc0+pairs_ind_now0==2);
            
            pairs_ind_pc_fcw=find(pairs_ind_pc0+pairs_ind_fcw0==2);
            pairs_ind_pc_pcw=find(pairs_ind_pc0+pairs_ind_pcw0==2);
            pairs_ind_pc_ncw=find(pairs_ind_pc0+pairs_ind_ncw0==2);
            pairs_ind_pc_now=find(pairs_ind_pc0+pairs_ind_now0==2);
            
            pairs_ind_nc_fcw=find(pairs_ind_nc0+pairs_ind_fcw0==2);
            pairs_ind_nc_pcw=find(pairs_ind_nc0+pairs_ind_pcw0==2);
            pairs_ind_nc_ncw=find(pairs_ind_nc0+pairs_ind_ncw0==2);
            pairs_ind_nc_now=find(pairs_ind_nc0+pairs_ind_now0==2);
            
            pairs_ind_no_fcw=find(pairs_ind_no0+pairs_ind_fcw0==2);
            pairs_ind_no_pcw=find(pairs_ind_no0+pairs_ind_pcw0==2);
            pairs_ind_no_ncw=find(pairs_ind_no0+pairs_ind_ncw0==2);
            pairs_ind_no_now=find(pairs_ind_no0+pairs_ind_now0==2);
            
            y=profits_j.spreadgatevf_org; % Standard Spread
            yw=profits_j.spreadgatevwf; % Wavelet Spread
            T=length(y);
            kmax=floor(12*(T/100)^0.25); % maximum lag length
            kmin=0; % minimum lag length
            mat=[];
            matw=[];
            parfor mc=1:size(y,2)
                [~,mza,msb,adft,adfa,~,~,mzt,~,~,~,~,~,~,~,~,~,a1,~,~]=unit_roots(y(:,mc),dtrnding,penalty,kmax,kmin);
                mat0=[mzt(1) quantile(mztc,0.05) 1-sum(mzt(1)<=mztc)/length(mztc) var(y(:,mc))]; % Unit root tests for standard spread. We consider MZ test.
                mat=[mat;mat0];
                
                [~,mzaw,msbw,adftw,adfaw,~,~,mztw,~,~,~,~,~,~,~,~,~,a1w,~,~]=unit_roots(yw(:,mc),dtrnding,penalty,kmax,kmin);
                mat0w=[mztw(1) quantile(mztc,0.05) 1-sum(mztw(1)<=mztc)/length(mztc) var(yw(:,mc))]; % Unit root tests for wavelet spread. We consider MZ test.
                matw=[matw;mat0w];
            end
            stationary_spread=[stationary_spread;[mm per dtrnding sum(mat(:,3)<0.05)/length(mat) sum(matw(:,3)<0.05)/length(matw) sum(matw(mat(:,3)>0.05,3)<0.05)/length((mat(:,3)>0.05))]]; % rejection frequencies
            % Generate results for different state and transition groups
            for s1=1:length(st)
                for s2=1:length(st)
                    eval(['mats=mat(pairs_ind_' st{s1} '_' st{s2} 'w,3);'])
                    eval(['matws=matw(pairs_ind_' st{s1} '_' st{s2} 'w,3);'])
                    if isempty(mats) || isempty(matw)
                        eval(['stationary_spread_' st{s1} '_' st{s2} 'w=[stationary_spread_' st{s1} '_' st{s2} 'w;[dtrnding mm per s1 s2 0 nan(1,3)]];'])
                    else
                        eval(['stationary_spread_' st{s1} '_' st{s2} 'w=[stationary_spread_' st{s1} '_' st{s2} 'w;[dtrnding mm per s1 s2 length(mats) sum(mats<0.05)/length(mats) sum(matws<0.05)/length(matws) sum(matws(mats>0.05)<0.05)/length((mats>0.05))]];'])
                    end
                    eval(['stationary_spread_all_transition=[stationary_spread_all_transition;[stationary_spread_' st{s1} '_' st{s2} 'w]];'])
                end
            end   
        end
    end    
end
