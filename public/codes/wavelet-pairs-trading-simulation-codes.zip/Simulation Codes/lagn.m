function y= lagn(x,n);
   
    if n > 0;
    y = [zeros(n,size(x,2));trimr(x,0,n)];
    else;
    y = [trimr(x,abs(n),0);zeros(abs(n),size(x,2))];
    end;
