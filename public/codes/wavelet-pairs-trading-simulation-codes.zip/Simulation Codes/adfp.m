function [adft,adfa,rho1,s2vec]=adfp(yt,kstar);
T=length(yt)-1;
reg=lagn(yt,1);
dyt=diffk(yt,1);
i=1;
while i <= kstar;
reg=[reg lagn(dyt,i)];
i=i+1;
end;
dyt=trimr(dyt,kstar+1,0);
reg=trimr(reg,kstar+1,0);
[rho,ee,ff]=olsqr2(dyt,reg);
% /*nef=rows(ee);*/
nef=size(dyt,1);
s2e=ee'*ee/nef;
xx=inv(reg'*reg);
sre=xx(1,1)*s2e;
adft=rho(1)/sqrt(sre);
if kstar> 0;
sumb=sum(rho(2:kstar+1));
else;
sumb=0;
end;
adfa=T*rho(1)/(1-sumb);
s2vec=s2e/(1-sumb)^2;
rho1=rho(1,1)+1;

