function retp= diffk(x,k) 
     if k == 0 
        retp=x;
     end 
     retp=[zeros(k,size(x,2));trimr(x,k,0)-trimr(lagn(x,k),k,0)];
