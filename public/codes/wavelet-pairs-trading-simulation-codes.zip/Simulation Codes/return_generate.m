function [Rb]=return_generate(p1,p2,T0,T1,theta,postogatevf,postcgatevf,tsgatevf,coeff0)
%This function generates Returns from output of pairs_trade_profit_fun_v2
%and pairs_trade_profit_fun_wave_v2 functions using the formulation in the
%paper.
Rb=zeros(T1,1);

p11=p1(T0+1:T0+T1);
p21=p2(T0+1:T0+T1);

post=[postogatevf postcgatevf];
post=post(1:tsgatevf,:);

for i=1:size(post,1)
    for t=abs(post(i,1))+1:abs(post(i,2))
        Rb(t)=sign(post(i,1))*(-((p11(t)-p11(t-1))/p11(abs(post(i,1))))+abs(coeff0(2))*((p21(t)-p21(t-1))/p21(abs(post(i,1)))));
        if t==abs(post(i,1))+1
            Rb(t)=Rb(t)-theta*((1+abs(coeff0(2))));
        end
        if t==abs(post(i,2))
            Rb(t)=Rb(t)-theta*(p11(abs(post(i,2)))/p11(abs(post(i,1)))+abs(coeff0(2))*p21(abs(post(i,2)))/p21(abs(post(i,1))));
        end
    end
end
