function [mu,phi] = isolator(beta,k,p);
% PURPOSE: Creates a sequence of vectors and matrices
%          of dimension 1 and mm, respectively
% ------------------------------------------------------------
% SYNTAX: matrix = isolator(beta,k,p);
% ------------------------------------------------------------
% OUTPUT: A vector (mu: kx1) and p matices phi indexed by h=1:p
% ------------------------------------------------------------
% INPUT: beta: vector to be segmented
%		   k   : number of series
%        p   : number of lags

% ------------------------------------------------------------
% written by:
%  Enrique M. Quilis
%  Macroeconomic Research Department
%  Ministry of Economy and Finance
%  Paseo de la Castellana, 162. Office 2.5-1.
%  28046 - Madrid (SPAIN)
%  <enrique.quilis@meh.es>


aux = desvec(beta,k)';

% Generating mu
mu = aux(:,1);

% Generating phi(h)  h=1:p
phi = zeros(k,k,p);  

Li=2; Ls=k+1;
for h=1:p
   phi(:,:,h) = aux(:,Li:Ls);
   Li = Ls + 1;
   Ls = (h+1)*k + 1;
end;

