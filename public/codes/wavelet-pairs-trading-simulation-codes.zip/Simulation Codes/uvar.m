function [res] = uvar(Z,p)
% PURPOSE: Unrestricted estimation of a VAR model
% ------------------------------------------------------------
% SYNTAX:  res = uvar(Z,p)
% ------------------------------------------------------------
% MODEL: Z(t)=mu+phi(1)*Z(t-1)+ ... +phi(p)*Z(t-p)+U(t)
%        U(t) : iid (0, sigma)
% ------------------------------------------------------------
% OUTPUT: a structure
%          res.meth        = label
%          res.parm        = number of: observations, effective 
%                            observations, series, order of VAR model
%          res.mu          = kx1 intercept
%          res.mu_dt       = kx1 intercept: standard errors
%          res.mu_t        = kx1 intercept: t-ratios
%          res.phi         = kxkxp matrices of parameters PHI(h) h=1..p
%          res.phi_dt      = PHI(h) parameters: standard errors
%          res.phi_t       = PHI(h) parameters: t-ratios
%          res.U           = (n-p)xk residuals
%          res.sigma       = VCV matrix of residuals
%          res.sigma_corr  = correlation matrix of residuals
%          res.perform     = log-likelihood,statistics AIC and BIC
% ------------------------------------------------------------
% INPUT: Z    = an nxk matrix of original series, columnwise
%        p    = order of the model
% ------------------------------------------------------------
% LIBRARY: lag, vec, desvec, isolator
% ------------------------------------------------------------
% SEE ALSO: var_prt, bvar

% ------------------------------------------------------------
% written by:
%  Enrique M. Quilis
%  Macroeconomic Research Department
%  Ministry of Economy and Finance
%  Paseo de la Castellana, 162. Office 2.5-1.
%  28046 - Madrid (SPAIN)
%  <enrique.quilis@meh.es>

[n,k] = size(Z);
nobs = n-p;  % Number of effective observations

% ------------------------------------------------------------
%       PREPARING THE MODEL Z = X * beta + U
% ------------------------------------------------------------

% Set of common regressors up to lag p: Z(t-1)..Z(t-p).
% Automatically includes a dummy (=1) for the intercept

X = lag(Z,p);

% Set of (stacked) variables Z(t)

Z_big = vec(Z(p+1:n,:));

% ------------------------------------------------------------
%       ESTIMATION OF THE MODEL
%       Note: if a full system estimation is required, then use
%			beta  = (kron(eye(k), (X'*X) \ X')) * Z_big; 
%       instead of the following j-loop
% ------------------------------------------------------------

Zj = Z(p+1:n,1);
beta = (X'*X) \  (X'*Zj);

for j=2:k
   Zj = Z(p+1:n,j);
   betaj = (X'*X) \  (X'*Zj);
   beta =[ beta
      betaj ];
end

% Residuals   

U_big = Z_big - (kron(eye(k),X'))'*beta;
U     = desvec(U_big,k);

% VCV and correlation of residuals   

sigma = cov(U,1);
sigma_corr = corrcoef(U);

% VCV and t-ratios de beta parameters

beta_dt  = sqrt(diag(kron(sigma, inv(X'*X))));
beta_t   = beta ./ beta_dt;

sigma_det = det(sigma);

% Performance measures

log_like = -0.5*nobs*(k*(1+log(2*pi))+log(sigma_det));
npar = k*k*p+k;

aic = -(2*log_like/nobs) + (2*npar)/nobs;
bic = -(2*log_like/nobs) + npar*(log(nobs)/nobs);

% ------------------------------------------------------------
%       ISOLATING THE MATRICES
% ------------------------------------------------------------

[mu,phi] = isolator(beta,k,p);
[mu_dt,phi_dt] = isolator(beta_dt,k,p);
[mu_t,phi_t] = isolator(beta_t,k,p);

% ------------------------------------------------------------
%       LOADING THE STRUCTURE

res.meth       = 'VAR MODEL: UNRESTRICTED ESTIMATION';
res.parm       = [n,nobs,k,p];
res.mu         = [mu];
res.mu_dt      = [mu_dt];
res.mu_t       = [mu_t];
res.phi        = [phi];
res.phi_dt     = [phi_dt];
res.phi_t      = [phi_t];
res.U          = [U];
res.sigma      = [sigma];
res.sigma_corr = [sigma_corr]; 
res.perform    = [log_like,aic,bic];
