function [profit,ts,trade_return,post,spread]=pairs_trade_profit_fun_v2(thresh,P,T0,T1,choose_thresh,b1,coeff,dtrndng)
%This is the main function to determine trading signal threshold, coefficient
%estimates, Spread calculation, trade opening and closing decisions for a
%given training and trading period.
% INPUTS: 1) Thresh (can be empty): User supplied threshold, 2) P: original
% price matrix. The first T0 observation is the training period, and the
% last T1 observation belongs to the trading period. 3) T0: sample size of training period, 4) T1:
% sample size of trading period, 5) choose_thresh (can be empty): 1 if
% threshold needs to be computed inside the function, 0 otherwise. Either
% thresh should be nonempty or choose_thresh=1, 6) coeff (can be empty): user supplied spread
% coefficients. If empty, coefficients will be estimated inside the
% function, 7) dtrndng: if 0 only an intercept term is included in spread
% model, if 1 an intercept and trend term are included.
% OUTPUTS: 1) Profit: total profit from the trades, 2) ts: the number of
% trades,  3) trade_return: a matrix containing returns of individual
% trades, 4) post: trade opening and closing times. 5) spread: training
% sample spread.
% The definition of segments and variables are same as in
% pairs_trade_profit_fun_wave_v2.m
p1=P(:,1);
p2=P(:,2);
p1t=p1(T0+1:T0+T1);
p2t=p2(T0+1:T0+T1);
if choose_thresh==1 % for choosing threshold from the in-sample
    p1t=p1(1:T0);
    p2t=p2(1:T0);
    T1=T0;
end
if ~isempty(coeff)
    a=coeff(1);
    b=coeff(2);
else
    if dtrndng==0
        [~,~,~,~,reg] = egcitest([p1(1:T0) p2(1:T0)]); %p1=a+b*p2+e
        b=reg(1).coeff(2);
        a=reg(1).coeff(1);
    elseif dtrndng==1
        [~,~,~,~,reg] = egcitest([p1(1:T0) p2(1:T0)],'creg','ct'); %p1=a+b*p2+e
        b=reg(1).coeff(3);
        a=reg(1).coeff(1);
        c=reg(1).coeff(2);
    end
end
if dtrndng==0
    if a==0 && b==1
        spread=p1t/p1(T0)-b*p2t/p2(T0);
        ncons1=p1(T0);
        ncons2=p2(T0);
    else
        spread=p1t-b*p2t-a; %residuals from cointegrating regression
        ncons1=1;
        ncons2=1;
    end
elseif dtrndng==1
    if choose_thresh==0
        %         trnd=((T0+1:T0+T1))';
        trnd=((1:T1))';
    else
        trnd=((1:T0))';
    end
    spread=p1t-b*p2t-a-c*trnd; %residuals from cointegrating regression
end
if isempty(thresh)
    if a==0 && b==1
        if dtrndng==0
            thresh=2*std(p1(1:T0)/p1(1)-a-b*p2(1:T0)/p2(1)); % threshold in Gatev et al.
        elseif dtrndng==1
            thresh=2*std(p1(1:T0)/p1(1)-a-b*p2(1:T0)/p2(1)-c*(1:T0)');
        end
    else
        if dtrndng==0
            thresh=2*std(p1(1:T0)-a-b*p2(1:T0)); % threshold in Gatev et al.
        elseif dtrndng==1
            thresh=2*std(p1(1:T0)-a-b*p2(1:T0)-c*(1:T0)');
        end
    end
end
post=zeros(T1,2);
ts=0;
sign_spread=sign(spread);
change_direction=double([0;diff([sign_spread])]~=0);
openpos=zeros(T1,1);

if spread(1)>=thresh
    ts=ts+1;
    post(ts,1)=1;
    openpos(1)=1;
elseif spread(1)<=-thresh
    ts=ts+1;
    post(ts,1)=-1;
    openpos(1)=-1;
end
for t=2:T1
    if spread(t)>=thresh && openpos(t-1)==0
        ts=ts+1;
        post(ts,1)=t;
        openpos(t)=1;
    elseif spread(t)<-thresh && openpos(t-1)==0
        ts=ts+1;
        post(ts,1)=-t;
        openpos(t)=-1;
    end
    if change_direction(t)==0 && openpos(t-1)==1
        openpos(t)=1;
    elseif change_direction(t)==0 && openpos(t-1)==-1
        openpos(t)=-1;
    end
    
    if change_direction(t)==1 && openpos(t-1)==1
        post(ts,2)=t;
    elseif change_direction(t)==1 && openpos(t-1)==-1
        post(ts,2)=-t;
    end
    
end
post=post(1:ts,:);
profit_1dollar=0;
profit_1stock=0;

% if b1==1 || b1==0
%     b=1;
% end
trade_return=zeros(ts,2);
if ts>0
    if post(ts,2)==0
        post(ts,2)=T1;
    end
    postabs=abs(post);
    p1t=p1t/ncons1;
    p2t=p2t/ncons2;
    if ~isempty(post)
        
        for tr=1:ts
            if sign(post(tr,1))==1
                trade_return(tr,1)=((p1t(postabs(tr,1))-p1t(postabs(tr,2)))/p1t(postabs(tr,1)))+...
                    abs(b)*((p2t(postabs(tr,2))-p2t(postabs(tr,1)))/p2t(postabs(tr,1)));
                profit_1dollar=profit_1dollar+trade_return(tr,1);
            else
                trade_return(tr,2)=((p1t(postabs(tr,2))-p1t(postabs(tr,1)))/p1t(postabs(tr,1)))+...
                    abs(b)*((p2t(postabs(tr,1))-p2t(postabs(tr,2)))/p2t(postabs(tr,1)));
                profit_1dollar=profit_1dollar+trade_return(tr,2);
            end
            
            %             if sign(post(tr,1))==1
            %                 profit_1stock=profit_1stock+((p1t(postabs(tr,1))-p1t(postabs(tr,2)))/p1t(postabs(tr,1)))+...
            %                     abs(b)*((p2t(postabs(tr,2))-p2t(postabs(tr,1)))/p2t(postabs(tr,1)));
            %             else
            %                 profit_1stock=profit_1stock+(p1t(postabs(tr,2))-p1t(postabs(tr,1)))+...
            %                     abs(b)*(p2t(postabs(tr,1))-p2t(postabs(tr,2)));
            %             end
            
            
        end
    end
end
profit=[profit_1dollar];