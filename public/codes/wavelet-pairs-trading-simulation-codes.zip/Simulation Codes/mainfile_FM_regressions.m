% This file conducts Fama-French regressions 
% OLS estimates, associated t statistics,  and R^2 are saved in the arrays
% for different specifications
clear
clc
close all
%% Data
% load data_SP500_cleared % Data is not shared becauce of copyright issues.
% data_SP500_cleared contains a dataset called dataff. The first columns is the
% dates, the remaining 415 series are stock prices from SP500 index. The
% below code does minor data cleaning. But one can easily use the remaining
% code for a given data set.
load FMdata % Fama French factors
level=1;
clearvars data dataf
init=max(find(diff(datenum(dataff.Dates))>5))+1;
dataff0=dataff(init:end,:);
dtrndng=0;
TT=length(dataff0);
TY=floor(TT/252);
T=TY*252;
data0=double(dataff0(1:T,2:end));
dates0=dataff0.Dates(253:T);
datanames=dataff0.Properties.VarNames(2:end);
%% 
warning('off')
theta=0; % Transaction Cost.
if theta==0
load Returns_theta0 % Load returns obtained from mainfile_basic_sumilation with 0 transaction cost
elseif theta==1
    load Returns_theta1 % Load returns obtained from mainfile_basic_sumilation with 0.001 transaction cost
end

dtrndng=[0];
for mm=[1 2] % Pairs selection method: cointegration=1 and minimum distance=2
    % For wavelet trade only
    y0=ywf(1:1764,mm); % Wavelet returns.
    y0(isnan(y0))=0; % remove nan
    [C,ia,ib] = intersect(datenum(FM.Date),datenum(dates0)); % find the intersection of FF dataset and the reurn series.
    X=double(FM(ia,2:end))/100;
    mdl = fitlm(X(:,1:5),y0-X(:,end)); % FF five factor model I
    mat_FF5I(1:2:2*length(mdl.Coefficients.Estimate),mm)=mdl.Coefficients.Estimate; % OLS estimates
    mat_FF5I(2:2:2*length(mdl.Coefficients.Estimate),mm)=mdl.Coefficients.tStat; % OLS t statistics
    r2mat_FF5I(mm)=mdl.Rsquared.Adjusted; % OLS R^2
    
    [C,ia,ib] = intersect(datenum(FM.Date),datenum(dates0));
    X=double(FM(ia,2:end))/100;
    mdl = fitlm(X(:,[1:3 6 8]),y0-X(:,end)); % FF five factor model II
    mat_FF5II(1:2:2*length(mdl.Coefficients.Estimate),mm)=mdl.Coefficients.Estimate;
    mat_FF5II(2:2:2*length(mdl.Coefficients.Estimate),mm)=mdl.Coefficients.tStat;
    r2mat_FF5II(mm)=mdl.Rsquared.Adjusted;
    
    [C,ia,ib] = intersect(datenum(FM.Date),datenum(dates0));
    X=double(FM(ia,2:end))/100;
    mdl = fitlm(X(:,[1:3 6:7]),y0-X(:,end)); % FF five factor model III
    mat_FF5III(1:2:2*length(mdl.Coefficients.Estimate),mm)=mdl.Coefficients.Estimate;
    mat_FF5III(2:2:2*length(mdl.Coefficients.Estimate),mm)=mdl.Coefficients.tStat;
    r2mat_FF5III(mm)=mdl.Rsquared.Adjusted;
    
    [C,ia,ib] = intersect(datenum(FM.Date),datenum(dates0));
    X=double(FM(ia,2:end))/100;
    mdl = fitlm(X(:,[1:6 8]),y0-X(:,end)); % FF seven factor model I
    mat_FF5p2I(1:2:2*length(mdl.Coefficients.Estimate),mm)=mdl.Coefficients.Estimate;
    mat_FF5p2I(2:2:2*length(mdl.Coefficients.Estimate),mm)=mdl.Coefficients.tStat;
    r2mat_FF5p2I(mm)=mdl.Rsquared.Adjusted;

    [C,ia,ib] = intersect(datenum(FM.Date),datenum(dates0));
    X=double(FM(ia,2:end))/100;
    mdl = fitlm(X(:,[1:7]),y0-X(:,end)); % FF seven factor model II
    mat_FF5p2II(1:2:2*length(mdl.Coefficients.Estimate),mm)=mdl.Coefficients.Estimate;
    mat_FF5p2II(2:2:2*length(mdl.Coefficients.Estimate),mm)=mdl.Coefficients.tStat;
    r2mat_FF5p2II(mm)=mdl.Rsquared.Adjusted;
   
    [C,ia,ib] = intersect(datenum(FM.Date),datenum(dates0));
    X=double(FM(ia,2:end))/100;
    mdl = fitlm(X(:,[1:8]),y0-X(:,end)); % FF eight factor model
    mat_FF5p3(1:2:2*length(mdl.Coefficients.Estimate),mm)=mdl.Coefficients.Estimate;
    mat_FF5p3(2:2:2*length(mdl.Coefficients.Estimate),mm)=mdl.Coefficients.tStat;
    r2mat_FF5p3(mm)=mdl.Rsquared.Adjusted;
      
end
