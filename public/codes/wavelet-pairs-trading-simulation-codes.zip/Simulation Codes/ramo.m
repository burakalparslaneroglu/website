function [stat]=ramo(data,wave)
[Lo_D,Hi_D] = wfilters(wave,'d');
[ca,cd] = dwt(data,Lo_D,Hi_D);
S_1=(ca'*ca)/((ca'*ca)+(cd'*cd));
reg=[0;data(1:end-1,1)];
res=data-reg*((reg'*reg)\(reg'*data));
[c,lags] = xcov(res,20);
c=c/length(res);
omega_hat=c(lags==0)+2*(1-(1:20)/21)*c(lags>0);
stat=length(data)*(4*omega_hat)*(S_1-1)/(2*(cd'*cd)/length(cd));
