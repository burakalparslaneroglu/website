function y=arima_sim(eps,ar_coeff,ma_coeff,y0,eps0);
T=length(eps);
ar_lag=length(ar_coeff);
ma_lag=length(ma_coeff);
if ma_coeff==0;
    ma_lag=0;
end
if ar_coeff==0;
    ar_lag=0;
end
max_lag=max(ma_lag,ar_lag);
if length(y0)~=max_lag
    y0=zeros(max_lag,1);
end
if length(eps0)~=max_lag
    eps0=zeros(max_lag,1);
end

yt=[y0;zeros(T,1)];
epst=[eps0;eps];
for t=max_lag+1:T+max_lag;
    for p=1:ar_lag
         yt(t)=yt(t)+ar_coeff(p)*yt(t-p);
    end
    for q=1:ma_lag
         yt(t)=yt(t)+ma_coeff(q)*epst(t-q);
    end
    yt(t)=yt(t)+epst(t);
end
y=yt(max_lag+1:T+max_lag);