clear
clc
close all
% parpool('local',20)
load data_SP500_cleared
clearvars data dataf
load pairs_indices
init=max(find(diff(datenum(dataff.Dates))>5))+1;
dataff0=dataff(init:end,:);

TT=length(dataff0);
TY=floor(TT/252);
T=TY*252;
data0=double(dataff0(1:T,2:end));
datanames=dataff0.Properties.VarNames(2:end);
for mm=1:2
    % Profit from the pairs chosen with Johansen test

    for per=1:7
        [mm per]
        % Cointegration Tests
        smpl0=(per-1)*252+1:(per)*252; % Testing period
        smpl1=(per)*252+1:(per+1)*252; % Trading period
        level=1;
        for delay=[22]
            dtrndng=[0];
            if mm==1 % cointegration
                cointj_ind=mat_coint.(['mat_' num2str(per)]);
            end
            if mm==2 % minimum distance 1000 Pairs
                cointj_ind=mat_mindist.(['mat_' num2str(per)]);
            end
            
            wavelets={'sym22'};
            T0=252;
            T1=252;
            for level=[1]

                profitgatevf_org=zeros(length(cointj_ind),length(wavelets));
                profitgatevwf=zeros(length(cointj_ind),length(wavelets));
                trade_returngatevf_org=zeros(T1,length(cointj_ind),length(wavelets));
                trade_returngatevwf=zeros(T1,length(cointj_ind),length(wavelets));


                ww=0;
                for wavelet=wavelets
                    ww=ww+1;
                    parfor mc=1:length(cointj_ind)

                        P=data0([smpl0 smpl1],cointj_ind(mc,1:2));
                        p1=P(:,1);
                        p2=P(:,2);
                        if dtrndng==0
                            X=[ones(T0,1) p2(1:T0)];
                        elseif dtrndng==1
                            X=[ones(T0,1) (1:T0)' p2(1:T0)];
                        end
                        coeff=inv(X'*X)*X'*p1(1:T0);

                        buy_val=1;
                        sell_val=p1(T0+T1)/p1(T0+1)+abs(coeff(2))*p2(T0+T1)/p2(T0+1);
                        sell_val=sell_val/(1+abs(coeff(2)));
                        profitgatevf_org(mc)=sell_val-buy_val;
                        trade_returngatevf1_org=diff(p1(T0+1:T0+T1)/p1(T0+1))+abs(coeff(2))*diff(p2(T0+1:T0+T1)/p2(T0+1));
                        trade_returngatevf_org(:,mc)=[0;trade_returngatevf1_org/(1+abs(coeff(2)))];

                        P1w0=modwt(P(:,1),char(wavelet),level);
                        P2w0=modwt(P(:,2),char(wavelet),level);
                        Pw=[P1w0(end,:)' P2w0(end,:)'];
                        p1w=Pw(:,1);
                        p2w=Pw(:,2);
                        if dtrndng==0
                            Xw=[ones(T0,1) p2w(1:T0)];
                        elseif dtrndng==1
                            Xw=[ones(T0,1) (1:T0)' p2w(1:T0)];

                        end
                        coeffw=inv(Xw'*Xw)*Xw'*p1w(1:T0);
                        buy_valw=1;
                        sell_valw=p1(T0+T1)/p1(T0+1)+abs(coeffw(2))*p2(T0+T1)/p2(T0+1);
                        sell_valw=sell_valw/(1+abs(coeffw(2)));
                        profitgatevwf(mc)=sell_valw-buy_valw;
                        trade_returngatevwf1=diff(p1(T0+1:T0+T1)/p1(T0+1))+abs(coeffw(2))*diff(p2(T0+1:T0+T1)/p2(T0+1));
                        trade_returngatevwf(:,mc)=[0;trade_returngatevwf1/(1+abs(coeffw(2)))];
                        

                    end

                end

                profits_j.profitgatevf_org=[cointj_ind profitgatevf_org];
                profits_j.profitgatevwf=[cointj_ind profitgatevwf];

                profits_j.trade_returngatevwf=trade_returngatevwf;
                profits_j.trade_returngatevf_org=trade_returngatevf_org;
              
                mean_profits_j=[mean(profitgatevwf) mean(profitgatevf_org)];


%                 eval(['save results_pairs_trade_SP500_level_' num2str(level) '_year_' num2str(per) '_detrend_' num2str(dtrndng) 'delay_' num2str(delay) '_model_' num2str(mm) '_onlygatev_buyandhold_240722 mean_profits_j profits_j' ])
            end
        end
        clearvars -except data0 per mm
    end
end


%Tables

mat=[];
 mat_risk=[];

for level=1
    for delay=[22]
        for mm=2
            % Profit from the pairs chosen with Johansen test
            matw0=[];
            mat0=[];
            mat_risk0=[];
          
            for per=1:7
                % Cointegration Tests
                dtrndng=[0];
                eval(['load results_pairs_trade_SP500_level_' num2str(level) '_year_' num2str(per) '_detrend_' num2str(dtrndng) 'delay_' num2str(delay) '_model_' num2str(mm) '_onlygatev_buyandhold_240722.mat'])
                y=mean(profits_j.trade_returngatevwf,2);
                x=profits_j.profitgatevwf(:,3);
                mat0=[mat0;[mean(x) std(x) range(x) skewness(x) kurtosis(x)]];
                mat_risk0=[mat_risk0 ;[sqrt(252)*mean(y)/std(y) MAXDRAWDOWN(y) ...
                    sum(x>0)/length(x) quantile(x,0.05) mean(x(x<quantile(x,0.05))) ...
                    mean(x)/mean(x(x<quantile(x,0.05)))]];

            end
            mat=[mat mat0];
             mat_risk=[mat_risk mat_risk0];

        end
    end
end


