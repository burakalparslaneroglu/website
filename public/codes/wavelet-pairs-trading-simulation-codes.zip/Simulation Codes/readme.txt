"PAIRS TRADING WITH WAVELET TRANSFORM"
Burak Alparslan Eroğlu, Haluk Yener and Taner Yiğit
MATLAB Codes used in the main analysis

MAINFILES:
	mainfile_basic_simulations.m: generates the trade returns and various statistic from pairs trading with wavelets.
	mainfile_basic_simulations_months.m: generates the results for 3, 6, or 9 months trading period.
	mainfile_Petkova_models.m: obtains Petkova asset pricing tests.
	mainfile_FM_regressions.m: obtains Fama-French aseet pricing tests. 
	mainfile_spread_unit_root_test.m: runs unit root tests on trading spreads.
	mainfile_buyandhold_analysis.m: conducts a buy and hold trade analysis.

AUXILLIARY FILES:
	pairs_trade_profit_fun_v2.m: main function for standard Pairs trading algorithm
	pairs_trade_profit_fun_wave_v2.m: main function for Wavelet Pairs trading algorithm
	return_generate.m: generates trade returns described in the article.
	unit_roots.m: conducts unit root tests.
	
	There are various other auxilliary functions required to run the above functions.

DATA AND MAT FILES:
	Returns_theta0.mat: contains the returns from standard and wavelet pairs trading with no transaction cost.
	Returns_theta1.mat: contains the returns from standard and wavelet pairs trading with %0.1 transaction cost.
	pairs_indices.mat: cointains the indices of stocks used in the analysis.
	FMdata.mat: contains Fama-French and Petkova factors.
	
