function [za,mza,msb,adft,adfa,pt,mpt,mzt,za1,mza1,msb1,mzt1,mza2,adft1,adfa1,krule,krule1,a1,ahatols,s2ar1]=unit_roots(data,dtrnding,penalty,kmax,kmin)

% y: a univariate time series of dimension nt.
% p: the order of the polynomial trend; either
%    a) detrend = 0 with only a constant in z, or
%    b) detrend = 1, with a constant and a linear trend in z.
% penalty: 0 for mic and 1 for bic.
% As discussed in the paper, the AIC has better theoretical and empirical
% properties.
% --------------------------------------------------------------------
% Output:
% Tests based on GLS detrended data for both the statistic and the
% spectral density:
% za:  the Phillips-Perron test Z_alpha;
% mza: the modified Phillip-Perron test MZ_alpha;
% msb: the modified Sargan-Bhargava test;
% adf: the augmented Dickey-Fuller test;
% pt:  Elliott, Rothemberg and Stock feasible point optimal test;
% mpt: the modified point optimal test;
% mzt: the modified Phillips-Perron MZ_t test;
% krule: the order of the autoregression selected by the data dependent
%        rule (used in constructing the spectral density estimator at
%        frequency zero);
% za1 and mza1 are always based on OLS detrending.
% mza2 uses GLS detrended data for the statistic but OLS detrending for
% the spectral density.
% a1: the sum of the autoregressive coefficients in the ADF autoregression.
% Note: for each test, say, za,
% za[1] returns the test statistic and za[2] returns the critical values
% 
% ---------------------------------------------------------------------*/
z=[];
cbar=-7;
nt=size(data,1);
if dtrnding == 0
z=ones(nt,1);
cbar=-7.0;
end
if dtrnding == 1
z=[ones(nt,1) (1:nt)'];
cbar=-13.5;
end


[yt,ssra]=glsd(data,z,cbar); %/* transforming the data*/

nt=size(yt,1);
[ahat,r,fit]=olsqr2(yt(2:nt),yt(1:nt-1));  %/* estimate the alpha-hat*/
s2u=(r'*r)/(nt-1);
sumyt2=sum(yt(1:nt-1).^2)/((nt-1)^2);
krule=s2ar(yt,penalty,kmax,kmin); %/* estimate s2ar */
[adft,adfa,a1,sar]=adfp(yt,krule);

% /*constructing zalpha and the M tests using GLS dtrndinged data*/
bt=nt-1;
za=bt*(ahat-1)-(sar-s2u)/(2*sumyt2);
mza=((yt(nt)^2)/bt-sar-(yt(1)^2)/bt)/(2*sumyt2);
msb=sqrt(sumyt2/sar);
mzt=mza*msb;

% /* construct PT and MPT */
[ytf,ssr1]=glsd(data,z,0);
pt=(ssra-(1+cbar/nt)*ssr1)/sar;
mpt=[];

if dtrnding == 0;
mpt=(cbar*cbar*sumyt2-cbar*(yt(nt,1)^2)/nt)/sar;
end;
if  dtrnding == 1;
mpt=(cbar*cbar*sumyt2+(1-cbar)*(yt(nt,1)^2)/nt)/sar;
end;


% /* the ols dtrndinging statistics */

[yols,~]=olsd(data,dtrnding);
% [Cs,L] = wavedec(yols,1,Lo_D,Hi_D);
% C = modwt(data,wavelet,1);
%  yols=Cs(1:L(1));
 yols2=sum(yols(1:size(yols,1)-1).^2)/((size(yols,1)-1)^2);
[ahatols,rols,~]=olsqr2(yols(2:nt,1),yols(1:nt-1,1));
s2uols=rols'*rols/(nt-1);
krule1=s2ar(yols,penalty,kmax,kmin);
[adft1,adfa1,~,s2ar1]=adfp(yols,krule1);
za1=bt*(ahatols-1)-(s2ar1-s2uols)/(2*yols2);
mza1=((yols(nt,1)^2)/bt-s2ar1-(yols(1)^2)/bt)/(2*yols2);
mza2=((yt(nt,1)^2)/bt-s2ar1-(yt(1)^2)/bt)/(2*sumyt2);
msb1=sqrt(yols2/s2ar1);
mzt1=mza1*msb1;
if dtrnding == 0;
za = [za; -8.35];
za1 = [za1; -14.1];
mzt = [mzt; -1.98];
mza = [mza;-8.1];
mza1= [mza1;-14.1];
mza2= [mza2;-8.1];
msb = [msb; 0.233];
adfa = [adfa; -1.98];
mpt = [mpt; 3.17];
pt = [pt; 3.17];
adfa1=[adfa1;-2.86];
else
za = [za; -17.3];
za1 = [za1; -21.0];
mzt = [mzt; -2.91];
mza1 = [mza1;-21.3];
mza2 = [mza2;-17.3];
mza = [mza;-17.3];
msb = [msb; .168];
adfa = [adfa; -2.91];
mpt = [mpt; 5.48];
pt = [pt; 5.48];
adfa1=[adfa1;-3.41];
end








