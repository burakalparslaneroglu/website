function [yd,ssr]=olsd(y,p);
if p==-1
    yd=y;
    ssr=sum(yd(1:size(yd,1)-1).^2)/((size(yd,1)-1)^2);
else
reg=ones(size(y,1),1);
trend=(1:size(y,1))';
i=1;
while i<=p;
reg=[reg trend.^i];
i=i+1;
end;
[~,yd,~]=olsqr2(y,reg);
ssr=sum(yd(1:size(yd,1)-1).^2)/((size(yd,1)-1)^2);
end