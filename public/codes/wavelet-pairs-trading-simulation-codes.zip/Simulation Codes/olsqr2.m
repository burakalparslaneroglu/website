function [beta_OLS,r,fit]=olsqr2(y,x)

beta_OLS=inv(x'*x)*x'*y;
r=y-x*beta_OLS;
fit=x*beta_OLS;