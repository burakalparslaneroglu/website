% This file generates results for different trading horizons. We only
% consider the standard and wavelet methods. The code is identical to
% mainfile_basic_simulations.m except the restriction on the models used
% and the minimum distance pairs used. Note that we did not include
% cointegrated pairs for brevity.
clear
clc
close all
%% Data
% load data_SP500_cleared % Data is not shared becauce of copyright issues.
% data_SP500_cleared contains a dataset called dataff. The first columns is the
% dates, the remaining 415 series are stock prices from SP500 index. The
% below code does minor data cleaning. But one can easily use the remaining
% code for a given data set.
clearvars data dataf
init=max(find(diff(datenum(dataff.Dates))>5))+1;
dataff0=dataff(init:end,:);

TT=length(dataff0);
TY=floor(TT/252);
T=TY*252;
data0=double(dataff0(1:T,2:end));
datanames=dataff0.Properties.VarNames(2:end);
%%
for nmonths=[3 6 9] % Number of trading months.
    maxnobs=length(data0);
    for num_pairs=[100 1000]
        cstop=0;
        smpl0=1:252; % Testing period
        smpl1=smpl0(end)+1:smpl0(end)+nmonths*21; % Trading period
        per=0;
        while cstop==0
            per=per+1;
            dtrndng=[0]
            T0=252;
            T1=21*nmonths;
            
            cc=0;
            for ii=1:size(data0,2)
                for jj=ii+1:size(data0,2)
                    cc=cc+1;
                    P=data0([smpl0],[ii jj]);
                    X1=data0(smpl0,ii)/data0(smpl0(1),ii);
                    X2=data0(smpl0,jj)/data0(smpl0(1),jj);
                    SSD(cc,1)=(X1-X2)'*(X1-X2)/length(smpl0);
                    SSD(cc,2:3)=[ii jj];
                end
            end
            SSSD=sortrows(SSD,1);
            mindist_ind=SSSD(1:num_pairs,2:3);
            wavelets={'haar','sym12','sym14','sym18','sym22'};
            
            for level=[1]
                profitf=zeros(length(mindist_ind),length(wavelets));
                profitwf=zeros(length(mindist_ind),length(wavelets));
                profitf0=zeros(length(mindist_ind),length(wavelets));
                profitwf0=zeros(length(mindist_ind),length(wavelets));
                profitgatevf=zeros(length(mindist_ind),length(wavelets));
                profitgatevwf=zeros(length(mindist_ind),length(wavelets));
                tsf=zeros(length(mindist_ind),length(wavelets));
                tswf=zeros(length(mindist_ind),length(wavelets));
                tsgatevf=zeros(length(mindist_ind),length(wavelets));
                tsgatevwf=zeros(length(mindist_ind),length(wavelets));
                trade_returnf=zeros(T1,length(mindist_ind),length(wavelets));
                trade_returnwf=zeros(T1,length(mindist_ind),length(wavelets));
                trade_returngatevf=zeros(T1,length(mindist_ind),length(wavelets));
                trade_returngatevwf=zeros(T1,length(mindist_ind),length(wavelets));
                postof=zeros(T1,length(mindist_ind),length(wavelets));
                postcf=zeros(T1,length(mindist_ind),length(wavelets));
                postowf=zeros(T1,length(mindist_ind),length(wavelets));
                postcwf=zeros(T1,length(mindist_ind),length(wavelets));
                postogatevf=zeros(T1,length(mindist_ind),length(wavelets));
                postcgatevf=zeros(T1,length(mindist_ind),length(wavelets));
                postogatevwf=zeros(T1,length(mindist_ind),length(wavelets));
                postcgatevwf=zeros(T1,length(mindist_ind),length(wavelets));
                spreadf=zeros(T1,length(mindist_ind),length(wavelets));
                spreadwf=zeros(T1,length(mindist_ind),length(wavelets));
                spreadgatevf=zeros(T1,length(mindist_ind),length(wavelets));
                spreadgatevwf=zeros(T1,length(mindist_ind),length(wavelets));
                ww=0
                for wavelet=wavelets
                    ww=ww+1
                    coeffs1=zeros(length(mindist_ind),1);
                    coeffs2=zeros(length(mindist_ind),1);
                    parfor mc=1:length(mindist_ind)
                        
                        P=data0([smpl0 smpl1],mindist_ind(mc,:));
                        p1=P(:,1);
                        p2=P(:,2);
                        if dtrndng==0
                            X=[ones(T0,1) p2(1:T0)];
                        else dtrndng==1
                            X=[ones(T0,1) (1:T0)' p2(1:T0)];
                        end
                        coeff=inv(X'*X)*X'*p1(1:T0);
                        res=p1(1:T0)-X*coeff;
                        coeffs1(mc)=coeff(1);
                        coeffs2(mc)=coeff(2);
                        P1w0=modwt(P(:,1),char(wavelet),level);
                        P2w0=modwt(P(:,2),char(wavelet),level);
                        Pw=[P1w0(end,:)' P2w0(end,:)'];
                        
                        
                        [profitgatevf0,tsgatevf0,trade_returngatevf0,postgatevf0,spreadgatevf0]=pairs_trade_profit_fun_v2([],P,T0,T1,0,0,[],dtrndng);
                        [profitgatevwf0,tsgatevwf0,trade_returngatevwf0,postgatevwf0,spreadgatevwf0]=pairs_trade_profit_fun_wave_v2([],P,Pw,T0,T1,0,0,[],dtrndng);
                        profitgatevf(mc,ww)=profitgatevf0;
                        tsgatevf(mc,ww)=tsgatevf0;
                        spreadgatevf(:,mc,ww)=spreadgatevf0;
                        profitgatevwf(mc,ww)=profitgatevwf0;
                        tsgatevwf(mc,ww)=tsgatevwf0;
                        spreadgatevwf(:,mc,ww)=spreadgatevwf0;
                        trade_returngatevf1=zeros(T1,1);
                        trade_returngatevf1(abs(postgatevf0(1:length(trade_returngatevf0(trade_returngatevf0~=0)),2)))=trade_returngatevf0(trade_returngatevf0~=0);
                        trade_returngatevf(:,mc,ww)=trade_returngatevf1;
                        trade_returngatevwf1=zeros(T1,1);
                        trade_returngatevwf1(abs(postgatevwf0(1:length(trade_returngatevwf0(trade_returngatevwf0~=0)),2)))=trade_returngatevwf0(trade_returngatevwf0~=0);
                        trade_returngatevwf(:,mc,ww)=trade_returngatevwf1;
                        
                        postogatevf1=zeros(T1,1);
                        postogatevf1(1:size(postgatevf0,1))=postgatevf0(:,1);
                        postogatevf(:,mc,ww)=postogatevf1;
                        postcgatevf1=zeros(T1,1);
                        postcgatevf1(1:size(postgatevf0,1))=postgatevf0(:,2);
                        postcgatevf(:,mc,ww)=postcgatevf1;
                        
                        
                        postogatevwf1=zeros(T1,1);
                        postogatevwf1(1:size(postgatevwf0,1))=postgatevwf0(:,1);
                        postogatevwf(:,mc,ww)=postogatevwf1;
                        postcgatevwf1=zeros(T1,1);
                        postcgatevwf1(1:size(postgatevwf0,1))=postgatevwf0(:,2);
                        postcgatevwf(:,mc,ww)=postcgatevwf1;
                        
                    end
                    
                end
                
                profits_j.profitgatevf=[mindist_ind profitgatevf];
                profits_j.profitgatevwf=[mindist_ind profitgatevwf];
                
                profits_j.tsgatevf=[mindist_ind tsgatevf];
                profits_j.tsgatevwf=[mindist_ind tsgatevwf];
                
                profits_j.trade_returngatevwf=trade_returngatevwf;
                profits_j.trade_returngatevf=trade_returngatevf;
                
                profits_j.postogatevwf=postogatevwf;
                profits_j.postogatevf=postogatevf;
                
                profits_j.postcgatevwf=postcgatevwf;
                profits_j.postcgatevf=postcgatevf;
                profits_j.spreadgatevf=spreadgatevf;
                profits_j.spreadgatevwf=spreadgatevwf;
                
                mean_profits_j=[mean(profitgatevwf);[mean(profitgatevf(:,1)) nan(1,length(wavelets)-1)]];
                eval(['save results_pairs_trade_SP500_all_year_' num2str(per) '_detrend_' num2str(dtrndng) 'numpairs_' num2str(num_pairs) '_level_' num2str(level) '_mindist_onlygatev_' num2str(nmonths) ' mean_profits_j profits_j' ])
            end
            smpl0=smpl1(end)-251:smpl1(end);
            smpl1=smpl0(end)+1:smpl0(end)+nmonths*21;
            if any([smpl0 smpl1]>maxnobs)
                cstop=1;
            end
        end
        
        clearvars -except data0 per num_pairs nmonths maxnobs
        
    end
    
  
    
    % %%%%%%%%%%%Trading Algorithm starts here %%%%%%%%%%%%%%%%%%%%%% %
    % clear
    % clc
    % close all
    % parpool('local',20)
    load data_SP500_cleared
    addpath('D:\Dropbox\Pairs New')
    
    clearvars data dataf
    init=max(find(diff(datenum(dataff.Dates))>5))+1;
    dataff0=dataff(init:end,:);
    
    TT=length(dataff0);
    TY=floor(TT/252);
    T=TY*252;
    data0=double(dataff0(1:T,2:end));
    datanames=dataff0.Properties.VarNames(2:end);
    
    
    maxnobs=length(data0);
    % nmonths=9;
    
    cstop=0;
    smpl0=1:252; % Testing period
    smpl1=smpl0(end)+1:smpl0(end)+nmonths*21; % Trading period
    per=0;
    load pairs_indices
    while cstop==0
        per=per+1;
        
        dtrndng=[0]
        T0=252;
        T1=21*nmonths;;
        per0=floor(per/(12/nmonths))+1;
        cointj_ind=mat_coint.(['mat_' num2str(per)]);
       
        wavelets={'haar','sym12','sym14','sym18','sym22'};
        
        for level=[1]
            profitf=zeros(length(cointj_ind),length(wavelets));
            profitwf=zeros(length(cointj_ind),length(wavelets));
            profitf0=zeros(length(cointj_ind),length(wavelets));
            profitwf0=zeros(length(cointj_ind),length(wavelets));
            profitgatevf=zeros(length(cointj_ind),length(wavelets));
            profitgatevwf=zeros(length(cointj_ind),length(wavelets));
            tsf=zeros(length(cointj_ind),length(wavelets));
            tswf=zeros(length(cointj_ind),length(wavelets));
            tsgatevf=zeros(length(cointj_ind),length(wavelets));
            tsgatevwf=zeros(length(cointj_ind),length(wavelets));
            trade_returnf=zeros(T1,length(cointj_ind),length(wavelets));
            trade_returnwf=zeros(T1,length(cointj_ind),length(wavelets));
            trade_returngatevf=zeros(T1,length(cointj_ind),length(wavelets));
            trade_returngatevwf=zeros(T1,length(cointj_ind),length(wavelets));
            postof=zeros(T1,length(cointj_ind),length(wavelets));
            postcf=zeros(T1,length(cointj_ind),length(wavelets));
            postowf=zeros(T1,length(cointj_ind),length(wavelets));
            postcwf=zeros(T1,length(cointj_ind),length(wavelets));
            postogatevf=zeros(T1,length(cointj_ind),length(wavelets));
            postcgatevf=zeros(T1,length(cointj_ind),length(wavelets));
            postogatevwf=zeros(T1,length(cointj_ind),length(wavelets));
            postcgatevwf=zeros(T1,length(cointj_ind),length(wavelets));
            spreadf=zeros(T1,length(cointj_ind),length(wavelets));
            spreadwf=zeros(T1,length(cointj_ind),length(wavelets));
            spreadgatevf=zeros(T1,length(cointj_ind),length(wavelets));
            spreadgatevwf=zeros(T1,length(cointj_ind),length(wavelets));
            ww=0
            for wavelet=wavelets
                ww=ww+1
                coeffs1=zeros(length(cointj_ind),1);
                coeffs2=zeros(length(cointj_ind),1);
                parfor mc=1:length(cointj_ind)
                    
                    P=data0([smpl0 smpl1],matj(cointj_ind(mc),1:2));
                    p1=P(:,1);
                    p2=P(:,2);
                    if dtrndng==0
                        X=[ones(T0,1) p2(1:T0)];
                    else dtrndng==1
                        X=[ones(T0,1) (1:T0)' p2(1:T0)];
                    end
                    coeff=inv(X'*X)*X'*p1(1:T0);
                    res=p1(1:T0)-X*coeff;
                    coeffs1(mc)=coeff(1);
                    coeffs2(mc)=coeff(2);
                    
                    P1w0=modwt(P(:,1),char(wavelet),level);
                    P2w0=modwt(P(:,2),char(wavelet),level);
                    Pw=[P1w0(end,:)' P2w0(end,:)'];
                    
                    
                    [profitgatevf0,tsgatevf0,trade_returngatevf0,postgatevf0,spreadgatevf0]=pairs_trade_profit_fun_v2([],P,T0,T1,0,0,[],dtrndng);
                    [profitgatevwf0,tsgatevwf0,trade_returngatevwf0,postgatevwf0,spreadgatevwf0]=pairs_trade_profit_fun_wave_v2([],P,Pw,T0,T1,0,0,[],dtrndng);
                    profitgatevf(mc,ww)=profitgatevf0;
                    tsgatevf(mc,ww)=tsgatevf0;
                    spreadgatevf(:,mc,ww)=spreadgatevf0;
                    profitgatevwf(mc,ww)=profitgatevwf0;
                    tsgatevwf(mc,ww)=tsgatevwf0;
                    spreadgatevwf(:,mc,ww)=spreadgatevwf0;
                    trade_returngatevf1=zeros(T1,1);
                    trade_returngatevf1(abs(postgatevf0(1:length(trade_returngatevf0(trade_returngatevf0~=0)),2)))=trade_returngatevf0(trade_returngatevf0~=0);
                    trade_returngatevf(:,mc,ww)=trade_returngatevf1;
                    trade_returngatevwf1=zeros(T1,1);
                    trade_returngatevwf1(abs(postgatevwf0(1:length(trade_returngatevwf0(trade_returngatevwf0~=0)),2)))=trade_returngatevwf0(trade_returngatevwf0~=0);
                    trade_returngatevwf(:,mc,ww)=trade_returngatevwf1;
                    
                    postogatevf1=zeros(T1,1);
                    postogatevf1(1:size(postgatevf0,1))=postgatevf0(:,1);
                    postogatevf(:,mc,ww)=postogatevf1;
                    postcgatevf1=zeros(T1,1);
                    postcgatevf1(1:size(postgatevf0,1))=postgatevf0(:,2);
                    postcgatevf(:,mc,ww)=postcgatevf1;
                    
                    
                    postogatevwf1=zeros(T1,1);
                    postogatevwf1(1:size(postgatevwf0,1))=postgatevwf0(:,1);
                    postogatevwf(:,mc,ww)=postogatevwf1;
                    postcgatevwf1=zeros(T1,1);
                    postcgatevwf1(1:size(postgatevwf0,1))=postgatevwf0(:,2);
                    postcgatevwf(:,mc,ww)=postcgatevwf1;
                    
                end
                
            end
            
            profits_j.profitgatevf=[cointj_ind profitgatevf];
            profits_j.profitgatevwf=[cointj_ind profitgatevwf];
            
            profits_j.tsgatevf=[cointj_ind tsgatevf];
            profits_j.tsgatevwf=[cointj_ind tsgatevwf];
            
            profits_j.trade_returngatevwf=trade_returngatevwf;
            profits_j.trade_returngatevf=trade_returngatevf;
            
            profits_j.postogatevwf=postogatevwf;
            profits_j.postogatevf=postogatevf;
            
            profits_j.postcgatevwf=postcgatevwf;
            profits_j.postcgatevf=postcgatevf;
            profits_j.spreadgatevf=spreadgatevf;
            profits_j.spreadgatevwf=spreadgatevwf;
            
            mean_profits_j=[mean(profitgatevwf);[mean(profitgatevf(:,1)) nan(1,length(wavelets)-1)]];
            eval(['save results_pairs_trade_SP500_all_year_' num2str(per) '_detrend_' num2str(dtrndng) '_level_' num2str(level) '_coint_onlygatev_' num2str(nmonths) '  mean_profits_j profits_j' ])
        end
        smpl0=smpl1(end)-251:smpl1(end);
        smpl1=smpl0(end)+1:smpl0(end)+nmonths*21;
        if any([smpl0 smpl1]>maxnobs)
            cstop=1;
        end
    end
    clearvars -except data0 per num_pairs nmonths
end
